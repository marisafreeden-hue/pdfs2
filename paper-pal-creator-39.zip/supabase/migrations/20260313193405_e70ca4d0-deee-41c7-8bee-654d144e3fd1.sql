
CREATE TABLE public.datasheet_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sheet_id text NOT NULL DEFAULT 'default',
  field_key text NOT NULL,
  content text NOT NULL DEFAULT '',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (sheet_id, field_key)
);

ALTER TABLE public.datasheet_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view content" ON public.datasheet_content FOR SELECT TO public USING (true);
CREATE POLICY "Anyone can insert content" ON public.datasheet_content FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Anyone can update content" ON public.datasheet_content FOR UPDATE TO public USING (true);
CREATE POLICY "Anyone can delete content" ON public.datasheet_content FOR DELETE TO public USING (true);

CREATE TRIGGER update_datasheet_content_updated_at
  BEFORE UPDATE ON public.datasheet_content
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
