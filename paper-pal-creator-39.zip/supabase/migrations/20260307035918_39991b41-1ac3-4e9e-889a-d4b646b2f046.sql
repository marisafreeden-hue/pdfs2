-- Create assets table for uploaded library assets
CREATE TABLE public.assets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_url TEXT NOT NULL,
  asset_type TEXT NOT NULL DEFAULT 'image',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Assets are viewable by everyone" ON public.assets FOR SELECT USING (true);
CREATE POLICY "Anyone can insert assets" ON public.assets FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can delete assets" ON public.assets FOR DELETE USING (true);

-- Create datasheet_elements table
CREATE TABLE public.datasheet_elements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sheet_id TEXT NOT NULL DEFAULT 'default',
  type TEXT NOT NULL,
  x DOUBLE PRECISION NOT NULL DEFAULT 0,
  y DOUBLE PRECISION NOT NULL DEFAULT 0,
  width DOUBLE PRECISION,
  height DOUBLE PRECISION,
  content TEXT,
  font_size INTEGER,
  font_weight TEXT,
  font_family TEXT,
  font_style TEXT,
  color TEXT,
  fill TEXT,
  stroke TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.datasheet_elements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Elements are viewable by everyone" ON public.datasheet_elements FOR SELECT USING (true);
CREATE POLICY "Anyone can insert elements" ON public.datasheet_elements FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update elements" ON public.datasheet_elements FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete elements" ON public.datasheet_elements FOR DELETE USING (true);

-- Create storage bucket for assets
INSERT INTO storage.buckets (id, name, public) VALUES ('assets', 'assets', true);

CREATE POLICY "Asset files are publicly accessible" ON storage.objects FOR SELECT USING (bucket_id = 'assets');
CREATE POLICY "Anyone can upload assets" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'assets');
CREATE POLICY "Anyone can delete assets" ON storage.objects FOR DELETE USING (bucket_id = 'assets');

-- Timestamp trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_datasheet_elements_updated_at
BEFORE UPDATE ON public.datasheet_elements
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();