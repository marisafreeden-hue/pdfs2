# Analyst FAQ copy updates

Two text changes on the GoContact Analyst FAQ page.

## Changes

1. Subhead under the title: "Analyst FAQs" becomes "Frequently Asked Questions".
2. First question becomes: "What is Analyst and why use it versus pasting data into an AI like ChatGPT or Claude?" with the new answer opening "Analyst is an AI-powered conversational analytics interface built natively into GoContact. This means Analyst does not send your operational data to a public AI model..." and keeping the rest of the existing paragraph.

No layout, styling, or pagination changes.

## Technical detail

Edit `src/pages/AIAnalystFAQ.tsx`: the `faq-title-sub` string and the first entry of `ctoItemsPage1`.
