import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import GoEngageDatasheet from "./pages/GoEngageDatasheet";
import PostCallAIDatasheet from "./pages/PostCallAIDatasheet";
import PartnerIntroKit from "./pages/PartnerIntroKit";
import CommunicatorDatasheet from "./pages/CommunicatorDatasheet";
import CommunicatorPartner from "./pages/CommunicatorPartner";
import BhiveDatasheet from "./pages/BhiveDatasheet";
import GoContactDatasheet from "./pages/GoContactDatasheet";
import GoEngageDatasheetEditable from "./pages/GoEngageDatasheetEditable";
import PartnerSuccessPlan from "./pages/PartnerSuccessPlan";
import AIAnalystFAQ from "./pages/AIAnalystFAQ";
import GoEngageInboundFAQ from "./pages/GoEngageInboundFAQ";
import ImplementationTaskforce from "./pages/ImplementationTaskforce";
import BhiveUserGuide from "./pages/BhiveUserGuide";
import CompanyOverview from "./pages/CompanyOverview";
import ExecutiveOverview from "./pages/ExecutiveOverview";
import ExecutiveOverviewGeneral from "./pages/ExecutiveOverviewGeneral";
import ExecutiveOverviewGeneralPT from "./pages/ExecutiveOverviewGeneralPT";
import ExecutiveOverviewGeneralES from "./pages/ExecutiveOverviewGeneralES";
import MayDemoIncentive from "./pages/MayDemoIncentive";
import ChannelManagerPlaybook from "./pages/ChannelManagerPlaybook";
import GlobalPartnerProgram from "./pages/GlobalPartnerProgram";
import CatholicChurchesFlyer from "./pages/CatholicChurchesFlyer";
import AISecuritySheet from "./pages/AISecuritySheet";
import LeySAC from "./pages/LeySAC";
import FelizVerano from "./pages/FelizVerano";
import HealthcareFlyer from "./pages/HealthcareFlyer";
import FinanceFlyer from "./pages/FinanceFlyer";
import InsuranceFlyer from "./pages/InsuranceFlyer";
import RealEstateFlyer from "./pages/RealEstateFlyer";
import LogisticsFlyer from "./pages/LogisticsFlyer";
import PolyRateCard from "./pages/PolyRateCard";
import InternationalCalling from "./pages/InternationalCalling";
import PartnerTechGuide from "./pages/PartnerTechGuide";
import PartnerTechGuideES from "./pages/PartnerTechGuideES";
import PartnerTechGuideESMadrid from "./pages/PartnerTechGuideESMadrid";
import DynamicsConnectorGuide from "./pages/DynamicsConnectorGuide";
import SalesforceConnectorGuide from "./pages/SalesforceConnectorGuide";
import GoContactHomepageGuide from "./pages/GoContactHomepageGuide";
import PerformanceGoalGuide from "./pages/PerformanceGoalGuide";
import InterviewOwnershipGuide from "./pages/InterviewOwnershipGuide";
import ZohoIntegrationDatasheet from "./pages/ZohoIntegrationDatasheet";
import SalesEngineerPlaybook from "./pages/SalesEngineerPlaybook";
import PartnerCertificationFAQ from "./pages/PartnerCertificationFAQ";
import DocumentIndex from "./pages/DocumentIndex";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AIAnalystFAQ />} />
          <Route path="/aianalyst" element={<GoEngageDatasheet />} />
          <Route path="/post-call-ai" element={<PostCallAIDatasheet />} />
          <Route path="/partner-intro-kit" element={<PartnerIntroKit />} />
          <Route path="/communicator" element={<CommunicatorDatasheet />} />
          <Route path="/communicator-partner" element={<CommunicatorPartner />} />
          <Route path="/bhive" element={<BhiveDatasheet />} />
          <Route path="/gocontact" element={<GoContactDatasheet />} />
          <Route path="/aianalyst-edit" element={<GoEngageDatasheetEditable />} />
          <Route path="/partner" element={<PartnerSuccessPlan />} />
          <Route path="/faq" element={<AIAnalystFAQ />} />
          <Route path="/inbound-faq" element={<GoEngageInboundFAQ />} />
          <Route path="/taskforce" element={<ImplementationTaskforce />} />
          <Route path="/user-guide" element={<BhiveUserGuide />} />
          <Route path="/company-overview" element={<CompanyOverview />} />
          <Route path="/executive-overview" element={<ExecutiveOverview />} />
          <Route path="/executive-overview-general" element={<ExecutiveOverviewGeneral />} />
          <Route path="/executive-overview-general-pt" element={<ExecutiveOverviewGeneralPT />} />
          <Route path="/executive-overview-general-es" element={<ExecutiveOverviewGeneralES />} />
          <Route path="/may-incentive" element={<MayDemoIncentive />} />
          <Route path="/channel-playbook" element={<ChannelManagerPlaybook />} />
          <Route path="/global-partner-program" element={<GlobalPartnerProgram />} />
          <Route path="/catholic-churches" element={<CatholicChurchesFlyer />} />
          <Route path="/ai-security" element={<AISecuritySheet />} />
          <Route path="/ley-sac" element={<LeySAC />} />
          <Route path="/feliz-verano" element={<FelizVerano />} />
          <Route path="/healthcare" element={<HealthcareFlyer />} />
          <Route path="/finance" element={<FinanceFlyer />} />
          <Route path="/insurance" element={<InsuranceFlyer />} />
          <Route path="/real-estate" element={<RealEstateFlyer />} />
          <Route path="/logistics" element={<LogisticsFlyer />} />
          <Route path="/poly-rate-card" element={<PolyRateCard />} />
          <Route path="/international-calling" element={<InternationalCalling />} />
          <Route path="/partner-tech-guide" element={<PartnerTechGuide />} />
          <Route path="/partner-tech-guide-es" element={<PartnerTechGuideES />} />
          <Route path="/partner-tech-guide-es-madrid" element={<PartnerTechGuideESMadrid />} />
          <Route path="/dynamics-connector-guide" element={<DynamicsConnectorGuide />} />
          <Route path="/salesforce-connector-guide" element={<SalesforceConnectorGuide />} />
          <Route path="/gocontact-homepage-guide" element={<GoContactHomepageGuide />} />
          <Route path="/performance-goal-guide" element={<PerformanceGoalGuide />} />
          <Route path="/interview-ownership-guide" element={<InterviewOwnershipGuide />} />
          <Route path="/zoho-integration" element={<ZohoIntegrationDatasheet />} />
          <Route path="/sales-engineer-playbook" element={<SalesEngineerPlaybook />} />
          <Route path="/partner-certification-faq" element={<PartnerCertificationFAQ />} />
          <Route path="/documents" element={<DocumentIndex />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
