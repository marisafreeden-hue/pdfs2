import React from "react";
import { Cloud, Building2, Bot, BarChart3 } from "lucide-react";
import "./GoEngageDatasheet.css";

const IconDefs = () => (
  <svg width="0" height="0" style={{ position: "absolute" }}>
    <defs>
      <linearGradient id="vf-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#43B5BF" />
        <stop offset="100%" stopColor="#27698F" />
      </linearGradient>
    </defs>
  </svg>
);

type Stat = { num: string; label: React.ReactNode };
type Challenge = { n: string; title: string; body: string };
type Outcome = { Icon: React.ComponentType<any>; title: string; sub: string; desc: string; items: Array<[string, string]> };

export interface VerticalFlyerProps {
  eyebrow: string;       // e.g. "Broadvoice for Healthcare"
  headlineLine1: string; // "Every Patient Interaction"
  headlineAccent: string; // italic accent word(s) on second line
  heroImage: string;
  pullQuote: string;     // italic intro
  intro: string;         // body paragraph
  stats: [Stat, Stat, Stat];
  sectionTitle: string;  // "Built for the <em>complexity</em>..."
  sectionTitleEm: string;
  sectionBody: string;
  challenges: Challenge[]; // 6
  page2Title: string;
  page2TitleEm: string;
  page2Body: string;
  solutions: [Outcome, Outcome, Outcome, Outcome];
  cta: string;
  sectionOffset?: number;
  flexibleSolutionsLabel?: string;
}

const PageHeader = () => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18, fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#888899", letterSpacing: "0.08em", textTransform: "uppercase" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" style={{ height: 20, width: "auto" }} />
    </div>
  </div>
);

const SolutionBlock: React.FC<Outcome> = ({ Icon, title, sub, desc, items }) => (
  <div style={{ background: "#FFFFFF", border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px", height: "100%", display: "flex", flexDirection: "column" }}>
    <div style={{ marginBottom: 4 }}>
      <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: "#43B5BF", fontFamily: "'Inter', sans-serif", marginBottom: 4 }}>{sub}</div>
      <div style={{ fontSize: 18, fontWeight: 500, color: "#1A1A2E", fontFamily: "'Instrument Sans', sans-serif", lineHeight: 1.1 }}>{title}</div>
    </div>
    <p style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.65, margin: "10px 0 10px", fontFamily: "'Inter', sans-serif" }}>{desc}</p>
    <div style={{ marginTop: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
      {items.map(([lead, rest], i) => (
        <div key={i} style={{ display: "grid", gridTemplateColumns: "10px 1fr", columnGap: 6, alignItems: "start" }}>
          <span style={{ color: "#43B5BF", fontSize: 10, lineHeight: 1.4 }}>•</span>
          <div style={{ fontFamily: "'Inter', sans-serif" }}>
            <div style={{ fontSize: 9.5, fontWeight: 700, color: "#1A1A2E", lineHeight: 1.4 }}>{lead}</div>
            {rest && <div style={{ fontSize: 9, color: "#555567", lineHeight: 1.45, marginTop: 1 }}>{rest}</div>}
          </div>
        </div>
      ))}
    </div>
  </div>
);

const ChallengeCard: React.FC<Challenge> = ({ n, title, body }) => (
  <div style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "10px 12px", background: "#FFFFFF" }}>
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4 }}>
      <span style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 18, fontWeight: 500, background: "linear-gradient(90deg, #43B5BF, #27698F)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", lineHeight: 1 }}>{n}</span>
      <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.25 }}>{title}</div>
    </div>
    <p style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.5, margin: 0, fontFamily: "'Inter', sans-serif" }}>{body}</p>
  </div>
);

const VerticalFlyer: React.FC<VerticalFlyerProps> = (p) => {
  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={() => window.print()}>Export as PDF</button>
      <IconDefs />

      {/* ===== PAGE 1 ===== */}
      <div className="page" style={{ padding: 0 }}>
        <div style={{ position: "relative", width: "100%", height: "3in", overflow: "hidden" }}>
          <img src={p.heroImage} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(10,20,40,0.55) 0%, rgba(10,20,40,0.35) 45%, rgba(39,105,143,0.85) 100%)" }} />
          <div style={{ position: "absolute", top: 22, left: "0.625in", right: "0.625in", display: "flex", alignItems: "center", gap: 14 }}>
            <img src="/assets/broadvoice-logo.png" alt="Broadvoice" style={{ height: 20, width: "auto", filter: "brightness(0) invert(1)" }} />
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: "55%", background: "linear-gradient(180deg, rgba(8,16,32,0) 0%, rgba(8,16,32,0.65) 55%, rgba(8,16,32,0.92) 100%)", pointerEvents: "none" }} />
          <div style={{ position: "absolute", bottom: 56, left: "0.625in", right: "0.625in" }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.22em", textTransform: "uppercase", color: "#A8E5EB", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>
              {p.eyebrow}
            </div>
            <h1 style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 44, fontWeight: 500, lineHeight: 1.05, letterSpacing: "-0.02em", color: "#FFFFFF", margin: 0 }}>
              {p.headlineLine1}<br />
              <em style={{ fontFamily: "'Besley', serif", fontWeight: 400, fontStyle: "italic", background: "linear-gradient(90deg, #43B5BF, #A8E5EB, #C686F8)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent" }}>{p.headlineAccent}</em>
            </h1>
          </div>
        </div>

        <div style={{ padding: "0.45in 0.625in 0.7in" }}>
          <p style={{ fontFamily: "'Besley', Georgia, serif", fontSize: 15, fontStyle: "italic", color: "#1A1A2E", lineHeight: 1.4, margin: "0 0 14px 0", maxWidth: "6.5in" }}>
            {p.pullQuote}
          </p>
          <p style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, margin: "0 0 18px 0", fontFamily: "'Inter', sans-serif" }}>
            {p.intro}
          </p>

          <div className="stats-row" style={{ marginBottom: 22, marginTop: -20 }}>
            {p.stats.map((s, i) => (
              <div key={i} className="stat-item">
                <div className="num">{s.num}</div>
                <div className="lbl">{s.label}</div>
              </div>
            ))}
          </div>

          <h2 className="section-title" style={{ marginTop: p.sectionOffset ?? -15 }}>
            {p.sectionTitle} <em>{p.sectionTitleEm}</em>
          </h2>
          <p className="section-body" style={{ maxWidth: "100%" }}>{p.sectionBody}</p>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 6 }}>
            {p.challenges.map((c, i) => <ChallengeCard key={i} {...c} />)}
          </div>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page">
        <PageHeader />

        <h2 className="section-title">{p.page2Title} <em>{p.page2TitleEm}</em></h2>
        <p className="section-body" style={{ maxWidth: "100%", marginBottom: 14 }}>{p.page2Body}</p>

        <div style={{ background: "linear-gradient(130.54deg, #FCF6FF 5.82%, #E8FCFF 113.26%)", border: "1px solid #E2E2EC", borderRadius: 12, padding: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {p.solutions.map((s, i) => <SolutionBlock key={i} {...s} />)}
        </div>

        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginTop: 28, marginBottom: 6, textAlign: "center" }}>Why Broadvoice</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginTop: 6, marginBottom: 6 }}>
          {[
            { t: "Easy to deploy", d: "Phased modernization, no rip-and-replace" },
            { t: "Easy to manage", d: "Non-technical staff handle day-to-day changes" },
            { t: "Easy to own", d: "Predictable pricing, 24/7 U.S.-based support" },
            { t: "UCaaS + CCaaS", d: p.flexibleSolutionsLabel ?? "Flexible Solutions for Healthcare Organizations" },
          ].map(({ t, d }, i) => (
            <div key={i} style={{ border: "1px solid #D0E8EA", borderRadius: 8, padding: "10px 12px", background: "rgba(67,181,191,0.04)" }}>
              <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "#27698F", marginBottom: 3, lineHeight: 1.15 }}>{t}</div>
              <div style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.45, fontFamily: "'Inter', sans-serif" }}>{d}</div>
            </div>
          ))}
        </div>


        <div className="about-section" style={{ position: "static", maxWidth: "100%", marginTop: 48 }}>
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent CX solutions for midmarket organizations—empowering business teams to design modern, frictionless customer experiences with AI that's practical, easy to use, and purpose-built for how they work.
          </p>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default VerticalFlyer;

// Shared solution blocks (per vertical descriptions injected by pages)
export const buildSolutions = (descs: { ucaas: string; ccaas: string; ai: string; insights: string }, items: { ucaas: Array<[string,string]>; ccaas: Array<[string,string]>; ai: Array<[string,string]>; insights: Array<[string,string]> }): [Outcome, Outcome, Outcome, Outcome] => ([
  { Icon: Cloud, title: "b-hive", sub: "UCaaS", desc: descs.ucaas, items: items.ucaas },
  { Icon: Building2, title: "GoContact", sub: "CCaaS", desc: descs.ccaas, items: items.ccaas },
  { Icon: Bot, title: "Engage", sub: "AI Voice", desc: descs.ai, items: items.ai },
  { Icon: BarChart3, title: "Analyst", sub: "AI Insights", desc: descs.insights, items: items.insights },
]);
