import React from "react";
import VerticalFlyer, { buildSolutions } from "./VerticalFlyer";
import hero from "@/assets/hero-insurance.jpg.asset.json";

const InsuranceFlyer: React.FC = () => (
  <VerticalFlyer
    eyebrow="Broadvoice for Insurance"
    headlineLine1="Faster Answers When"
    headlineAccent="Policyholders Need Them"
    heroImage={hero.url}
    pullQuote="Reduce service friction across claims, billing, renewals, and policyholder support."
    intro="Broadvoice helps insurance organizations improve policyholder and agent experience, reduce operational complexity, and support distributed claims, service, sales, and back-office teams with unified communications, contact center, text messaging, agentic AI, and deep analytics."
    stats={[
      { num: "99.999%", label: <><strong>Platform uptime SLA</strong>for first-notice-of-loss lines, billing queues, and policyholder service — even during catastrophe surges.</> as any },
      { num: "80%", label: <><strong>Self-service success rate</strong>when routine claim status, billing, and policy inquiries are routed to agentic AI.</> as any },
      { num: "<2 mo", label: <><strong>Payback on AI</strong>when deflection, AHT, and after-hours coverage are accounted for.</> as any },
    ]}
    sectionTitle="Built for the"
    sectionTitleEm="complexity of policyholder service"
    sectionBody="Insurance leaders connect distributed teams across claims, billing, policy service, and agent support — under unpredictable volume from CAT events, renewal cycles, and policyholder needs."
    challenges={[
      { n: "01", title: "Claims responsiveness", body: "Policyholders calling after a loss expect fast, empathetic answers. Hold times damage trust at the worst possible moment." },
      { n: "02", title: "CAT-event call surges", body: "Storms, fires, and recalls create sudden 10x volume spikes legacy systems can't absorb without melting down." },
      { n: "03", title: "Billing & renewal volume", body: "Premium, EFT, and renewal questions consume capacity that should go to claims and producer support." },
      { n: "04", title: "Distributed adjusters", body: "Field and remote adjusters need a business line, recording, and SMS that work from any device, any location." },
      { n: "05", title: "Agent & producer support", body: "Captive and independent producers need fast access to underwriting, service, and back-office teams." },
      { n: "06", title: "Service visibility", body: "Leaders need queue, workload, and bottleneck insight in real time — across claims, service, and sales." },
    ]}
    page2Title="A unified platform for"
    page2TitleEm="every policyholder moment"
    page2Body="Four integrated solutions — phone system, contact center, agentic AI, and analytics — built for the surges, sensitivity, and scale of insurance operations."
    solutions={buildSolutions(
      {
        ucaas: "Connect claims, service, sales, underwriting, and operations teams across offices and remote work.",
        ccaas: "Policyholder and claimant contact center with consistent routing, recording, and screen pop.",
        ai: "Agentic AI that handles routine policy, billing, and status inquiries so licensed staff focus on complex needs.",
        insights: "Real-time visibility into claims workload, queue pressure, and service bottlenecks.",
      },
      {
        ucaas: [["Field-ready", "adjusters take calls from any device"], ["Recording", "compliant capture across teams"], ["Bubble texting", "adjuster, payment, and renewal reminders"]],
        ccaas: [["Surge-ready routing", "elastic capacity for CAT events"], ["Policy screen pop", "policy & loss context before answer"], ["Supervisor view", "live queue & QA tools"]],
        ai: [["Claim status & FNOL intake", "24/7 self-service"], ["Billing & payments", "secure routine handling"], ["Warm escalation", "to licensed humans when needed"]],
        insights: [["Workload heatmaps", "by line, queue & location"], ["Service patterns", "topic & resolution trends"], ["Plain-language reports", "no analyst required"]],
      }
    )}
    cta="Connect with Broadvoice to improve policyholder service, reduce operational friction, and modernize insurance communications."
    flexibleSolutionsLabel="Flexible Solutions for Insurance Organizations"
    sectionOffset={10}
  />
);

export default InsuranceFlyer;
