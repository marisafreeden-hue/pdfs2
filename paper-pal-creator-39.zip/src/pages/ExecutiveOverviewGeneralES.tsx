import React from "react";
import { Lock, Headphones, Sparkles, TrendingUp, Server } from "lucide-react";
import "./GoEngageDatasheet.css";

import logoPfizer from "@/assets/logo-pfizer.png.asset.json";
import logoLoreal from "@/assets/logo-loreal.png.asset.json";
import logoUps from "@/assets/logo-ups.png.asset.json";
import logoToyota from "@/assets/logo-toyota.png.asset.json";
import logoHertz from "@/assets/logo-hertz.png.asset.json";
import logoSiemens from "@/assets/logo-siemens.png.asset.json";

import jeffPritle from "@/assets/jeff-pritle.jpeg.asset.json";
import mollyLozano from "@/assets/molly-lozano.png.asset.json";
import ricardoCosta from "@/assets/ricardo-costa.png.asset.json";
import rodrigoJaramillo from "@/assets/rodrigo-jaramillo.jpeg.asset.json";
import jimMurphy from "@/assets/jim-murphy.jpeg.asset.json";
import samGhahremanpour from "@/assets/sam-ghahremanpour.jpeg.asset.json";
import georgeMitsopoulos from "@/assets/george-mitsopoulos.jpeg.asset.json";
import gurdipJande from "@/assets/gurdip-jande.jpeg.asset.json";
import marisaFreeden from "@/assets/marisa-freeden.jpeg.asset.json";
import worldMap from "@/assets/world-dot-map.png.asset.json";

const SECTION_LABEL: React.CSSProperties = {
  fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase",
  color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10,
};

const PersonCard: React.FC<{ name: string; title: string; photo?: string }> = ({ name, title, photo }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
    {photo ? (
      <img src={photo} alt={name} style={{ width: 44, height: 44, borderRadius: "50%", objectFit: "cover", border: "1px solid #E2E2EC", flexShrink: 0 }} />
    ) : (
      <div style={{
        width: 44, height: 44, borderRadius: "50%",
        background: "linear-gradient(135deg, #43B5BF 0%, #27698F 100%)",
        border: "1px solid #E2E2EC", flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "'Inter', sans-serif",
      }}>
        {name.split(" ").map(n => n[0]).slice(0, 2).join("")}
      </div>
    )}
    <div style={{ minWidth: 0 }}>
      <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.2 }}>{name}</div>
      <div style={{ fontSize: 9, color: "#555567", fontFamily: "'Inter', sans-serif", lineHeight: 1.3, marginTop: 1 }}>{title}</div>
    </div>
  </div>
);

const Footer: React.FC = () => (
  <>
    <div className="page-bottom-cta" style={{ bottom: "0.3in" }}>
      <img src="/assets/learn-more-cta.png" alt="Más información en broadvoice.com" style={{ height: 53 }} />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
    </div>
  </>
);

const Logo: React.FC = () => (
  <div className="logo" style={{ marginBottom: 24 }}>
    <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
  </div>
);

const ExecutiveOverviewGeneralES: React.FC = () => {
  const handleExportPDF = () => window.print();

  const executives = [
    { name: "Jim Murphy", title: "CEO y Cofundador", photo: jimMurphy.url },
    { name: "Sam Ghahremanpour", title: "Presidente", photo: samGhahremanpour.url },
    { name: "George Mitsopoulos", title: "COO", photo: georgeMitsopoulos.url },
    { name: "Gurdip Jande", title: "Chief Product Officer", photo: gurdipJande.url },
    { name: "Marisa Freeden", title: "Chief Marketing Officer", photo: marisaFreeden.url },
    { name: "Jeff Pritle", title: "Chief Financial Officer", photo: jeffPritle.url },
  ];

  const salesLeaders = [
    { name: "Molly Lozano", title: "Channel Chief, EE. UU.", photo: mollyLozano.url },
    { name: "Ricardo Costa", title: "VP de Ventas, EMEA", photo: ricardoCosta.url },
    { name: "Rodrigo Jaramillo", title: "Head of Sales, LATAM", photo: rodrigoJaramillo.url },
  ];

  const facts = [
    { label: "Fundada", value: "2005" },
    { label: "Sede", value: "Northridge, California" },
    { label: "Estructura", value: "Capital privado, respaldada por Private Equity" },
    { label: "Actividad", value: "CCaaS y Experiencia de Cliente con IA" },
    { label: "Clientes", value: "Miles en Norteamérica, EMEA y LATAM" },
    { label: "Perfil", value: "Rentable a nivel operativo, con crecimiento sostenido" },
  ];

  const customerLogos = [
    { src: logoPfizer.url, alt: "Pfizer" },
    { src: logoLoreal.url, alt: "L'Oréal" },
    { src: logoUps.url, alt: "UPS" },
    { src: logoToyota.url, alt: "Toyota" },
    { src: logoHertz.url, alt: "Hertz" },
    { src: logoSiemens.url, alt: "Siemens" },
  ];

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn no-print" onClick={handleExportPDF}>
        Exportar como PDF
      </button>

      {/* ============ PÁGINA 1: Visión Ejecutiva + Liderazgo ============ */}
      <div className="page page-1" style={{ position: "relative", overflow: "hidden" }}>
        <Logo />

        <h1 className="hero-headline" style={{ fontSize: 40, marginBottom: 6, lineHeight: 1.1 }}>
          Visión <em>Ejecutiva</em>
        </h1>
        <p className="hero-desc" style={{ maxWidth: "100%", fontSize: 12, lineHeight: 1.6, marginBottom: 14 }}>
          Broadvoice es una compañía de capital privado, rentable a nivel operativo, que ofrece soluciones de contact center en la nube (CCaaS) y de experiencia de cliente impulsadas por Inteligencia Artificial en Norteamérica, EMEA y LATAM.
        </p>

        {/* Franja de datos */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 0,
          background: "#F8FAFB",
          border: "1px solid #E2E2EC",
          borderRadius: 10,
          padding: "14px 18px",
          marginBottom: 14,
        }}>
          {facts.map((f, i) => (
            <div key={i} style={{
              padding: "6px 14px",
              borderRight: (i % 3 !== 2) ? "1px solid #E2E2EC" : "none",
              borderBottom: i < 3 ? "1px solid #E2E2EC" : "none",
            }}>
              <div style={{ fontSize: 7.5, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#888899", fontFamily: "'Inter', sans-serif", marginBottom: 3 }}>{f.label}</div>
              <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.3 }}>{f.value}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 18, marginBottom: 18 }}>
          <div>
            <div style={SECTION_LABEL}>Sobre la Compañía</div>
            <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
              <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, marginBottom: 12, fontFamily: "'Inter', sans-serif" }}>
                Desde hace más de dos décadas, Broadvoice acompaña a las empresas en la modernización de sus comunicaciones, en la mejora de la relación con sus clientes y en el soporte a equipos distribuidos, con tecnología cloud fiable y escalable.
              </p>
              <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                Con el respaldo de inversión de Private Equity y una sólida base financiera, Broadvoice combina la agilidad de una tecnológica enfocada en la innovación con la estabilidad y el gobierno corporativo propios de un partner de confianza en comunicaciones empresariales.
              </p>
            </div>

            {/* Misión */}
            <div style={{ marginTop: 14 }}>
              <div style={SECTION_LABEL}>Misión</div>
              <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
                <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                  Dotar a las organizaciones de soluciones de comunicación inteligentes que generen experiencias de cliente excepcionales, refuercen la colaboración de los equipos y aporten resultados medibles, integrando contact center e Inteligencia Artificial en una única plataforma.
                </p>
              </div>
            </div>

            {/* Mapa de presencia global */}
            <div style={{ marginTop: 16 }}>
              <div style={SECTION_LABEL}>Presencia Global</div>
              <div style={{ padding: 0, marginTop: -32 }}>
                <div style={{
                  position: "relative",
                  width: "100%",
                  aspectRatio: "2 / 1",
                  overflow: "visible",
                }}>
                  <img
                    src={worldMap.url}
                    alt="Presencia global"
                    style={{
                      position: "absolute", inset: 0, width: "100%", height: "100%",
                      objectFit: "contain", objectPosition: "center top", opacity: 0.18,
                    }}
                  />
                  {[
                    { name: "Estados Unidos", x: 22, y: 42, labelPos: "bottom" as const },
                    { name: "Colombia", x: 30, y: 60, labelPos: "bottom" as const },
                    { name: "Portugal", x: 45.2, y: 39, labelPos: "left" as const },
                    { name: "España", x: 48.2, y: 39, labelPos: "right" as const },
                  ].map((loc) => {
                    const labelStyle: React.CSSProperties = {
                      position: "absolute",
                      fontSize: 8, fontWeight: 700, color: "#1A1A2E",
                      fontFamily: "'Inter', sans-serif", whiteSpace: "nowrap",
                      letterSpacing: "0.04em", textTransform: "uppercase",
                    };
                    if (loc.labelPos === "left") {
                      Object.assign(labelStyle, { right: "calc(100% + 6px)", top: "50%", transform: "translateY(-50%)" });
                    } else if (loc.labelPos === "right") {
                      Object.assign(labelStyle, { left: "calc(100% + 6px)", top: "50%", transform: "translateY(-50%)" });
                    } else {
                      Object.assign(labelStyle, { left: "50%", top: "calc(100% + 4px)", transform: "translateX(-50%)" });
                    }
                    return (
                      <div key={loc.name} style={{
                        position: "absolute", left: `${loc.x}%`, top: `${loc.y}%`,
                        transform: "translate(-50%, -50%)",
                      }}>
                        <span style={{
                          display: "block", width: 6, height: 6, borderRadius: "50%",
                          background: "#43B5BF",
                          boxShadow: "0 0 0 2px rgba(67,181,191,0.22), 0 0 0 4px rgba(67,181,191,0.10)",
                        }} />
                        <span style={labelStyle}>{loc.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          <div>
            <div style={SECTION_LABEL}>Liderazgo Ejecutivo</div>
            <div style={{
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              {executives.map((p, i) => <PersonCard key={i} {...p} />)}
            </div>
            <div style={{ ...SECTION_LABEL, marginTop: 14 }}>Liderazgo Comercial</div>
            <div style={{
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              {salesLeaders.map((p, i) => <PersonCard key={i} {...p} />)}
            </div>
          </div>
        </div>

        <Footer />
      </div>

      {/* ============ PÁGINA 2: Plataforma, Confianza, Clientes ============ */}
      <div className="page page-2" style={{ position: "relative", overflow: "hidden" }}>
        <Logo />

        <svg width="0" height="0" style={{ position: "absolute" }}>
          <defs>
            <linearGradient id="exec-icon-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#43B5BF" />
              <stop offset="100%" stopColor="#27698F" />
            </linearGradient>
          </defs>
        </svg>

        {/* 1. Portfolio de Soluciones */}
        <div style={SECTION_LABEL}>Portfolio de Soluciones</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14, marginBottom: 18 }}>
          {[
            {
              Icon: Headphones, title: "Contact Center", sub: "CCaaS",
              items: [
                "Atención omnicanal",
                "Enrutamiento y gestión de colas inteligente",
                "Optimización del personal y analítica avanzada",
                "Herramientas de supervisión y rendimiento",
              ],
            },
            {
              Icon: Sparkles, title: "Experiencia de Cliente con IA", sub: "GoAI Suite",
              items: [
                "IA conversacional y automatización",
                "Asistencia al agente con IA",
                "Resúmenes e insights automáticos",
                "Inteligencia aplicada a la experiencia de cliente",
              ],
            },
          ].map((c, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <c.Icon size={20} style={{ stroke: "url(#exec-icon-grad)", flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>{c.title}</div>
                  <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.12em", color: "#43B5BF", fontFamily: "'Inter', sans-serif" }}>{c.sub}</div>
                </div>
              </div>
              {c.items.map((b, j) => (
                <div key={j} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                  <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.55 }}>•</span>
                  <span style={{ fontSize: 11, color: "#555567", lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{b}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* 2 + 3. Seguridad, Cumplimiento y Fiabilidad */}
        <div style={SECTION_LABEL}>Seguridad, Cumplimiento y Fiabilidad</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 18 }}>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Lock size={16} style={{ color: "#43B5BF" }} />
              <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Seguridad y Cumplimiento</div>
            </div>
            {[
              "Entorno auditado SOC 2 Tipo 1, alineado con controles reconocidos por la industria",
              "Flujos conformes con HIPAA para datos sanitarios protegidos",
              "Prácticas de privacidad y tratamiento de datos alineadas con el RGPD",
            ].map((b, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.6 }}>•</span>
                <span style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
              </div>
            ))}
          </div>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Server size={16} style={{ color: "#43B5BF" }} />
              <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Fiabilidad de la Plataforma</div>
            </div>
            {[
              "Arquitectura cloud de nivel empresarial, diseñada para la resiliencia",
              "Infraestructura de alta disponibilidad, con redundancia geográfica",
              "Monitorización proactiva y excelencia operativa",
              "Planes sólidos de recuperación ante desastres y continuidad de negocio",
            ].map((b, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.6 }}>•</span>
                <span style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Solidez Financiera */}
        <div style={SECTION_LABEL}>Solidez y Estabilidad Financiera</div>
        <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px", background: "#F8FAFB", marginBottom: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
            <TrendingUp size={16} style={{ color: "#43B5BF" }} />
            <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Rentable a nivel operativo. Respaldada por Private Equity.</div>
          </div>
          <p style={{ fontSize: 12, color: "#555567", lineHeight: 1.65, margin: 0, fontFamily: "'Inter', sans-serif" }}>
            Rentable a nivel operativo, con una larga trayectoria de crecimiento sostenido y una gestión financiera disciplinada. El respaldo de Private Equity aporta capital estratégico y los recursos necesarios para seguir invirtiendo en producto, infraestructura, seguridad y éxito del cliente.
          </p>
        </div>

        {/* 5. Por qué Broadvoice */}
        <div style={SECTION_LABEL}>Por qué las Organizaciones Eligen Broadvoice</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginBottom: 18 }}>
          {[
            { t: "Solidez Financiera", d: "Rentable a nivel operativo y respaldada por Private Equity" },
            { t: "Confianza y Seguridad", d: "Controles y gobierno alineados con SOC 2" },
            { t: "Fiabilidad", d: "Infraestructura de nivel empresarial" },
            { t: "Foco en el Cliente", d: "Equipos dedicados de implantación y éxito" },
            { t: "Innovación", d: "Inversión continua en IA y CX" },
          ].map((w, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "12px 13px" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 4 }}>{w.t}</div>
              <div style={{ fontSize: 10, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{w.d}</div>
            </div>
          ))}
        </div>

        {/* 6. Logos */}
        <div style={SECTION_LABEL}>Marcas de Referencia que Confían en Broadvoice</div>
        <div style={{
          border: "1px solid #E2E2EC", borderRadius: 10, padding: "4px 16px",
          display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12,
          alignItems: "center", justifyItems: "center",
          background: "#FFFFFF",
          marginTop: -2,
        }}>
          {customerLogos.map((l, i) => {
            const isSiemens = l.alt === "Siemens";
            return (
              <img key={i} src={l.src} alt={l.alt}
                style={{
                  maxHeight: isSiemens ? 50 : 34,
                  maxWidth: "100%",
                  objectFit: "contain",
                  filter: "grayscale(100%)",
                }} />
            );
          })}
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default ExecutiveOverviewGeneralES;
