import React from "react";
import { Check } from "lucide-react";
import "./GoEngageDatasheet.css";

type Row = { country: string; landline: boolean; mobile: boolean };

const left: Row[] = [
  { country: "American Samoa", landline: true, mobile: false },
  { country: "Andorra", landline: true, mobile: false },
  { country: "Argentina", landline: true, mobile: false },
  { country: "Australia", landline: true, mobile: false },
  { country: "Belgium", landline: true, mobile: false },
  { country: "Brazil", landline: true, mobile: false },
  { country: "Brunei Darussalam", landline: true, mobile: false },
  { country: "Canada", landline: true, mobile: true },
  { country: "Chile", landline: true, mobile: false },
  { country: "China", landline: true, mobile: true },
  { country: "Colombia", landline: true, mobile: false },
  { country: "Costa Rica", landline: true, mobile: false },
  { country: "Croatia", landline: true, mobile: false },
  { country: "Cyprus", landline: true, mobile: true },
  { country: "Czech Republic", landline: true, mobile: false },
  { country: "Denmark", landline: true, mobile: true },
  { country: "France", landline: true, mobile: false },
  { country: "French Guiana", landline: true, mobile: true },
  { country: "Germany", landline: true, mobile: true },
  { country: "Greece", landline: true, mobile: false },
  { country: "Guadeloupe", landline: true, mobile: false },
  { country: "Hong Kong", landline: true, mobile: true },
  { country: "Hungary", landline: true, mobile: true },
  { country: "Iceland", landline: true, mobile: true },
  { country: "India", landline: true, mobile: true },
  { country: "Ireland", landline: true, mobile: true },
  { country: "Israel", landline: true, mobile: true },
  { country: "Italy", landline: true, mobile: false },
  { country: "Japan", landline: true, mobile: false },
  { country: "Kazakstan", landline: true, mobile: false },
];

const right: Row[] = [
  { country: "Luxembourg", landline: true, mobile: true },
  { country: "Malaysia", landline: true, mobile: true },
  { country: "Malta", landline: true, mobile: true },
  { country: "Martinique", landline: true, mobile: false },
  { country: "Mexico", landline: true, mobile: true },
  { country: "Mongolia", landline: true, mobile: true },
  { country: "N. Mariana Islands", landline: true, mobile: false },
  { country: "Netherlands", landline: true, mobile: false },
  { country: "New Zealand", landline: true, mobile: false },
  { country: "Norway", landline: true, mobile: true },
  { country: "Panama", landline: true, mobile: false },
  { country: "Peru", landline: true, mobile: true },
  { country: "Poland", landline: true, mobile: false },
  { country: "Portugal", landline: true, mobile: false },
  { country: "Puerto Rico", landline: true, mobile: true },
  { country: "Romania", landline: true, mobile: true },
  { country: "Singapore", landline: true, mobile: true },
  { country: "Slovak Republic", landline: true, mobile: true },
  { country: "South Korea", landline: true, mobile: true },
  { country: "Spain", landline: true, mobile: false },
  { country: "Sweden", landline: true, mobile: true },
  { country: "Switzerland", landline: true, mobile: false },
  { country: "Taiwan", landline: true, mobile: false },
  { country: "Thailand", landline: true, mobile: true },
  { country: "Turkey", landline: true, mobile: false },
  { country: "United Kingdom", landline: true, mobile: true },
  { country: "United States", landline: true, mobile: true },
  { country: "Vatican City State", landline: true, mobile: false },
  { country: "Venezuela", landline: true, mobile: true },
  { country: "Virgin Islands", landline: true, mobile: false },
];

const Mark = ({ on }: { on: boolean }) =>
  on ? (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: 14,
        height: 14,
        borderRadius: 4,
        background: "linear-gradient(135deg, #43B5BF 0%, #27698F 100%)",
        color: "#fff",
        WebkitPrintColorAdjust: "exact",
        printColorAdjust: "exact",
      }}
    >
      <Check size={9} strokeWidth={3.5} />
    </span>
  ) : (
    <span style={{ color: "#C9C9D4", fontSize: 9 }}>—</span>
  );

const RateTable: React.FC<{ rows: Row[] }> = ({ rows }) => (
  <table className="outcomes-table" style={{ tableLayout: "fixed", marginBottom: 0 }}>
    <colgroup>
      <col style={{ width: "56%" }} />
      <col style={{ width: "22%" }} />
      <col style={{ width: "22%" }} />
    </colgroup>
    <thead>
      <tr>
        <th style={{ fontSize: 6, padding: "6px 6px" }}>Country</th>
        <th style={{ fontSize: 6, textAlign: "center", padding: "6px 4px" }}>Land</th>
        <th style={{ fontSize: 6, textAlign: "center", padding: "6px 4px" }}>Mob*</th>
      </tr>
    </thead>
    <tbody>
      {rows.map((r) => (
        <tr key={r.country}>
          <td style={{ whiteSpace: "normal", width: "auto", fontSize: 7.5, lineHeight: 1.2, padding: "4px 6px" }}>{r.country}</td>
          <td style={{ textAlign: "center", padding: "4px 4px" }}>
            <Mark on={r.landline} />
          </td>
          <td style={{ textAlign: "center", padding: "4px 4px" }}>
            <Mark on={r.mobile} />
          </td>
        </tr>
      ))}
    </tbody>
  </table>
);

const InternationalCalling: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="hero" style={{ marginBottom: 0 }}>
          <h1 className="hero-headline" style={{ fontSize: 40, lineHeight: 1.05 }}>
            International <em>Calling</em>
          </h1>
          <p className="hero-body" style={{ marginTop: 6 }}>Unlimited Global Extensions</p>
          <p className="hero-desc" style={{ marginTop: 2 }}>
            Includes calling to the following countries:
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginTop: 12 }}>
          <RateTable rows={left.slice(0, 15)} />
          <RateTable rows={left.slice(15)} />
          <RateTable rows={right.slice(0, 15)} />
          <RateTable rows={right.slice(15)} />
        </div>

        <p
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: 8,
            color: "#888899",
            marginTop: 10,
          }}
        >
          * Satellite phone numbers excluded.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginTop: 34 }}>
          {[
            {
              t: "One predictable rate",
              b: "Unlimited calling to 60 destinations is bundled into the Global Extension — no per-minute surprises on the invoice.",
            },
            {
              t: "Built for distributed teams",
              b: "Give remote employees, contractors, and international offices the same extension experience they'd have in headquarters.",
            },
            {
              t: "Landline and mobile coverage",
              b: "Mobile termination is included across major markets, so teams can reach customers on whichever number they answer.",
            },
          ].map((c) => (
            <div
              key={c.t}
              style={{
                border: "1px solid #E2E2EC",
                borderRadius: 12,
                padding: "14px 16px",
                background: "#FFFFFF",
              }}
            >
              <div
                style={{
                  width: 26,
                  height: 3,
                  borderRadius: 2,
                  background: "linear-gradient(90deg, #43B5BF, #27698F)",
                  WebkitPrintColorAdjust: "exact",
                  printColorAdjust: "exact",
                  marginBottom: 10,
                }}
              />
              <div
                style={{
                  fontFamily: "'Instrument Sans', sans-serif",
                  fontSize: 12,
                  fontWeight: 700,
                  color: "#1A1A2E",
                  marginBottom: 5,
                }}
              >
                {c.t}
              </div>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 9, lineHeight: 1.55, color: "#555567" }}>
                {c.b}
              </div>
            </div>
          ))}
        </div>


        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default InternationalCalling;
