import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>MS Dynamics Connector for GoContact · Installation Guide · v1.0</div>
    <div>© Broadvoice 2026</div>
  </div>
);

const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}
  </h2>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Ordered: React.FC<{ items: React.ReactNode[]; start?: number }> = ({ items, start }) => (
  <ol
    start={start}
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.65,
      paddingLeft: 22,
      margin: "6px 0 10px",
      listStyleType: "decimal",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 3 }}>
        {it}
      </li>
    ))}
  </ol>
);

const Bullets: React.FC<{ items: React.ReactNode[] }> = ({ items }) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      paddingLeft: 20,
      margin: "6px 0 10px",
      listStyleType: "disc",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 3 }}>
        {it}
      </li>
    ))}
  </ul>
);

const Callout: React.FC<{ children: React.ReactNode; tone?: "info" | "warn" }> = ({
  children,
  tone = "info",
}) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: tone === "warn" ? "#8a4a00" : "#1A1A2E",
      background: tone === "warn" ? "#FFF6E5" : "#EEF7F8",
      borderLeft: `3px solid ${tone === "warn" ? "#D97706" : "#43B5BF"}`,
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const StepCard: React.FC<{ num: string; title: string; children: React.ReactNode }> = ({
  num,
  title,
  children,
}) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      padding: "14px 18px 10px",
      marginBottom: 14,
      background: "#FFFFFF",
    }}
  >
    <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 4 }}>
      <span
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 10,
          fontWeight: 700,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "#43B5BF",
        }}
      >
        Step {num}
      </span>
    </div>
    <h2
      className="section-title"
      style={{ fontSize: 20, margin: "0 0 6px", lineHeight: 1.2, display: "block" }}
    >
      {title}
    </h2>
    {children}
  </div>
);

const ConfigTable: React.FC = () => {
  const rows: [string, React.ReactNode][] = [
    ["Name", "GoContact Connector"],
    ["Label", "GoContact"],
    [
      "Channel URL",
      <span style={{ wordBreak: "break-all" }}>
        https://eu.cloud.gocontact.com/ccaas-crm-embed-ui/?tenantId=0f181b9a-0c13-422b-ae38-418f6c389288
      </span>,
    ],
    ["Enable Outbound Communication", "Yes"],
    ["Channel Order", "1"],
    ["Trusted Domain", "eu.cloud.gocontact.com"],
    [
      "Select Unified Interface Apps",
      <>
        Select the Dynamics 365 apps where the connector should appear (e.g., Customer
        Service Hub, Sales Hub). <strong>This selection is required to save the
        configuration.</strong>
      </>,
    ],
    ["API Version", "1"],
  ];
  return (
    <div
      className="rounded-table"
      style={{
        border: "1px solid #E2E2EC",
        borderRadius: 8,
        overflow: "hidden",
        margin: "8px 0 12px",
      }}
    >
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontFamily: "'Inter', sans-serif",
          fontSize: 10.5,
          tableLayout: "fixed",
        }}
      >
        <colgroup>
          <col style={{ width: "32%" }} />
          <col style={{ width: "68%" }} />
        </colgroup>
        <thead>
          <tr style={{ background: "#F3F3F8" }}>
            {["Field", "Value"].map((h) => (
              <th
                key={h}
                style={{
                  padding: "9px 12px",
                  textAlign: "left",
                  fontSize: 10,
                  fontWeight: 700,
                  letterSpacing: "0.07em",
                  textTransform: "uppercase",
                  color: "#555567",
                  borderBottom: "2px solid #E2E2EC",
                }}
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map(([f, v], i) => (
            <tr key={i} style={{ background: i % 2 === 0 ? "#FFFFFF" : "#FAFAFA" }}>
              <td
                style={{
                  padding: "10px 12px",
                  color: "#1A1A2E",
                  fontWeight: 700,
                  borderBottom: i === rows.length - 1 ? "none" : "1px solid #E2E2EC",
                  verticalAlign: "top",
                  lineHeight: 1.45,
                }}
              >
                {f}
              </td>
              <td
                style={{
                  padding: "10px 12px",
                  color: "#555567",
                  borderBottom: i === rows.length - 1 ? "none" : "1px solid #E2E2EC",
                  verticalAlign: "top",
                  lineHeight: 1.45,
                }}
              >
                {v}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const ChecklistGroup: React.FC<{ title: string; items: string[] }> = ({ title, items }) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      padding: "12px 16px 10px",
      marginBottom: 10,
      background: "#FFFFFF",
    }}
  >
    <h3
      style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: 12,
        fontWeight: 700,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: "#27698F",
        margin: "0 0 8px",
      }}
    >
      {title}
    </h3>
    <ul
      style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: 12,
        color: "#555567",
        lineHeight: 1.55,
        paddingLeft: 0,
        margin: 0,
        listStyle: "none",
      }}
    >
      {items.map((it, i) => (
        <li
          key={i}
          style={{
            display: "flex",
            alignItems: "flex-start",
            gap: 8,
            marginBottom: 5,
          }}
        >
          <span
            style={{
              flex: "0 0 auto",
              width: 12,
              height: 12,
              border: "1.5px solid #43B5BF",
              borderRadius: 3,
              marginTop: 3,
            }}
          />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  </div>
);

const TroubleshootingCard: React.FC<{ title: string; items: string[] }> = ({ title, items }) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderLeft: "4px solid #27698F",
      borderRadius: 6,
      padding: "12px 16px 8px",
      marginBottom: 10,
      background: "#FFFFFF",
    }}
  >
    <h3
      style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: 13,
        fontWeight: 700,
        color: "#1A1A2E",
        margin: "0 0 4px",
      }}
    >
      {title}
    </h3>
    <p
      style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: 11,
        color: "#888899",
        margin: "0 0 6px",
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        fontWeight: 600,
      }}
    >
      Check
    </p>
    <ul
      style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: 12,
        color: "#555567",
        lineHeight: 1.55,
        paddingLeft: 18,
        margin: 0,
        listStyleType: "disc",
      }}
    >
      {items.map((it, i) => (
        <li key={i} style={{ marginBottom: 2 }}>
          {it}
        </li>
      ))}
    </ul>
  </div>
);

const CapabilityGroup: React.FC<{
  title: string;
  items: [string, string][];
}> = ({ title, items }) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      padding: "12px 16px 10px",
      marginBottom: 10,
      background: "#FFFFFF",
    }}
  >
    <h3
      style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: 12,
        fontWeight: 700,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: "#27698F",
        margin: "0 0 8px",
      }}
    >
      {title}
    </h3>
    <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
      {items.map(([label, desc], i) => (
        <li
          key={i}
          style={{
            display: "flex",
            alignItems: "flex-start",
            gap: 8,
            marginBottom: 6,
          }}
        >
          <span
            style={{
              flex: "0 0 auto",
              width: 6,
              height: 6,
              borderRadius: "50%",
              background: "linear-gradient(135deg, #43B5BF, #27698F)",
              marginTop: 6,
            }}
          />
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: "#555567",
              lineHeight: 1.5,
            }}
          >
            <strong style={{ color: "#1A1A2E" }}>{label}</strong> — {desc}
          </span>
        </li>
      ))}
    </ul>
  </div>
);

const DynamicsConnectorGuide: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
        .rounded-table table { margin: 0 !important; }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 – Cover & Table of Contents ===== */}
      <div className="page">
        <PageHeader eyebrow="Installation Guide" />

        <div className="partner-hero" style={{ marginTop: 40, marginBottom: 10 }}>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "#43B5BF",
              marginBottom: 10,
            }}
          >
            MS Dynamics Connector for GoContact
          </div>
          <h1
            className="hero-headline"
            style={{ fontSize: 34, lineHeight: 1.05, marginBottom: 6 }}
          >
            Broadvoice MS Dynamics <em>Connector</em>
          </h1>
          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Installation and configuration steps for the GoContact connector inside
            Microsoft Dynamics 365.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />

        <PageBody>
          <div style={{ height: 14 }} />
          <SectionTitle>Contents</SectionTitle>
          <Body>
            A quick map of the installation and validation steps covered in this guide.
          </Body>

          <div style={{ marginTop: 10 }}>
            {[
              { num: "01", title: "Obtain the Connector Package", desc: "Receive the managed solution .zip from Broadvoice.", page: "02" },
              { num: "02", title: "Import the Solution into Dynamics", desc: "Upload and verify the GoContact Connector package.", page: "02" },
              { num: "03", title: "Configure Microsoft Entra ID (Azure AD) SSO", desc: "Set up SAML SSO between Microsoft and GoContact.", page: "03" },
              { num: "04", title: "Configure the Connector in Dynamics (CIF v1)", desc: "Add the GoContact channel provider and configuration options.", page: "04" },
              { num: "05", title: "User Readiness & Validation", desc: "First-time login and sandbox validation checklist.", page: "06" },
              { num: "—", title: "Troubleshooting Gates", desc: "Quick triage paths for common setup issues.", page: "07" },

            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: 14,
                  padding: "10px 0",
                  borderBottom: "1px solid #E2E2EC",
                }}
              >
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 13,
                      fontWeight: 700,
                      color: "#1A1A2E",
                      lineHeight: 1.3,
                    }}
                  >
                    {item.title}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 11,
                      color: "#888899",
                      marginTop: 2,
                      lineHeight: 1.4,
                    }}
                  >
                    {item.desc}
                  </div>
                </div>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 11,
                    fontWeight: 700,
                    color: "#27698F",
                    flex: "0 0 auto",
                    letterSpacing: "0.08em",
                  }}
                >
                  p. {item.page}
                </span>
              </div>
            ))}
          </div>
        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – Steps 1–2 ===== */}
      <div className="page">
        <PageHeader eyebrow="Steps 1–2 · Obtain & Import" />
        <PageBody>
          <div style={{ height: 30 }} />
          <Body>
            This document describes the process for installing and configuring the{" "}
            <strong>Broadvoice MS Dynamics Connector for GoContact</strong>.
          </Body>

          <StepCard num="1" title="Obtain the Connector Package">
            <Body>
              The GoContact Connector is delivered as a managed solution package
              (.zip file). The latest version is shared directly by the Broadvoice
              team.
            </Body>
          </StepCard>

          <StepCard num="2" title="Import the Solution into Dynamics">
            <Ordered
              items={[
                <>
                  In Dynamics, go to <strong>Advanced Settings → Solutions → Import</strong>.
                </>,
                "Upload the provided GoContact Connector package (.zip file).",
                "Wait for the import to complete.",
                <>
                  Verify that the <strong>GoContact Connect</strong> components appear
                  in the Dynamics environment.
                </>,
              ]}
            />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>



      {/* ===== PAGE 3 – Step 3 SSO ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 3 · Microsoft Entra ID (Azure AD) SSO" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>Step 3 · Configure Microsoft Entra ID (Azure AD) SSO</SectionTitle>

          <Callout tone="warn">
            <strong>Note:</strong> This step is only required if Microsoft SSO has{" "}
            <strong>not already been configured</strong> for the customer's GoContact
            tenant. If SSO is already active and working (i.e., users can log in to
            GoContact using "Login with Microsoft"), skip this step.
          </Callout>

          <SubHead>
            Performed by the customer's Microsoft 365 or IT administrator
          </SubHead>
          <Ordered
            items={[
              <>
                In Microsoft Entra ID (Azure AD), create a new{" "}
                <strong>Enterprise Application</strong>.
              </>,
              <>
                Choose <strong>SAML-based Single Sign-On</strong> as the authentication
                method.
              </>,
              <>
                Enter the following information provided by GoContact:
                <Bullets
                  items={[
                    <>
                      <strong>Entity ID</strong> and <strong>Reply URL (ACS)</strong>{" "}
                      values
                    </>,
                    <>
                      Required user attributes: <code>email</code>,{" "}
                      <code>firstName</code>, <code>lastName</code>,{" "}
                      <code>phoneNumber</code> (optional)
                    </>,
                  ]}
                />
              </>,
              <>
                Save the configuration and download the{" "}
                <strong>Federation Metadata XML</strong> file.
              </>,
              <>
                In GoContact, open{" "}
                <strong>Admin → Authentication → SSO Configuration</strong>, select
                Microsoft, and upload the XML file.
              </>,
              <>
                Save and confirm the configuration. Propagation may take up to{" "}
                <strong>48 hours</strong>.
              </>,
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 3 – Step 4 CIF v1 ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 4 · Configure the Connector in Dynamics (CIF v1)" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>
            Step 4 · Configure the GoContact Connector in Microsoft Dynamics (CIF v1)
          </SectionTitle>
          <Body>
            After completing the prerequisites above, the{" "}
            <strong>
              GoContact Connector UI can be configured inside Microsoft Dynamics using
              Channel Integration Framework (CIF) v1.
            </strong>
          </Body>

          <Callout>
            <strong>Prerequisite:</strong> CIF v1 must be available in the Dynamics
            instance. This requires the{" "}
            <strong>Dynamics 365 Channel Integration Framework</strong> add-on. Verify
            that CIF is installed by navigating to{" "}
            <strong>Dynamics 365 → Channel Integration Framework</strong> in the
            left-hand navigation. If it is not available, the Dynamics administrator
            must install it from <u>Microsoft AppSource</u>.
          </Callout>

          <SubHead>Connector Application URL</SubHead>
          <Body>
            The GoContact Connector is loaded through a URL containing the Ccaas CRM
            embed UI:
          </Body>
          <div
            style={{
              fontFamily: "'JetBrains Mono', ui-monospace, monospace",
              fontSize: 11,
              color: "#1A1A2E",
              background: "#F3F3F8",
              border: "1px solid #E2E2EC",
              borderRadius: 6,
              padding: "10px 12px",
              wordBreak: "break-all",
              margin: "6px 0 14px",
            }}
          >
            https://eu.cloud.gocontact.com/ccaas-crm-embed-ui/?tenantId=
            <mark style={{ background: "#FFF1A8", padding: "0 2px" }}>0f</mark>
            181b9a-0c13-422b-ae38-418f6c389288
          </div>

          <SubHead>Add Connector to Dynamics CIF v1</SubHead>
          <Ordered
            items={[
              <>
                Navigate to{" "}
                <strong>Dynamics 365 → Channel Integration Framework</strong>{" "}
                configuration.
              </>,
              <>
                Create a <strong>new Channel Provider</strong>.
              </>,
              "Configure the following settings:",
            ]}
          />
          <ConfigTable />
          <Ordered
            start={4}
            items={[<strong key="save">Save the configuration.</strong>]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== Step 4 continued – Configuration options & agent experience ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 4 · Configuration Options" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>Step 4 · Additional Configuration Options</SectionTitle>
          <Body>
            Once the channel provider is saved, review the administration settings
            below so the embedded experience matches the customer's business rules.
          </Body>

          <CapabilityGroup
            title="Administration & Configuration"
            items={[
              [
                "Flexible contact search configuration",
                "Configure contact search priority to align with business requirements.",
              ],
              [
                "Catch-all contact configuration",
                "Support for a default contact when no CRM match is found.",
              ],
              [
                "Configurable call activity field mapping",
                "Administrators can define which call data fields are synchronized with Dynamics 365.",
              ],
              [
                "Enhanced queue search",
                "Improved queue selection for deployments with a large number of queues.",
              ],
              [
                "Assignment management enhancements",
                "Improved handling of assignment changes initiated by administrators to ensure users always have the correct access and configuration.",
              ],
              [
                "Permission based break support",
                "Break availability that needs approval.",
              ],
              [
                "Improved assignment handling",
                "Automatically reflects assignment revocations or updates made by administrators without requiring manual intervention.",
              ],
            ]}
          />

          <SubHead>Agent capabilities enabled by this configuration</SubHead>
          <CapabilityGroup
            title="Agent Productivity"
            items={[
              [
                "After Call Actions",
                "Configurable post-call actions to streamline agent workflows after customer interactions.",
              ],
              [
                "Remote user transfer",
                "Agents can transfer active calls directly to remote users.",
              ],
              [
                "Improved callback visibility",
                "Enhanced visibility of callback interactions, making it easier for agents to manage follow-up engagements.",
              ],
              [
                "Automatic campaign support",
                "Support for automatic outbound campaigns within the Dynamics 365 embedded experience.",
              ],
              [
                "Call activity for multiple contact matches",
                "Automatically creates a call activity even when a phone number matches multiple CRM contacts, ensuring interactions are captured consistently.",
              ],
            ]}
          />

          <CapabilityGroup
            title="User Experience & Accessibility"
            items={[
              [
                "Accessibility improvements",
                "The embedded CTI experience has been enhanced based on accessibility testing for a more intuitive and consistent user interface.",
              ],
              [
                "Improved DTMF keypad experience",
                "Keypad and UI inconsistencies were addressed to deliver a smoother in-call experience.",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 4 – User Readiness & Validation ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 5 · User Readiness & Validation" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>Step 5 · User Readiness</SectionTitle>
          <Ordered
            items={[
              <>
                Confirm the user can log in to <strong>Microsoft Dynamics</strong>.
              </>,
              <>
                For any user <strong>not yet linked</strong> to GoContact through
                Microsoft identity, complete a{" "}
                <strong>one-time direct GoContact login</strong> using{" "}
                <strong>Login with Microsoft</strong>.
              </>,
              "Confirm the user has the required queue / campaign assignment for voice login.",
            ]}
          />
          <Callout>
            The first-time direct GoContact login is required{" "}
            <strong>only once per new user</strong>.
          </Callout>

          <div style={{ height: 14 }} />
          <SectionTitle>Minimum Validation Checklist</SectionTitle>

          <Body>Validate in sandbox before production.</Body>

          <ChecklistGroup
            title="Platform validation"
            items={[
              "The connector panel loads inside the selected Dynamics app.",
              "Microsoft SSO completes successfully inside the embedded widget.",
              "The voice login screen loads and shows the user's assigned voice options.",
              "The user can enter a ready / usable voice state.",
            ]}
          />
          <ChecklistGroup
            title="Functional validation"
            items={[
              "Inbound call handling works in the current build.",
              "Dynamics record lookup / screen pop works in the current build.",
              "Outbound call handling works in the current build.",
              "Phone call activity is created or updated in Dynamics, including when a number matches multiple contacts.",
              "Configured after call actions, callbacks, and transfers behave as expected.",
            ]}
          />
          <ChecklistGroup
            title="Operational validation"
            items={[
              "Logout / leave voice behavior works as expected for the current build.",
              "Browser microphone permission is granted and WebRTC is operational.",
              "No environment-specific URL or tenant mismatch is present.",
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Troubleshooting Gates ===== */}
      <div className="page">
        <PageHeader eyebrow="Troubleshooting Gates" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>Troubleshooting Gates</SectionTitle>
          <Body>
            Use the gates below to triage issues quickly before escalating to
            Broadvoice support.
          </Body>

          <TroubleshootingCard
            title="Connector panel does not appear"
            items={[
              "CIF v1 availability",
              "Channel URL",
              "Trusted Domain",
              "Unified Interface App selection",
              "Target Dynamics app visibility",
            ]}
          />
          <TroubleshootingCard
            title="SSO works in browser but not in Dynamics"
            items={[
              "Microsoft SSO is active on the GoContact tenant",
              "Dynamics service subscription is enabled on the tenant",
              "User has completed the first-time direct GoContact login if needed",
            ]}
          />
          <TroubleshootingCard
            title="User cannot complete voice login"
            items={[
              "Queue / campaign assignment",
              "Microphone / WebRTC readiness",
              "Browser compatibility",
            ]}
          />
          <TroubleshootingCard
            title="Import or CIF issues appear during setup"
            items={[
              "Validate the Dynamics environment and licensing before treating the issue as a connector defect.",
            ]}
          />
          <TroubleshootingCard
            title="CRM actions fail after the widget loads"
            items={[
              "Check CIF availability and the active Dynamics app context before deeper troubleshooting.",
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

    </div>
  );
};

export default DynamicsConnectorGuide;
