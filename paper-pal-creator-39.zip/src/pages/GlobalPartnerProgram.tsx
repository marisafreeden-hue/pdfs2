import React from "react";
import { Handshake, Sparkles, Cloud, Bot, BarChart3, Users, Store, Wrench, Award, Headphones, Globe, Mail, ArrowRight, CheckCircle2 } from "lucide-react";
import "./GoEngageDatasheet.css";
import "./ImplementationTaskforce.css";

const PageHeader = () => (
  <div className="tf-page-header">
    <span className="tf-header-left">BROADVOICE | GoContact · Global Partner Program</span>
    <span className="tf-header-right">REV. MAY 2026</span>
  </div>
);

const PageFooterText = ({ pageNum }: { pageNum: number }) => (
  <div className="tf-page-footer-text">
    <span>Confidencial – Uso Interno</span>
    <span>Página {pageNum}</span>
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const SectionLabel = ({ number, label }: { number: number; label?: string }) => (
  <div className="tf-section-label">{label ? `SECCIÓN ${number} · ${label}` : `SECCIÓN ${number}`}</div>
);

const IconDefs = () => (
  <svg width="0" height="0" style={{ position: "absolute" }}>
    <defs>
      <linearGradient id="gpp-icon-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#43B5BF" />
        <stop offset="100%" stopColor="#27698F" />
      </linearGradient>
    </defs>
  </svg>
);

type SolCardProps = { Icon: React.ComponentType<any>; title: string; intro: string; items: string[] };
const SolutionCard: React.FC<SolCardProps> = ({ Icon, title, intro, items }) => (
  <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px", background: "#FFFFFF" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
      <Icon size={16} style={{ stroke: "url(#gpp-icon-grad)" }} />
      <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 700, color: "#1A1A2E" }}>{title}</div>
    </div>
    <p style={{ fontSize: 10, color: "#555567", lineHeight: 1.55, margin: "0 0 8px 0", fontFamily: "'Inter', sans-serif" }}>{intro}</p>
    <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc" }}>
      {items.map((it, i) => (
        <li key={i} style={{ fontSize: 10, color: "#555567", lineHeight: 1.55, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>{it}</li>
      ))}
    </ul>
  </div>
);

type PathProps = { Icon: React.ComponentType<any>; title: string; desc: string; items: string[] };
const PathCard: React.FC<PathProps> = ({ Icon, title, desc, items }) => (
  <div style={{ border: "1px solid #D0E8EA", borderRadius: 10, padding: "16px 18px", background: "rgba(67,181,191,0.04)", display: "flex", flexDirection: "column" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
      <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #43B5BF, #27698F)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon size={16} color="#FFFFFF" />
      </div>
      <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 18, fontWeight: 600, color: "#1A1A2E" }}>{title}</div>
    </div>
    <p style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.6, margin: "0 0 10px 0", fontFamily: "'Inter', sans-serif" }}>{desc}</p>
    <ul style={{ margin: 0, paddingLeft: 0, listStyle: "none" }}>
      {items.map((it, i) => (
        <li key={i} style={{ fontSize: 10, color: "#555567", lineHeight: 1.55, marginBottom: 5, fontFamily: "'Inter', sans-serif", display: "flex", gap: 6 }}>
          <CheckCircle2 size={11} style={{ stroke: "url(#gpp-icon-grad)", flexShrink: 0, marginTop: 2 }} />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  </div>
);

const GlobalPartnerProgram: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper tf-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>
      <IconDefs />

      {/* ===== PAGE 1: Cover + ¿Qué es? + ¿Por qué? ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="tf-cover-content">
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 6 }}>
            Broadvoice · GoContact
          </div>
          <h1 className="hero-headline">
            Global Partner<br /><em>Program</em>
          </h1>
          <div className="tf-cover-subtitle">Una alianza estratégica<br />para liderar el Contact Center</div>
        </div>

        <hr />

        <SectionLabel number={1} label="¿QUÉ ES?" />
        <h2 className="section-title">Una iniciativa de <em>colaboración estratégica</em></h2>

        <p className="section-body tf-body-wide">
          Diseñada para compartir nuestra experiencia y liderazgo en la industria de Contact Centers con socios de negocios que deseen fortalecer sus capacidades en este sector. Juntos, ayudamos a los clientes a optimizar sus operaciones y maximizar sus resultados mediante soluciones tecnológicas innovadoras.
        </p>
        <p className="section-body tf-body-wide">
          Nuestro programa ofrece un ecosistema basado en la colaboración estratégica y el crecimiento mutuo. Cada socio recibe el respaldo y las herramientas necesarias para alcanzar el éxito.
        </p>

        <div className="closing-line" style={{ marginTop: 16, marginBottom: 18 }}>
          Descubre las ventajas exclusivas de ser parte del programa.
        </div>

        <SectionLabel number={2} label="¿POR QUÉ SER PARTE?" />
        <h2 className="section-title">Un socio tecnológico <em>competitivo</em></h2>
        <p className="section-body tf-body-wide">
          Reconocidos por nuestra solución de Contact Center as a Service, nos adaptamos a las necesidades de nuestros clientes con soluciones innovadoras y disruptivas como IA Generativa y análisis de datos que transforman el CX | UX en las compañías.
        </p>

        <PageFooterText pageNum={1} />
        <PageFooter />
      </div>

      {/* ===== PAGE 2: Soluciones ===== */}
      <div className="page page-2">
        <PageHeader />
        <SectionLabel number={3} label="NUESTRAS SOLUCIONES" />
        <h2 className="section-title">Tecnología integral para el <em>Contact Center moderno</em></h2>
        <p className="section-body tf-body-wide">
          Tres capas complementarias que cubren toda la operación: plataforma, automatización inteligente y servicios de próxima generación.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginTop: 12 }}>
          <SolutionCard
            Icon={Cloud}
            title="CCaaS"
            intro="Nuestra plataforma omnicanal, desarrollada 100% en Cloud, es la base de todo lo que hacemos."
            items={["Voz", "Correo electrónico / Tickets", "WebChat", "Mensajes de Facebook", "Instagram DM's", "WhatsApp"]}
          />
          <SolutionCard
            Icon={Bot}
            title="Inteligencia Artificial"
            intro="Ayudamos a clientes y agentes a agilizar interacciones y automatizar procesos."
            items={["IVR avanzado", "Asistente de Voz Inteligente (AVI)", "Chatbots", "Email Bot"]}
          />
          <SolutionCard
            Icon={BarChart3}
            title="CXHub"
            intro="Un ecosistema con soluciones de IA y datos de próxima generación."
            items={["Advanced Analytics", "Workforce Management (WFM)", "Agent Assist", "Quality Automation"]}
          />
        </div>

        <div style={{ marginTop: 22 }}>
          <SectionLabel number={4} label="ELIGE TU CAMINO" />
          <h2 className="section-title">Tres vías de <em>colaboración</em></h2>
          <p className="section-body tf-body-wide">
            Descubre las tres vías que generan una relación de valor entre Broadvoice GoContact y nuestros socios.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginTop: 10 }}>
          <PathCard
            Icon={Handshake}
            title="Referral"
            desc="Recomienda a los clientes y clientes potenciales interesados en implementar soluciones como las de GoContact."
            items={[
              "Comisiones por cada oportunidad de negocio convertida",
              "Apoyo de un gerente de socios para coordinar reuniones",
            ]}
          />
          <PathCard
            Icon={Store}
            title="Reseller"
            desc="Vende de forma proactiva las soluciones de GoContact a clientes y clientes potenciales."
            items={[
              "Margen de beneficio por cada conversión realizada",
              "Posibilidad de facturación directa",
              "Soporte de nuestro equipo multidisciplinario (ventas, customer success, soporte y otros)",
            ]}
          />
          <PathCard
            Icon={Wrench}
            title="Integrator"
            desc="Expertos en tecnología o CX que venden las soluciones y participan activamente en implementación, consultoría y soporte diario."
            items={[
              "Margen de beneficio por cada conversión realizada",
              "Gestión directa de la facturación a los clientes",
              "Apoyo integrado con nuestro equipo multidisciplinario",
              "Ofrecer un servicio completo (end-to-end)",
              "Acciones de marketing para gestionar y cerrar acuerdos",
            ]}
          />
        </div>

        <PageFooterText pageNum={2} />
        <PageFooter />
      </div>

      {/* ===== PAGE 3: Beneficios + Testimonio + Contacto ===== */}
      <div className="page page-3">
        <PageHeader />
        <SectionLabel number={5} label="BENEFICIOS" />
        <h2 className="section-title">Beneficios del <em>Global Partner Program</em></h2>
        <p className="section-body tf-body-wide">
          Un programa diseñado para impulsar el crecimiento mutuo y la excelencia operativa.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10, marginTop: 10 }}>
          {[
            { Icon: Award, t: "Modelo de beneficios financieros competitivos" },
            { Icon: Sparkles, t: "Acceso a un portafolio de soluciones innovadoras" },
            { Icon: Users, t: "Excelencia en la satisfacción del cliente" },
            { Icon: ArrowRight, t: "Generación y desarrollo de nuevos negocios" },
            { Icon: Headphones, t: "Gerente de socios dedicado y soporte personalizado" },
            { Icon: Award, t: "Certificación avanzada" },
            { Icon: BarChart3, t: "Crecimiento mutuo" },
            { Icon: Globe, t: "Presencia local, cobertura global" },
          ].map(({ Icon, t }, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, border: "1px solid #E2E2EC", borderRadius: 8, padding: "10px 12px", background: "#FFFFFF" }}>
              <div style={{ width: 26, height: 26, borderRadius: 6, background: "rgba(67,181,191,0.1)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Icon size={14} style={{ stroke: "url(#gpp-icon-grad)" }} />
              </div>
              <div style={{ fontSize: 11, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", fontWeight: 500, lineHeight: 1.35 }}>{t}</div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 22 }}>
          <SectionLabel number={6} label="LA VOZ DE NUESTRO PARTNER" />
        </div>

        <div style={{ border: "1px solid #D0E8EA", borderRadius: 12, padding: "20px 22px", background: "linear-gradient(135deg, rgba(67,181,191,0.06), rgba(39,105,143,0.04))", marginTop: 8 }}>
          <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 36, lineHeight: 1, background: "linear-gradient(90deg, #43B5BF, #27698F)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", marginBottom: 4 }}>“</div>
          <p style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 16, fontWeight: 400, color: "#1A1A2E", lineHeight: 1.45, margin: "0 0 14px 0", fontStyle: "italic" }}>
            Es una alianza con éxito garantizado, en la que creemos que la capacidad de innovación de GoContact, combinada con las plataformas tecnológicas de NOS, nos permite crear una propuesta de valor única y diferenciadora para el mercado.
          </p>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg, #43B5BF, #27698F)", display: "flex", alignItems: "center", justifyContent: "center", color: "#FFFFFF", fontFamily: "'Inter', sans-serif", fontWeight: 700, fontSize: 12 }}>TS</div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Tiago Silva Ribeiro</div>
              <div style={{ fontSize: 10, color: "#555567", fontFamily: "'Inter', sans-serif" }}>Director de Desarrollo de Negocios B2B · NOS</div>
            </div>
          </div>
        </div>

        <div style={{ marginTop: 22 }}>
          <SectionLabel number={7} label="¿HABLAMOS?" />
        </div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", border: "1px solid #E2E2EC", borderRadius: 10, padding: "18px 22px", marginTop: 8, background: "#FFFFFF" }}>
          <div>
            <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 22, fontWeight: 500, color: "#1A1A2E", marginBottom: 4 }}>
              Envíanos un email para <em style={{ background: "linear-gradient(90deg, #43B5BF, #27698F)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", fontStyle: "italic" }}>obtener más información</em>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
              <Mail size={14} style={{ stroke: "url(#gpp-icon-grad)" }} />
              <a href="mailto:comercial@gocontact.es" style={{ fontSize: 13, color: "#27698F", fontFamily: "'Inter', sans-serif", fontWeight: 600, textDecoration: "none" }}>comercial@gocontact.es</a>
            </div>
          </div>
          <div style={{ padding: "10px 18px", borderRadius: 8, background: "linear-gradient(135deg, #43B5BF, #27698F)", color: "#FFFFFF", fontFamily: "'Inter', sans-serif", fontSize: 11, fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
            Global Partner Program <ArrowRight size={13} />
          </div>
        </div>

        <PageFooterText pageNum={3} />
        <PageFooter />
      </div>
    </div>
  );
};

export default GlobalPartnerProgram;
