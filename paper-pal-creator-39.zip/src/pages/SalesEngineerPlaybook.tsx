import React from "react";
import {
  Target,
  Users,
  TrendingUp,
  Calendar,
  ClipboardList,
  Network,
  BookOpen,
  Briefcase,
  Compass,
  Brain,
  BarChart3,
  Trophy,
  GraduationCap,
  Clock,
  CheckCircle2,
  Presentation,
  Search,
  Layers,
  FileText,
  Wrench,
  ShieldCheck,
  Sparkles,
  MessageSquare,
} from "lucide-react";
import "./GoEngageDatasheet.css";
import "./ImplementationTaskforce.css";

const DOC_NAME = "Sales Engineer CX Solution Selling Playbook";
const DOC_REV = "REV. APRIL 2026";

const PageHeader = () => (
  <div className="tf-page-header">
    <span className="tf-header-left">BROADVOICE | {DOC_NAME}</span>
    <span className="tf-header-right">{DOC_REV}</span>
  </div>
);

const PageFooterText = ({ pageNum }: { pageNum: number }) => (
  <div className="tf-page-footer-text" style={{ bottom: "0.4in" }}>
    <span>Confidential – Internal Use Only</span>
    <span>Page {pageNum}</span>
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const SectionLabel = ({ number, label }: { number: number; label?: string }) => (
  <div className="tf-section-label">{label ? `SECTION ${number} · ${label}` : `SECTION ${number}`}</div>
);

type PillarProps = { Icon: React.ComponentType<any>; title: string; items: React.ReactNode[] };
const PillarCard: React.FC<PillarProps> = ({ Icon, title, items }) => (
  <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px", background: "#FFFFFF" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
      <Icon size={16} style={{ stroke: "url(#se-icon-grad)" }} />
      <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 700, color: "#1A1A2E" }}>{title}</div>
    </div>
    <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc" }}>
      {items.map((it, i) => (
        <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 4, fontFamily: "'Inter', sans-serif" }}>{it}</li>
      ))}
    </ul>
  </div>
);

const StageCard: React.FC<{
  num: string;
  title: string;
  objective: string;
  actions: string[];
  extraLabel?: string;
  extra?: string[];
}> = ({ num, title, objective, actions, extraLabel, extra }) => (
  <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "10px 14px", background: "#FFFFFF" }}>
    <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 6 }}>
      <div style={{
        fontFamily: "'Instrument Sans', sans-serif",
        fontSize: 22, fontWeight: 500, lineHeight: 1,
        background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)",
        WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent",
      }}>{num}</div>
      <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12.5, fontWeight: 700, color: "#1A1A2E" }}>{title}</div>
    </div>
    <div style={{ fontSize: 10.5, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 6 }}>
      <strong>Objective: </strong>{objective}
    </div>
    <div style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 4 }}>SE Actions</div>
    <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc", marginBottom: extra ? 8 : 0 }}>
      {actions.map((a, i) => (
        <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.5, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>{a}</li>
      ))}
    </ul>
    {extra && (
      <>
        <div style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 4 }}>{extraLabel}</div>
        <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc" }}>
          {extra.map((a, i) => (
            <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.5, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>{a}</li>
          ))}
        </ul>
      </>
    )}
  </div>
);

const IconDefs = () => (
  <svg width="0" height="0" style={{ position: "absolute" }}>
    <defs>
      <linearGradient id="se-icon-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#43B5BF" />
        <stop offset="100%" stopColor="#27698F" />
      </linearGradient>
    </defs>
  </svg>
);

const SalesEngineerPlaybook: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper tf-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>
      <IconDefs />

      {/* ===== PAGE 1: Cover + Purpose + Role ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="tf-cover-content">
          <h1 className="hero-headline" style={{ fontSize: 40, lineHeight: 1.1 }}>
            Sales Engineer<br /><em>CX Solution Selling Playbook</em>
          </h1>
          <div className="tf-cover-subtitle">Aligning technical expertise with<br />business value and customer outcomes</div>
        </div>

        <div className="outcomes-container" style={{ marginTop: 24 }}>
          <table className="outcomes-table tf-cover-table">
            <tbody>
              <tr><td className="tf-meta-label">Document</td><td>Sales Engineer CX Solution Selling Playbook</td></tr>
              <tr><td className="tf-meta-label">Revision</td><td>April 2026</td></tr>
              <tr><td className="tf-meta-label">Audience</td><td>Sales Engineers</td></tr>
              <tr><td className="tf-meta-label">Classification</td><td>Confidential – Internal Use Only</td></tr>
              <tr><td className="tf-meta-label">Owner</td><td>Broadvoice Sales Engineering Leadership</td></tr>
            </tbody>
          </table>
        </div>

        

        <div style={{ marginTop: 50 }} />
        <SectionLabel number={1} label="PURPOSE" />
        <h2 className="section-title">Purpose & <em>Role of the Sales Engineer</em></h2>

        <p className="section-body tf-body-wide">
          This playbook equips Sales Engineers (SEs) to effectively support a CX solution-selling motion by aligning technical expertise with business value, sales strategy, and customer outcomes.
        </p>

        <p className="section-body tf-body-wide">
          <strong>Mission — </strong>Partner with Account Executives (AEs) to proactively support partners and win deals by translating customer needs into technical solutions that deliver measurable business value.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 10 }}>
          <PillarCard
            Icon={Users}
            title="Partner & Team Alignment"
            items={[
              "Partner with TSD engineers so they're positioned as a valued resource.",
              "Proactively support partners to create positive business impact.",
              "Fully embrace the POD approach for total alignment across every partner and customer engagement.",
            ]}
          />
          <PillarCard
            Icon={Wrench}
            title="Core Responsibilities"
            items={[
              "Lead technical discovery.",
              "Deliver tailored product demonstrations.",
              "Design solution architectures.",
              "Validate technical fit and influence deal strategy.",
              "Support proposals and scope of work.",
            ]}
          />
        </div>

        <div className="closing-line" style={{ marginTop: 18 }}>
          Lead with outcomes. Design for fit. Win on value.
        </div>

        <PageFooterText pageNum={1} />
        <PageFooter />
      </div>

      {/* ===== PAGE 2: Framework Stages 1-3 ===== */}
      <div className="page page-2">
        <PageHeader />
        <SectionLabel number={2} label="SOLUTION SELLING FRAMEWORK" />
        <h2 className="section-title">SE Engagement Model — <em>Stages 1–3</em></h2>
        <p className="section-body tf-body-wide" style={{ marginBottom: 6 }}>
          A repeatable, stage-based engagement model that moves opportunities from qualification through a compelling, customer-aligned demonstration.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 8, marginTop: 4 }}>
          <StageCard
            num="01"
            title="Qualification — Confirm technical and business viability"
            objective="Confirm the opportunity is worth pursuing from a technical and business standpoint."
            actions={[
              "Validate high-level use case.",
              "Identify technical requirements.",
              "Flag risks early.",
            ]}
            extraLabel="Key Questions & Exit Criteria"
            extra={[
              "What systems are in place today? Are there integration requirements? Any compliance / security constraints?",
              "Exit: clear technical fit and no major blockers identified.",
            ]}
          />
          <StageCard
            num="02"
            title="Discovery — Understand business problems and desired outcomes"
            objective="Uncover the business challenges, KPIs, and definition of success driving the opportunity."
            actions={[
              "Lead technical discovery.",
              "Map workflows and pain points.",
              "Identify success metrics.",
            ]}
            extraLabel="Key Questions & Deliverables"
            extra={[
              "What are your top business challenges? What KPIs are you trying to improve? What does success look like?",
              "Deliverables: discovery notes and an initial solution hypothesis.",
            ]}
          />
          <StageCard
            num="03"
            title="Demonstration — Show how the solution solves customer problems"
            objective="Deliver a tailored, outcome-focused demo that reinforces fit and creates conviction."
            actions={[
              "Customize the demo to the customer use case.",
              "Align features to business outcomes.",
              "Tell a compelling, persona-based story.",
            ]}
            extraLabel="Demo Framework & Best Practices"
            extra={[
              "1) Agenda aligned to goals  2) Reconfirm pain points  3) Show solution in context  4) Highlight differentiators  5) Handle objections  6) Define next steps.",
              "70% use case, 30% features — persona-based storytelling.",
            ]}
          />
        </div>

        <PageFooterText pageNum={2} />
        <PageFooter />
      </div>

      {/* ===== PAGE 3: Framework Stages 4-7 ===== */}
      <div className="page page-3">
        <PageHeader />
        <SectionLabel number={2} label="SOLUTION SELLING FRAMEWORK" />
        <h2 className="section-title">SE Engagement Model — <em>Stages 4–7</em></h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 8 }}>
          <StageCard
            num="04"
            title="Solution Design"
            objective="Define the optimal technical solution for the customer's environment."
            actions={[
              "Build architecture diagrams.",
              "Define integrations.",
              "Align to customer environment.",
            ]}
            extraLabel="Deliverables"
            extra={[
              "Solution architecture.",
              "Technical validation summary.",
            ]}
          />
          <StageCard
            num="05"
            title="Proposal & Pricing Support"
            objective="Ensure the solution aligns with scope and value."
            actions={[
              "Validate configuration.",
              "Support pricing alignment.",
              "Ensure scalability.",
            ]}
          />
          <StageCard
            num="06"
            title="Scope of Work (SOW)"
            objective="Define implementation expectations across all stakeholders."
            actions={[
              "Document technical requirements.",
              "Define assumptions and dependencies.",
              "Align with delivery teams.",
            ]}
          />
          <StageCard
            num="07"
            title="Technical Win"
            objective="Secure customer confidence in the solution."
            actions={[
              "Address final objections.",
              "Validate all requirements are met.",
              "Support final presentations.",
            ]}
            extraLabel="Success Criteria"
            extra={[
              "Customer agrees the solution meets their needs.",
              "No unresolved technical risks.",
            ]}
          />
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={3} label="DEMO PLAYBOOK" />
          <h2 className="section-title">The <em>Demo Playbook</em></h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 6 }}>
          <PillarCard
            Icon={ClipboardList}
            title="Preparation Checklist"
            items={[
              "Understand customer use case.",
              "Identify personas attending.",
              "Customize and personalize the demo environment.",
              "Align with AE on goals.",
            ]}
          />
          <PillarCard
            Icon={Presentation}
            title="Execution Tips"
            items={[
              "Lead with outcomes, not features.",
              "Pause for engagement and ask questions throughout.",
              "Control the narrative through conversation — not a monologue.",
              "Use storytelling to drive the discussion.",
            ]}
          />
          <PillarCard
            Icon={ShieldCheck}
            title="Common Mistakes to Avoid"
            items={[
              "Generic demos.",
              "Overloading with features.",
              "Ignoring business value.",
            ]}
          />
        </div>

        <PageFooterText pageNum={3} />
        <PageFooter />
      </div>

      {/* ===== PAGE 4: Discovery, Tools, Metrics ===== */}
      <div className="page page-4">
        <PageHeader />
        <SectionLabel number={4} label="DISCOVERY PLAYBOOK" />
        <h2 className="section-title">Discovery <em>Framework</em></h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 8 }}>
          <PillarCard
            Icon={Search}
            title="The Framework"
            items={[
              "Current State.",
              "Pain Points.",
              "Business Impact.",
              "Desired Future State.",
              "Success Metrics.",
            ]}
          />
          <PillarCard
            Icon={MessageSquare}
            title="Example Questions"
            items={[
              "What is not working today?",
              "What is the cost of the problem?",
              "What happens if nothing changes?",
            ]}
          />
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={5} label="TOOLS & ASSETS" />
          <h2 className="section-title">Required <em>Tools & Assets</em></h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginTop: 6 }}>
          {[
            { Icon: Layers, line1: "Demo", line2: "environments" },
            { Icon: BarChart3, line1: "ROI", line2: "calculators" },
            { Icon: FileText, line1: "Discovery", line2: "templates" },
            { Icon: Network, line1: "Architecture", line2: "diagrams" },
            { Icon: ShieldCheck, line1: "Competitive", line2: "battlecards" },
          ].map(({ Icon, line1, line2 }, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "12px 12px", textAlign: "left", background: "#FFFFFF" }}>
              <Icon size={18} style={{ stroke: "url(#se-icon-grad)" }} />
              <div style={{ marginTop: 6, fontSize: 10.5, fontWeight: 600, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.3 }}>
                {line1}<br />{line2}
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={6} label="METRICS & KPIs" />
          <h2 className="section-title">Metrics & <em>KPIs</em></h2>
        </div>

        <div style={{ border: "1px solid #D0E8EA", borderRadius: 10, padding: "14px 16px", background: "rgba(67,181,191,0.04)", marginTop: 6 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <div>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>Activity Metrics</div>
              <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc" }}>
                {["Demos delivered", "Deals supported", "Discovery participation"].map((t, i) => (
                  <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 4, fontFamily: "'Inter', sans-serif" }}>{t}</li>
                ))}
              </ul>
            </div>
            <div>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>Outcome Metrics</div>
              <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc" }}>
                {["Technical win rate", "Deal influence", "Sales cycle impact", "Average deal size"].map((t, i) => (
                  <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 4, fontFamily: "'Inter', sans-serif" }}>{t}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <PageFooterText pageNum={4} />
        <PageFooter />
      </div>

      {/* ===== PAGE 5: Ramp + Enablement + Readiness ===== */}
      <div className="page page-5">
        <PageHeader />
        <SectionLabel number={7} label="30-60-90 RAMP" />
        <h2 className="section-title">30-60-90 Day <em>Ramp Plan</em></h2>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 8 }}>
          <PillarCard
            Icon={Clock}
            title="30 Days"
            items={[
              "Complete product training.",
              "Shadow calls and demos.",
              "Learn ICP and use cases.",
            ]}
          />
          <PillarCard
            Icon={Calendar}
            title="60 Days"
            items={[
              "Deliver demo segments.",
              "Support active deals.",
              "Build solution designs.",
            ]}
          />
          <PillarCard
            Icon={Trophy}
            title="90 Days"
            items={[
              "Run full demo cycles.",
              "Own technical strategy.",
              "Achieve technical wins.",
            ]}
          />
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={8} label="ONGOING ENABLEMENT" />
          <h2 className="section-title">Ongoing <em>Enablement</em></h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 6 }}>
          <PillarCard
            Icon={GraduationCap}
            title="Weekly"
            items={["Demo practice.", "Deal reviews."]}
          />
          <PillarCard
            Icon={BookOpen}
            title="Monthly"
            items={["Product updates.", "Competitive training."]}
          />
          <PillarCard
            Icon={Sparkles}
            title="Quarterly"
            items={["Certification.", "Industry deep dives."]}
          />
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={9} label="READINESS" />
          <h2 className="section-title">Manager <em>Readiness Checklist</em></h2>
        </div>

        <div style={{ border: "1px solid #43B5BF", padding: "12px 16px", background: "rgba(67,181,191,0.04)", borderRadius: 8, marginTop: 6 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
            {[
              "Can run discovery independently.",
              "Can deliver tailored demos.",
              "Can design solutions.",
              "Can influence deals.",
              "Can handle objections.",
              "Can recognize their own gaps and ask for help instead of guessing and making assumptions.",
            ].map((t, i) => (
              <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                <CheckCircle2 size={13} style={{ stroke: "url(#se-icon-grad)", marginTop: 2, flexShrink: 0 }} />
                <div style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{t}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 12, fontSize: 10.5, color: "#555567", fontFamily: "'Inter', sans-serif", lineHeight: 1.5 }}>
          <div style={{ fontWeight: 600, color: "#1A1A2E", marginBottom: 4 }}>Readiness is validated through multiple channels:</div>
          <ul style={{ margin: 0, paddingLeft: 18, listStyle: "disc" }}>
            <li>Completion of required training</li>
            <li>Shadowing of approved SEs</li>
            <li>Demo presentation</li>
            <li>Partner and customer-facing role plays</li>
            <li>Manager final approval</li>
          </ul>
        </div>

        <div className="closing-line" style={{ marginTop: 18 }}>
          A high-performing Sales Engineer operates as a business-focused technical advisor who drives customer outcomes and directly influences revenue.
        </div>

        <PageFooterText pageNum={5} />
        <PageFooter />
      </div>
    </div>
  );
};

export default SalesEngineerPlaybook;
