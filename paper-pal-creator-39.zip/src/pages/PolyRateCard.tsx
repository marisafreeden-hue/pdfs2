import React from "react";
import "./GoEngageDatasheet.css";
import polyLogo from "@/assets/poly-logo.png.asset.json";

const PageFooter = () => (
  <>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const Logo = () => (
  <div className="logo" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
      <div style={{ width: 1, height: 26, background: "#D5D5DD" }} />
      <img src={polyLogo.url} alt="Poly" style={{ height: 22, width: "auto", display: "block" }} />
    </div>
    <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 9, fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: "#888" }}>
      Poly Rate Card · As of 6.10.26
    </div>
  </div>
);

type Row = { name: string; desc: string; msrp: string; purchase: string; m36: string; m12: string };

const phones: Row[] = [
  { name: "Edge E220", desc: "2.8\" color IPS LCD display, four-line keys supporting up to 16 lines, integrated Bluetooth® 5.0, HD voice, Acoustic Fence, and NoiseBlockAI technologies, delivering quality audio and seamless connectivity.", msrp: "$183.95", purchase: "$150.00", m36: "$8.00", m12: "$10.00" },
  { name: "Edge E350", desc: "3.5\" color IPS LCD display, eight-line keys supporting up to 32 lines, integrated Bluetooth® 5.0, HD voice, Acoustic Fence, and NoiseBlockAI technologies, delivering quality audio and seamless connectivity.", msrp: "$287.95", purchase: "$200.00", m36: "$12.00", m12: "$14.00" },
  { name: "Edge E450", desc: "Two color IPS LCD displays (3.5\" and 2.4\"), fourteen-line keys supporting up to 44 lines, integrated Bluetooth® 5.0, optional expansion module support, HD voice, Acoustic Fence, and NoiseBlockAI technologies, delivering quality audio and seamless connectivity.", msrp: "$376.95", purchase: "$290.00", m36: "$15.00", m12: "$17.00" },
  { name: "Edge E550", desc: "5\" color IPS LCD display, twelve-line keys supporting up to 48 lines, integrated Bluetooth® 5.0, optional expansion module support, HD voice, Acoustic Fence, and NoiseBlockAI technologies, delivering quality audio and seamless connectivity.", msrp: "$406.95", purchase: "$315.00", m36: "$16.00", m12: "$18.00" },
  { name: "E Expansion Module (for E450/E550)", desc: "Expansion Module with 5\" color LCD display, 22 multifunctional line keys, plug-and-play setup powered by the host phone, and a user-friendly interface for streamlined call handling.", msrp: "$299.95", purchase: "$199.00", m36: "$12.00", m12: "$14.00" },
  { name: "RealPresence Trio 8300", desc: "Conference phone with three directional microphones providing up to 12 ft/3.7 m pickup range, integrated Bluetooth® 5.0, Poly NoiseBlock technology, and a large 3.5\" monochrome LCD display for professional-quality conferencing.", msrp: "$557.95", purchase: "$485.00", m36: "$21.00", m12: "$24.00" },
];

const accessories: Row[] = [
  { name: "Obi402", desc: "ATA with four FXS ports, support for up to four VoIP services, T.38 fax capabilities, and robust call routing features for versatile connectivity.", msrp: "$134.95", purchase: "$95.00", m36: "$6.00", m12: "$8.00" },
  { name: "ObiWIFI5G", desc: "WiFi USB adapter with dual-band 2.4 GHz and 5 GHz Wi-Fi support, USB connectivity, and secure WPA/WPA2 encryption for reliable wireless network access.", msrp: "$33.95", purchase: "$33.95", m36: "—", m12: "—" },
  { name: "Sync20+", desc: "Speakerphone with three-microphone array, full-duplex audio, up to 20 hours of battery life, and integrated USB and Bluetooth® connectivity for professional-quality conferencing.", msrp: "$167.95", purchase: "$167.95", m36: "$9.00", m12: "$11.00" },
  { name: "Trio Microphone Kit", desc: "Two expansion microphones for the Trio 8300, with 360° voice pickup, and extended audio range for larger meeting spaces.", msrp: "$209.00", purchase: "$209.00", m36: "$14.00", m12: "$15.00" },
  { name: "APP-51 (for Savi 8420)", desc: "Electronic hook switch for the Savi 8420, with remote call control functionality, ring alert integration, and seamless Polycom phone compatibility for professional wireless headset operation.", msrp: "$98.95", purchase: "$65.00", m36: "$4.00", m12: "$5.00" },
  { name: "Wallmount (for Edge series)", desc: "Secure wall mounting capability for Edge series phones, with vertical phone positioning and space-saving installation design for professional workspace optimization.", msrp: "$40.65", purchase: "$30.00", m36: "—", m12: "—" },
];

const headsets: Row[] = [
  { name: "Blackwire 5210", desc: "Wired single-ear headset with noise-canceling flexible boom microphone, dual USB-C/3.5mm connectivity, monaural on-ear design, and inline call controls for professional all-day communication comfort.", msrp: "$111.95", purchase: "$80.00", m36: "$5.00", m12: "$6.00" },
  { name: "Savi 8420", desc: "Wireless dual-ear headset with DECT wireless connectivity, 3-way device connection capability, up to 13 hours talk time, and hybrid active noise cancellation for professional office communication.", msrp: "$514.95", purchase: "$300.00", m36: "$18.00", m12: "$19.00" },
  { name: "Voyager 4310 UC", desc: "Wireless single-ear headset with Bluetooth 5.2 connectivity, up to 24 hours talk time, 50-meter wireless range, and noise-canceling boom microphone for professional mobile productivity.", msrp: "$213.95", purchase: "$130.00", m36: "$8.00", m12: "$9.00" },
  { name: "Voyager 4320 UC", desc: "Wireless dual-ear headset with Bluetooth 5.2 connectivity, up to 24 hours talk time, 50-meter wireless range, and noise-canceling technology for immersive stereo communication.", msrp: "$233.95", purchase: "$140.00", m36: "$8.00", m12: "$9.00" },
  { name: "Voyager 5200", desc: "Wireless single-ear headset with four-microphone noise-canceling array, Bluetooth 5.0 connectivity, up to 7 hours talk time, and WindSmart technology for professional mobile communication clarity.", msrp: "$264.95", purchase: "$175.00", m36: "$11.00", m12: "$12.00" },
  { name: "Voyager Focus2 w/ Stand", desc: "Wireless dual-ear headset with three-level hybrid active noise cancellation, up to 25 hours talk time, Qi wireless charging stand, and Acoustic Fence technology for immersive professional focus.", msrp: "$335.95", purchase: "$190.00", m36: "$12.00", m12: "$13.00" },
  { name: "Voyager Free 60", desc: "Wireless dual earbuds with true wireless Bluetooth 5.3 connectivity, touchscreen charging case, Qi wireless charging capability, and multipoint device pairing for premium mobile productivity.", msrp: "$279.95", purchase: "$260.00", m36: "$16.00", m12: "$17.00" },
];

const Table: React.FC<{ category: string; rows: Row[] }> = ({ category, rows }) => (
  <table className="outcomes-table" style={{ marginBottom: 14, tableLayout: "fixed" }}>
    <colgroup>
      <col style={{ width: "15%" }} />
      <col style={{ width: "45%" }} />
      <col style={{ width: "10%" }} />
      <col style={{ width: "10%" }} />
      <col style={{ width: "10%" }} />
      <col style={{ width: "10%" }} />
    </colgroup>
    <thead>
      <tr>
        <th style={{ fontSize: 7 }}>{category}</th>
        <th style={{ fontSize: 7 }}>Description</th>
        <th style={{ textAlign: "right", fontSize: 7 }}>MSRP</th>
        <th style={{ textAlign: "right", fontSize: 7 }}>Purchase</th>
        <th style={{ textAlign: "right", fontSize: 7 }}>36 Mo Rental</th>
        <th style={{ textAlign: "right", fontSize: 7 }}>12 Mo Rental</th>
      </tr>
    </thead>
    <tbody>
      {rows.map((r) => (
        <tr key={r.name}>
          <td style={{ whiteSpace: "normal", width: "auto", fontSize: 9 }}>{r.name}</td>
          <td style={{ fontSize: 9, lineHeight: 1.4 }}>{r.desc}</td>
          <td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontSize: 9 }}>{r.msrp}</td>
          <td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontWeight: 700, color: "#1A1A2E", fontSize: 9 }}>{r.purchase}</td>
          <td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontSize: 9 }}>{r.m36}</td>
          <td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontSize: 9 }}>{r.m12}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

const PolyRateCard: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <Logo />


        <h2 className="section-title" style={{ marginTop: 4, fontSize: 16 }}>
          Desk <em>Phones</em>
        </h2>
        <Table category="Phones" rows={phones} />

        <h2 className="section-title" style={{ fontSize: 16 }}>Accessories</h2>
        <Table category="Accessories" rows={accessories.slice(0, 4)} />

        <PageFooter />
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2" style={{ paddingTop: 32 }}>
        <Logo />

        <h2 className="section-title" style={{ fontSize: 16 }}>Accessories <em>(continued)</em></h2>
        <Table category="Accessories" rows={accessories.slice(4)} />

        <h2 className="section-title" style={{ fontSize: 16 }}>Headsets</h2>
        <Table category="Headsets" rows={headsets} />


        <PageFooter />
      </div>
    </div>
  );
};

export default PolyRateCard;
