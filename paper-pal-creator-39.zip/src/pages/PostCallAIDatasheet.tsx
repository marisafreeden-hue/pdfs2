import React from "react";
import "./GoEngageDatasheet.css";

const PostCallAIDatasheet: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="hero">
          <div>
            <h1 className="hero-headline">
              Post-Call <em>AI</em>
            </h1>
            <p className="hero-body">
              Every conversation has answers. Post-Call AI helps you find them.
            </p>
            <p className="hero-desc">
              Turn customer conversations into actionable insights with AI-powered summaries, sentiment analysis, and transcription built into GoContact — so teams can see what happened and improve performance without reviewing every interaction.
            </p>
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <div className="stat-label-top">AI-Powered Call Insights</div>
              <div className="stat-value">
                <span className="stat-value-sans">20+ </span>
              </div>
              <div className="stat-desc">
                Languages supported for multilingual<br />contact center environments
              </div>
            </div>
          </div>
        </div>

        <hr />

        {/* The Problem */}
        <h2 className="section-title">The <em>Problem</em></h2>
        <p className="section-body">
          Your customers tell you what is working — and what isn't — every day. The challenge is finding those signals across thousands of conversations. Traditional call reviews require teams to manually listen, document findings, and interpret what happened.
        </p>

        <div className="stats-row">
          <div className="stat-item">
            <div className="num">Manual</div>
            <div className="lbl">
              <strong>Too much manual review</strong>
              QA teams spend hours listening to calls and documenting what AI can surface automatically
            </div>
          </div>
          <div className="stat-item">
            <div className="num">Missed</div>
            <div className="lbl">
              <strong>Customer signals get missed</strong>
              Recurring frustrations and experience gaps stay hidden when only a fraction of calls are reviewed.
            </div>
          </div>
          <div className="stat-item">
            <div className="num">Late</div>
            <div className="lbl">
              <strong>Coaching comes too late</strong>
              Without fast, objective insight, managers have less to guide agent development and performance
            </div>
          </div>
        </div>

        <hr className="section-divider" />

        <h2 className="section-title" style={{ marginTop: "12px" }}>What Post-Call AI <em>Does</em></h2>
        <p className="section-body">
AI-powered post-call analysis built into GoContact gives teams immediate visibility into every customer interaction — without adding another system to manage.
        </p>

        <div className="feature-grid">
          <div className="feature-item">
            <div className="feature-title">AI-generated call summaries</div>
            <div className="feature-body">
              A concise overview of every conversation so managers grasp key topics fast.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Customer &amp; agent transcription</div>
            <div className="feature-body">
              A detailed transcript that clearly separates customer from agent for easy review.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Sentiment analysis</div>
            <div className="feature-body">
              Understand the overall tone of an interaction with AI sentiment analysis based on the transcript.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Conversation playback &amp; talk time</div>
            <div className="feature-body">
              Review each side's audio, jump to key moments, and see talk-time balance.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Built into GoContact Quality</div>
            <div className="feature-body">
              Access Post-Call AI in GoContact Quality Manager, inside the workflow QA already uses.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Multilingual analysis</div>
            <div className="feature-body">
              Support multilingual operations with Post-Call AI across more than 20 languages.
            </div>
          </div>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <h2 className="section-title">Turn Conversations Into <em>Action</em></h2>

        <div className="outcomes-container">
          <div className="outcomes-blur" />
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Team</th>
                <th>Use Post-Call AI to</th>
                <th>Business Impact</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Quality Assurance</td>
                <td>Review summaries, sentiment and transcripts within each individual call</td>
                <td>Save audit time by focusing on the segments of the calls that make sense to analyze</td>
              </tr>
              <tr>
                <td>Contact Center Leaders</td>
                <td>Identify recurring customer themes and service issues</td>
                <td>Make faster decisions around processes, staffing and training</td>
              </tr>
              <tr>
                <td>CX Leaders</td>
                <td>Understand sentiment and friction across customer interactions</td>
                <td>Find experience gaps and prioritize improvements</td>
              </tr>
              <tr>
                <td>Agent Managers</td>
                <td>Use objective conversation data during coaching</td>
                <td>Deliver more consistent, evidence-based feedback</td>
              </tr>
            </tbody>
          </table>
        </div>

        <hr />

        <h2 className="section-title">Why <em>Now</em></h2>
        <p className="section-body">
          Your contact center already holds an enormous source of customer intelligence: the conversations
          happening every day. But when understanding those conversations depends on manually listening to
          recordings, valuable insight arrives slowly — or never gets surfaced at all. Post-Call AI turns every
          analyzed interaction into structured information your teams can use. Managers can quickly understand
          what happened, how the customer felt, and where attention is needed in each interaction. That means
          less time listening to calls — and more time improving the experience.
        </p>

        <p className="closing-line">
          Your customers are already telling you what needs to improve.<br />
          Post-Call AI helps you hear it at scale.
        </p>

        <div className="about-section" style={{ marginTop: 48 }}>
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent CX solutions for midmarket organizations—empowering business teams to design modern, frictionless customer experiences with AI that's practical, easy to use, and purpose-built for how they work.
          </p>
          <p className="about-addon">
            Post-Call AI is integrated with the GoContact Quality Manager.
          </p>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default PostCallAIDatasheet;
