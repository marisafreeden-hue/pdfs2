import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>Guía técnica para partners · v1.0 · junio de 2026</div>
    <div>© Broadvoice 2026</div>
  </div>
);



const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ num?: string; children: React.ReactNode }> = ({
  children,
}) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}

  </h2>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Bullets: React.FC<{ items: React.ReactNode[]; tight?: boolean }> = ({
  items,
  tight,
}) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: tight ? 1.5 : 1.65,
      paddingLeft: 20,
      margin: "6px 0 10px",
      listStyleType: "disc",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 2 }}>
        {it}
      </li>
    ))}
  </ul>
);

const Callout: React.FC<{ children: React.ReactNode; tone?: "info" | "warn" }> = ({
  children,
  tone = "info",
}) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: tone === "warn" ? "#8a4a00" : "#1A1A2E",
      background: tone === "warn" ? "#FFF6E5" : "#EEF7F8",
      borderLeft: `3px solid ${tone === "warn" ? "#D97706" : "#43B5BF"}`,
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const SimpleTable: React.FC<{
  head: string[];
  rows: (string | React.ReactNode)[][];
  colWidths?: string[];
}> = ({ head, rows, colWidths }) => (
  <table
    style={{
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "'Inter', sans-serif",
      fontSize: 9.5,
      margin: "8px 0 12px",
      tableLayout: "fixed",
    }}
  >
    <colgroup>
      {(colWidths || head.map(() => "auto")).map((w, i) => (
        <col key={i} style={{ width: w }} />
      ))}
    </colgroup>
    <thead>
      <tr style={{ background: "#F3F3F8" }}>
        {head.map((h, i) => (
          <th
            key={i}
            style={{
              padding: "9px 12px",
              textAlign: "left",
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: "0.07em",
              textTransform: "uppercase",
              color: "#555567",
              borderBottom: "2px solid #E2E2EC",
            }}
          >
            {h}
          </th>
        ))}
      </tr>
    </thead>
    <tbody>
      {rows.map((r, ri) => (
        <tr key={ri} style={{ background: ri % 2 === 0 ? "#FFFFFF" : "#FAFAFA" }}>
          {r.map((c, ci) => (
            <td
              key={ci}
              style={{
                padding: "9px 12px",
                color: "#555567",
                borderBottom: "1px solid #E2E2EC",
                lineHeight: 1.45,
                verticalAlign: "top",
                fontWeight: ci === 0 ? 700 : 400,
                ...(ci === 0 ? { color: "#1A1A2E" } : {}),
              }}
            >
              {c}
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  </table>
);

const PartnerTechGuideESMadrid: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
        .rounded-table table { margin: 0 !important; }
        .rounded-table tbody tr:last-child td { border-bottom: none !important; }
      `}</style>


      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Exportar como PDF
      </button>

      {/* ===== PAGE 1 – Cover & Intro ===== */}
      <div className="page">
        <PageHeader eyebrow="Guía técnica para partners" />

        <div className="partner-hero" style={{ marginTop: 60, marginBottom: 10 }}>
          <h1 className="hero-headline" style={{ fontSize: 36, lineHeight: 1.05, marginBottom: 4, whiteSpace: "nowrap" }}>
            Guía <em>técnica</em> para partners
          </h1>


          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Requisitos de soporte, SLA, entrega y certificación para distribuidores.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />


        <PageBody>
          <div style={{ height: 22 }} />
          <SectionTitle num="1.">Introducción</SectionTitle>

          <Body>
            Esta guía proporciona a los partners de Broadvoice todo lo necesario para cualificar,
            dimensionar y entregar un despliegue CCaaS de GoContact con éxito. Consolida
            los compromisos de soporte, la metodología de entrega y los prerrequisitos
            técnicos que toda sede de cliente debe cumplir antes de la puesta en producción,
            para que los partners puedan fijar expectativas claras y proteger el tiempo hasta obtener valor.
          </Body>
          <Body>
            <strong>Audiencia:</strong> Preventa de partners, arquitectos de soluciones y jefes de proyecto
            que revenden Broadvoice / GoContact CCaaS.
          </Body>

          <Body>
            <strong>Alcance:</strong> Modelo de soporte, SLA, metodología de proyecto y los
            requisitos técnicos y de infraestructura que una sede de cliente debe cumplir antes
            de la puesta en producción.
          </Body>
          <Body>
            Como distribuidor sois la primera línea de cualificación. Antes de firmar con un
            cliente, debéis poder:
          </Body>
          <ol
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: "#555567",
              lineHeight: 1.65,
              paddingLeft: 22,
              margin: "6px 0 10px",
              listStyleType: "decimal",
            }}
          >

            <li style={{ marginBottom: 2 }}>
              Establecer las expectativas correctas sobre <strong>soporte y SLA</strong> (y las
              penalizaciones que Broadvoice respetará).
            </li>
            <li style={{ marginBottom: 2 }}>
              Explicar la <strong>metodología de entrega</strong> y los recursos que el cliente
              debe asignar.
            </li>
            <li style={{ marginBottom: 2 }}>
              Recopilar la <strong>información de red, IP, telefonía y endpoints</strong>{" "}
              que GoContact necesita para aprovisionar el tenant.
            </li>
          </ol>

          <Callout>
            Una sede que no cumpla los requisitos de la sección 5 no superará la
            certificación, independientemente del acuerdo comercial.
          </Callout>

          <hr style={{ margin: "16px 0" }} />

          <SectionTitle num="2.">Modelo de soporte y marco de SLA</SectionTitle>
          <Body>
            GoContact se entrega con un <strong>modelo de SLA de cuatro niveles</strong>, calculado
            anualmente sobre el año natural (1 de enero – 31 de diciembre). La asignación del nivel depende de
            (a) qué componente esté afectado y (b) si el impacto es total o
            parcial.
          </Body>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["Clase", "Alcance", "Disponib. anual", "Restauración máx."]}
              colWidths={["10%", "55%", "17%", "18%"]}
              rows={[
                [
                  "A",
                  "Indisponibilidad total de funciones Core o del acceso a la plataforma",
                  "99.9%",
                  "4 horas",
                ],
                [
                  "B",
                  "Indisponibilidad parcial de Core, O pérdida total de funciones de soporte operativo",
                  "99.5%",
                  "8 horas",
                ],
                [
                  "C",
                  "Indisponibilidad total de funciones secundarias (Calidad, E-Learning, Calendario)",
                  "98.0%",
                  "5 días laborables",
                ],
                [
                  "D",
                  "Indisponibilidad parcial de funciones de soporte operativo",
                  "98.0%",
                  "10 días laborables",
                ],
              ]}
            />
          </div>

        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – SLA detail ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 2 · Detalle de SLA" />
        <PageBody>
          <div style={{ height: 30 }} />
          {[
            {
              title: "SLA-A — Acceso a Core / plataforma (caída total)",
              intro: "Se activa cuando el cliente no puede:",
              items: [
                "Acceder a la plataforma en absoluto",
                "Realizar o recibir llamadas",
                "Enviar o recibir correos electrónicos",
                "Ver o gestionar tickets",
                "Recibir o gestionar webchats",
                "Usar el módulo Scripts",
                "Usar cualquier canal de comunicación",
              ],
            },
            {
              title: "SLA-B — Core parcial, o soporte operativo total",
              intro: "Fallos parciales / intermitentes de cualquier elemento de SLA-A, o pérdida total de:",
              items: [
                "Informes",
                "Cuadros de mando",
                "Gestión de usuarios",
                "Acceso a grabaciones de llamadas",
                "Módulo CRM",
                "Módulo de gestión de bases de datos",
              ],
            },
            {
              title: "SLA-C — Funciones secundarias (caída total)",
              intro: "Fallo total de cualquiera de estos módulos:",
              items: ["Calidad", "E-Learning", "Calendario"],
            },
            {
              title: "SLA-D — Soporte operativo (caída parcial)",
              intro: "Fallos parciales de:",
              items: [
                "Calidad",
                "E-Learning",
                "Calendario",
                "Grabaciones de llamadas",
                "CRM",
                "Gestión de bases de datos",
                "Informes",
                "Cuadros de mando",
                "Gestión de usuarios",
              ],
            },
            {
              title: "Exclusiones comunes de SLA",
              intro: "El siguiente tiempo de inactividad no cuenta contra ningún SLA:",
              items: [
                "Ventanas de mantenimiento correctivo o evolutivo programadas",
                "Eventos fuera del control razonable de GoContact (fallos/latencia de internet, configuración incorrecta del cliente o de terceros, fallos de LAN del cliente, integraciones externas, servicios de telecomunicaciones contratados por el cliente)",
                "Incidencias cuya resolución requiera cambios en el código fuente de cualquier componente del ecosistema GoContact",
              ],
            },
          ].map((sec, i) => (
            <div
              key={i}
              style={{
                border: "1px solid #E2E2EC",
                borderRadius: 8,
                padding: "12px 16px 10px",
                marginBottom: 10,
                background: "#FFFFFF",
              }}
            >
              <h2
                className="section-title"
                style={{
                  fontSize: 22,
                  margin: "0 0 6px",
                  lineHeight: 1.2,
                  display: "block",
                }}
              >
                {sec.title}
              </h2>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#555567",
                  margin: "0 0 6px",
                  lineHeight: 1.5,
                }}
              >
                {sec.intro}
              </p>
              <ul
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#555567",
                  lineHeight: 1.55,
                  paddingLeft: 20,
                  margin: 0,
                  listStyleType: "disc",
                  columnCount: 2,
                  columnGap: 28,
                }}
              >
                {sec.items.map((it, j) => (
                  <li key={j} style={{ marginBottom: 2, breakInside: "avoid" }}>
                    {it}
                  </li>
                ))}
              </ul>

            </div>
          ))}
        </PageBody>
        <PageFooter />
      </div>


      {/* ===== PAGE 3 – Availability, Penalties, Methodology ===== */}
      <div className="page">
        <PageHeader eyebrow="Secciones 2.6 – 2.7 · Disponibilidad y penalizaciones" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="2.6">Compromiso de disponibilidad del servicio</SectionTitle>
          <Body>
            El servicio se presta 24×7. El mantenimiento planificado se realiza en ventanas de baja actividad
            con aviso previo; si debe realizarse en horario productivo, el
            cliente debe aprobarlo y se acuerda un plan de continuidad de negocio; esas
            ventanas quedan entonces también excluidas del cálculo del SLA. El SLA se mide{" "}
            <strong>globalmente</strong> en todas las sedes donde se ejecuta la plataforma. Si
            la disponibilidad mensual cae por debajo del límite, el cliente puede solicitar un
            crédito <strong>en los 30 días posteriores al cierre del mes</strong>.
          </Body>

          <div style={{ height: 28 }} />

          <SectionTitle num="2.7">Penalizaciones (crédito sobre la cuota mensual del servicio)</SectionTitle>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["SLA", "SLA mensual", "> 0% – ≤ 0.5%", "> 0.5% – ≤ 1%", "> 1%"]}
              colWidths={["12%", "22%", "22%", "22%", "22%"]}
              rows={[
                ["A", "99.90%", "2%", "5%", "10%"],
                ["B", "99.50%", "—", "2%", "5%"],
                ["C y D", "98.00%", "—", "—", "—"],
              ]}
            />
          </div>
          <Callout>
            Los partners deben incorporar los créditos de servicio en los modelos comerciales, especialmente para
            clientes con fuerte dependencia de Core (exposición a SLA-A).
          </Callout>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – Delivery methodology & Pre-sales checklist ===== */}
      <div className="page">
        <PageHeader eyebrow="Secciones 3 – 4 · Entrega y discovery" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="3.">Metodología de entrega</SectionTitle>
          <Body>
            Todo despliegue CCaaS de GoContact sigue el mismo marco por fases para que
            partners y clientes compartan un único playbook desde la firma del contrato hasta el
            estado estable. La sección 3 describe las cuatro fases; la sección 4 enumera la
            información que debéis recopilar del cliente antes del kickoff.
          </Body>
          <Body>Las implementaciones de GoContact CCaaS se ejecutan como proyectos por fases:</Body>
          <Bullets
            items={[
              <>
                <strong>Planificación</strong> — discovery, requisitos, diseño.
              </>,
              <>
                <strong>Ejecución / Implementación</strong> — aprovisionamiento,
                configuración, integración, pruebas.
              </>,
              <>
                <strong>Cierre</strong> — traspaso, aceptación, transferencia al Customer
                Success Manager (CSM).
              </>,
              <>
                <strong>Acompañamiento</strong> — acompañamiento posterior a la puesta en producción por parte del CSM.
              </>,
            ]}
          />
          <Body>
            La metodología se basa en <strong>PRINCE2®</strong>, alineada con las mejores prácticas de PMI /
            PMBOK®. Se espera que los partners proporcionen un PM homólogo,
            un responsable técnico y un contacto de red durante la ejecución.
          </Body>

          <hr style={{ margin: "16px 0" }} />

          <SectionTitle num="4.">Discovery de preventa</SectionTitle>
          <Body>
            Usad estas preguntas para cualificar la oportunidad y dimensionar el despliegue
            antes de presupuestar. Las respuestas alimentan directamente el dimensionamiento, el diseño de red, la integración de telefonía
            y el plan de proyecto; las lagunas aquí son la causa más habitual de
            retrasos en las puestas en producción. Revisad cada categoría con los interlocutores técnicos
            y de negocio del cliente.
          </Body>

          <SubHead>Dimensionamiento y operaciones</SubHead>
          <Bullets
            items={[
              "¿Cuántos agentes concurrentes deberá soportar la plataforma y cuál es el crecimiento previsto a 12 meses?",
              "¿Cuál es el patrón de turnos de los agentes (24×7, horario laboral, ventanas pico) y el volumen de llamadas en hora punta?",
              "¿Cuántas sedes están en el alcance, dónde se ubican y se prevén agentes remotos/en casa?",
            ]}
          />

          <SubHead>Red y conectividad</SubHead>
          <Bullets
            items={[
              "¿Cuál es la topología WAN / Internet existente (internet dedicado, MPLS, híbrida) y qué redundancia existe?",
              "¿Qué equipamiento LAN hay instalado (modelos de switches, capacidad de gestión, PoE) y quién es su propietario?",
              "¿Hay agentes trabajando actualmente por Wi-Fi y puede eliminarse antes de la puesta en producción?",
            ]}
          />

          <SubHead>Telefonía y numeración</SubHead>
          <Bullets
            items={[
              "¿Qué IP públicas se usarán para el troncal SIP y hay una IP de respaldo disponible para failover?",
              "¿Qué operador(es) proporcionarán los servicios SIP, qué lado origina las llamadas y se requiere portabilidad de números?",
              "¿Cuál es el plan de numeración entrante (DID, menús IVR, horario laboral, calendarios de festivos)?",
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – Pre-Sales Discovery (cont.) ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 4 · Discovery de preventa (cont.)" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="4.">Discovery de preventa (continuación)</SectionTitle>

          <SubHead>Canales y outbound</SubHead>
          <Bullets
            items={[
              "¿Qué modos de marcación outbound se necesitan (preview, progresivo, predictivo) y qué reglas de cumplimiento aplican (TCPA, DNC, opt-out)?",
              "¿Qué canales están en el alcance además de voz (correo electrónico, webchat, WhatsApp, SMS, social) y con qué volumen?",
            ]}
          />

          <SubHead>Cumplimiento y grabación</SubHead>
          <Bullets
            items={[
              "¿Qué periodo de retención de grabaciones de llamadas se requiere (90 días por defecto) y aplica alguna normativa (PCI, HIPAA, GDPR)?",
            ]}
          />

          <SubHead>Endpoints e integraciones</SubHead>
          <Bullets
            items={[
              "¿Cuál es el inventario de endpoints de agente (especificaciones del PC, auriculares, SO, navegador) y el ciclo de renovación de equipos?",
              "¿Qué integraciones se requieren (CRM, ticketing, WFM, BI, API externas) y quién es propietario de cada sistema?",
            ]}
          />

          <SubHead>Informes e interlocutores</SubHead>
          <Bullets
            items={[
              "¿Quiénes son el patrocinador ejecutivo, el responsable técnico, el contacto de red y el champion de usuarios finales del lado del cliente?",
            ]}
          />

          <SubHead>Calendario y criterios de éxito</SubHead>
          <Bullets
            items={[
              "¿Cuál es la fecha objetivo de puesta en producción y hay periodos bloqueados (temporada alta, auditorías, congelaciones de sistemas)?",
              "¿Cómo se define el éxito a los 30, 60 y 90 días tras la puesta en producción?",
            ]}
          />

          <Callout>
            <strong>Cerrad el círculo:</strong> Antes de presupuestar, obtened la aprobación del número de agentes,
            canales, integraciones y fecha de puesta en producción — por escrito. Cada suposición que
            dejéis abierta se convierte en una solicitud de cambio, un retraso o un impacto en el margen durante la entrega.
          </Callout>
        </PageBody>
        <PageFooter />
      </div>



      {/* ===== PAGE 4 – Technical requirements (IP, LAN, Access) ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 5 · Requisitos técnicos" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="5.1">Direccionamiento IP y puertos</SectionTitle>
          <Body>
            <strong>Rango IP de la plataforma GoContact (PT / ES):</strong>{" "}
            <code style={{ background: "#F3F3F8", padding: "1px 6px", borderRadius: 3 }}>
              185.133.136.0/22
            </code>
          </Body>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["Finalidad", "Protocolo", "Puertos"]}
              colWidths={["40%", "20%", "40%"]}
              rows={[
                ["Señalización SIP", "UDP", "5060, 5062, 5090"],
                ["Señalización SIP (TLS)", "TCP", "5061"],
                ["Audio RTP (bajo)", "UDP", "16384–32767"],
                ["Audio RTP (alto)", "UDP", "49152–65535"],
                ["Gestión de IPBX local (solo on-prem)", "UDP", "10000–10050"],
                ["Gestión de plataforma GoContact", "TCP", "50000–50010"],
              ]}
            />
          </div>
          <Callout>
            Todos los puertos deben permitirse bidireccionalmente a través del firewall del cliente
            contra el rango IP anterior.
          </Callout>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 10,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.2">Requisitos de LAN</SectionTitle>
            <Body>
              VoIP es muy sensible a la estabilidad de la LAN. La plataforma{" "}
              <strong>no admite Wi-Fi</strong> para agentes.
            </Body>
            <Bullets
              tight
              items={[
                "Cableado estructurado, Cat 5E o superior.",
                "Switches gestionados de capa 2 con: LACP, 802.1Q, STP, PoE.",
                "Puertos de switch 10/100/1000 Base-T.",
                "Conmutación: 24 puertos > 40 Mbps · 48 puertos > 70 Mbps.",
                "Referencia: Huawei S5700 LI, S5710 LI (o equivalente).",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 10,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.3">Acceso IP a la plataforma</SectionTitle>
            <Body>
              Todo el tráfico con la plataforma GoContact — HTTP/HTTPS, SIP, RTP, puertos de gestión
              — debe tratarse como <strong>tiempo real</strong>.
            </Body>
            <SubHead>Ancho de banda por agente (regla orientativa)</SubHead>
            <Bullets
              tight
              items={[
                "~100 kbps voz",
                "~200 kbps otros canales / funciones",
                "≈ 300 kbps total por agente concurrente",
              ]}
            />
            <Body>
              El acceso puede proporcionarse mediante Internet dedicado, VPN MPLS o circuito
              dedicado. El router CPE debe ser equivalente o superior a un{" "}
              <strong>Cisco 1921/K9</strong>.
            </Body>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Access types, QoS, Workstation ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 5 · Acceso y calidad" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.4">Acceso a Internet dedicado</SectionTitle>
            <Bullets
              tight
              items={[
                "NO garantiza QoS entre la sede y el datacenter.",
                "Funciona en la práctica hasta ~50 agentes con internet empresarial estándar.",
                "Recomendado: un circuito dedicado separado del internet general del cliente.",
                "Perfil de referencia en producción: 100 Mbps simétricos, IP estática.",
                "La latencia al datacenter de GoContact debe ser < 100 ms.",
                "Todo el tráfico cruza la Internet pública — revisad las necesidades de seguridad del cliente.",
                "> 50 y hasta 200 agentes: es obligatorio un circuito dedicado de GoContact O MPLS / L2.",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.5">Acceso MPLS / VPN</SectionTitle>
            <Bullets
              tight
              items={[
                "Recomendado para cualquier operación — cumple QoS y seguridad.",
                "Se establece entre el datacenter de GoContact y la sede del cliente.",
                "Debe dimensionarse según el ancho de banda por agente.",
                "El datacenter de GoContact puede terminar VPN MPLS redundantes.",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.6">Configuración de calidad de voz (QoS)</SectionTitle>
            <Bullets
              tight
              items={[
                "VLAN dedicada para voz en cada sede, separada de datos.",
                "Priorizad la voz saliente (uplink) en el router con ancho de banda garantizado por canal.",
                <>
                  Códec: <strong>G.711a</strong>, ~95 kbps por canal.
                </>,
                "Los teléfonos SIP marcan señalización DSCP=40, audio DSCP=46.",
                "Aplicad QoS mediante segmentación VLAN, DSCP (40/46) o IP Precedence 5.",
                "Cola prioritaria para paquetes de audio: Expedited Forwarding (EF).",
              ]}
            />
          </div>

          <div style={{ marginBottom: 12 }}>
            <SectionTitle num="5.7">Puesto de agente (PC)</SectionTitle>
            <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 4px" }}>
              <SimpleTable
                head={["Componente", "Mínimo"]}
                colWidths={["30%", "70%"]}
                rows={[
                  ["CPU", "Intel Core i3 / i5"],
                  ["Disco", "60 GB"],
                  ["RAM", "4 GB"],
                  ["SO", "Windows 7 o posterior"],
                  ["Navegador", "Google Chrome (última versión)"],
                  ["Softphone", "X-Lite, MicroSIP o Zoiper"],
                  ["Periféricos", "Auriculares USB, monitor, teclado, ratón"],
                ]}
              />
            </div>
          </div>

        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 – IPERF + Recording & SIP Trunking ===== */}
      <div className="page">
        <PageHeader eyebrow="Secciones 5.8 – 6 · Pruebas, grabación y SIP" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.8">Pruebas de conectividad IPERF</SectionTitle>
            <Body>
              Antes de la puesta en producción, la conectividad se valida con <strong>IPERF</strong>. El
              cliente debe <strong>abrir temporalmente TCP/UDP 32000</strong> durante las
              pruebas; puede cerrarse después.
            </Body>
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="6.1">Grabación de llamadas y retención</SectionTitle>
            <Body>
              Broadvoice (GoTelecom — "A Broadvoice Company") incluye{" "}
              <strong>grabación y retención hasta 90 días sin coste adicional</strong> como
              parte del servicio CCaaS. El partner debe verificar si el sector o la jurisdicción del cliente
              exige una retención más larga (p. ej., Deliberación CNPD
              Nº 1039/2017 en Portugal). La retención ampliada está disponible, pero las condiciones técnicas
              y comerciales deben acordarse por adelantado.
            </Body>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – SIP Trunking ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 6.2 · Troncal SIP" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="6.2">Troncal SIP sobre Internet (autenticado por IP)</SectionTitle>
            <Body>
              La infraestructura SIP de GoContact se basa en <strong>FreeSWITCH</strong> con
              un proxy-registrar. Las siguientes restricciones aplican cuando un cliente aporta
              su propio troncal SIP autenticado por IP pública.
            </Body>

            <SubHead>Configuración de gateway</SubHead>
            <Bullets
              tight
              items={[
                "El gateway debe usar una IP pública fija y un puerto SIP específico (por defecto 5060).",
                <>
                  El tráfico SIP <strong>debe originarse exactamente desde ese puerto</strong>, o
                  las llamadas se rechazan con <code>403 Forbidden</code>.
                </>,
                "Gateways entrantes: NO se admiten nombres DNS — solo IP + puerto. DNS permitido solo en outbound.",
              ]}
            />

            <SubHead>Seguridad y autenticación</SubHead>
            <Bullets
              tight
              items={[
                "REGISTER no está permitido para gateways entrantes. La autenticación es solo por IP de origen + puerto.",
                "Mutual TLS (mTLS) no está soportado — desactivadlo en los SBC del cliente.",
              ]}
            />

            <SubHead>Comportamiento esperado</SubHead>
            <Bullets
              tight
              items={[
                "La misma IP no puede usarse para troncal SIP Y registro de extensiones — provoca conflictos de autenticación.",
                "Una única extensión mal configurada (REGISTER fallidos repetidos) puede bloquear temporalmente toda la IP de origen.",
              ]}
            />

            <SubHead>Failover</SubHead>
            <Bullets
              tight
              items={[
                "Se activa automáticamente ante cualquier respuesta SIP no 2xx.",
                "No hay forma de incluir en listas blancas/negras códigos SIP específicos para failover.",
                <>
                  Si el operador devuelve <code>183 Session Progress</code> con early
                  media, FreeSWITCH considera la llamada establecida y el failover deja de
                  estar disponible.
                </>,
              ]}
            />

            <SubHead>Códecs, media y elementos no soportados</SubHead>
            <Bullets
              tight
              items={[
                "Códecs nativos: PCMA (G.711a), PCMU (G.711u), G.722, GSM.",
                "G.729 y Opus no disponibles por defecto — requieren desarrollo y posiblemente licencias.",
                "G.729 disponible solo en datacenters específicos de EE. UU. usando el SBC Perimeta.",
                "DTMF: solo RFC 2833. Sin SRTP, sin STIR/SHAKEN.",
                "Sin llamadas entre dominios cruzados entre IPPBX y GoContact, ni entre dominios cloud de GoContact.",
                "FreeSWITCH no genera tonos de ringback por defecto.",
              ]}
            />
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 – Go / No-Go Checklist ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 7 · Go / No-Go" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="7.">Checklist go / no-go para partners</SectionTitle>
          <Body>
            Esta checklist es la puerta final entre una oportunidad prometedora y un
            despliegue exitoso. Tratad cualquier elemento sin marcar como un riesgo abierto: resolvedlo
            por escrito con el cliente antes de firmar el contrato, no después.
            Los partners que aplican esta disciplina de forma constante logran implementaciones más cortas,
            menos escalados posteriores a la puesta en producción y mejores resultados para el cliente, que es
            exactamente lo que la colaboración con Broadvoice está diseñada para ofrecer.
          </Body>
          <Body>Usar antes de presupuestar al cliente:</Body>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr",
              gap: 6,
              marginTop: 8,
            }}
          >
            {[
              "Número de agentes dimensionado; ancho de banda confirmado a 300 kbps/agente",
              "Tipo de acceso elegido (Internet / MPLS / Dedicado) y coherente con el número de agentes",
              "Latencia al DC de GoContact medida < 100 ms",
              "Cat 5E + switches gestionados L2 instalados, sin Wi-Fi para agentes",
              "VLAN de voz y QoS (DSCP 40/46, cola EF) planificadas",
              "Firewall abierto para el rango IP 185.133.136.0/22 y los puertos de §5.1",
              "Ventana de prueba IPERF programada, puerto 32000 abierto temporalmente",
              "Parque de PC conforme con §5.7",
              "Requisito de retención de grabaciones confirmado (90 días por defecto)",
              "Plan de troncal SIP validado contra §6.2 (IP pública fija, sin REGISTER entrante, sin mTLS, códec soportado)",
              "Exposición por clase de SLA y modelo de penalizaciones comunicados al cliente",
              "PM y contactos técnicos y de red nombrados del lado del cliente",
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: "grid",
                  gridTemplateColumns: "20px 1fr",
                  gap: 10,
                  alignItems: "start",
                  padding: "8px 10px",
                  background: "#FAFAFA",
                  border: "1px solid #E2E2EC",
                  borderRadius: 4,
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 10,
                  color: "#1A1A2E",
                  lineHeight: 1.45,
                }}
              >
                <div
                  style={{
                    width: 14,
                    height: 14,
                    border: "1.5px solid #27698F",
                    borderRadius: 3,
                    marginTop: 1,
                  }}
                />
                <div>{item}</div>
              </div>
            ))}
          </div>



          <div style={{ marginTop: 18 }}>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 13,
                fontWeight: 700,
                color: "#27698F",
                marginBottom: 4,
              }}
            >
              Listo para certificación
            </div>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                color: "#1A1A2E",
                lineHeight: 1.5,
              }}
            >
              Una vez marcadas todas las casillas, la sede está lista para la certificación y el kickoff
              del proyecto.
            </div>
            <div
              style={{
                fontFamily: "'Besley', Georgia, serif",
                fontSize: 11,
                fontStyle: "italic",
                color: "#555",
                marginTop: 4,
              }}
            >
              Más control. Más trazabilidad. Menor tiempo hasta obtener valor para vuestros clientes.
            </div>
          </div>
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default PartnerTechGuideESMadrid;