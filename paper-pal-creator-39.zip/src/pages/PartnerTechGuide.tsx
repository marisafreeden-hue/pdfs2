import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>Partner Technical Guide · v1.0 · June 2026</div>
    <div>© Broadvoice 2026</div>
  </div>
);



const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ num?: string; children: React.ReactNode }> = ({
  children,
}) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}

  </h2>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Bullets: React.FC<{ items: React.ReactNode[]; tight?: boolean }> = ({
  items,
  tight,
}) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: tight ? 1.5 : 1.65,
      paddingLeft: 20,
      margin: "6px 0 10px",
      listStyleType: "disc",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 2 }}>
        {it}
      </li>
    ))}
  </ul>
);

const Callout: React.FC<{ children: React.ReactNode; tone?: "info" | "warn" }> = ({
  children,
  tone = "info",
}) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: tone === "warn" ? "#8a4a00" : "#1A1A2E",
      background: tone === "warn" ? "#FFF6E5" : "#EEF7F8",
      borderLeft: `3px solid ${tone === "warn" ? "#D97706" : "#43B5BF"}`,
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const SimpleTable: React.FC<{
  head: string[];
  rows: (string | React.ReactNode)[][];
  colWidths?: string[];
}> = ({ head, rows, colWidths }) => (
  <table
    style={{
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "'Inter', sans-serif",
      fontSize: 9.5,
      margin: "8px 0 12px",
      tableLayout: "fixed",
    }}
  >
    <colgroup>
      {(colWidths || head.map(() => "auto")).map((w, i) => (
        <col key={i} style={{ width: w }} />
      ))}
    </colgroup>
    <thead>
      <tr style={{ background: "#F3F3F8" }}>
        {head.map((h, i) => (
          <th
            key={i}
            style={{
              padding: "9px 12px",
              textAlign: "left",
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: "0.07em",
              textTransform: "uppercase",
              color: "#555567",
              borderBottom: "2px solid #E2E2EC",
            }}
          >
            {h}
          </th>
        ))}
      </tr>
    </thead>
    <tbody>
      {rows.map((r, ri) => (
        <tr key={ri} style={{ background: ri % 2 === 0 ? "#FFFFFF" : "#FAFAFA" }}>
          {r.map((c, ci) => (
            <td
              key={ci}
              style={{
                padding: "9px 12px",
                color: "#555567",
                borderBottom: "1px solid #E2E2EC",
                lineHeight: 1.45,
                verticalAlign: "top",
                fontWeight: ci === 0 ? 700 : 400,
                ...(ci === 0 ? { color: "#1A1A2E" } : {}),
              }}
            >
              {c}
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  </table>
);

const PartnerTechGuide: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
        .rounded-table table { margin: 0 !important; }
        .rounded-table tbody tr:last-child td { border-bottom: none !important; }
      `}</style>


      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 – Cover & Intro ===== */}
      <div className="page">
        <PageHeader eyebrow="Partner Technical Guide" />

        <div className="partner-hero" style={{ marginTop: 60, marginBottom: 10 }}>
          <h1 className="hero-headline" style={{ fontSize: 36, lineHeight: 1.05, marginBottom: 4, whiteSpace: "nowrap" }}>
            Partner <em>Technical</em> Guide
          </h1>


          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Support, SLAs, delivery and certification requirements for resellers.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />


        <PageBody>
          <div style={{ height: 22 }} />
          <SectionTitle num="1.">Introduction</SectionTitle>

          <Body>
            This guide equips Broadvoice partners with everything needed to qualify,
            scope and deliver a successful GoContact CCaaS deployment. It consolidates
            the support commitments, delivery methodology and technical prerequisites
            that every customer site must satisfy before going live — so partners can
            set clear expectations and protect time-to-value.
          </Body>
          <Body>
            <strong>Audience:</strong> Partner pre-sales, solution architects and project
            managers reselling Broadvoice / GoContact CCaaS.
          </Body>

          <Body>
            <strong>Scope:</strong> Support model, SLAs, project methodology, and the
            technical and infrastructure requirements a customer site must meet before
            go-live.
          </Body>
          <Body>
            As a reseller you are the first line of qualification. Before signing a
            customer, you must be able to:
          </Body>
          <ol
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: "#555567",
              lineHeight: 1.65,
              paddingLeft: 22,
              margin: "6px 0 10px",
              listStyleType: "decimal",
            }}
          >

            <li style={{ marginBottom: 2 }}>
              Set the right expectations on <strong>support and SLAs</strong> (and the
              penalties Broadvoice will honour).
            </li>
            <li style={{ marginBottom: 2 }}>
              Explain the <strong>delivery methodology</strong> and what the customer
              must staff.
            </li>
            <li style={{ marginBottom: 2 }}>
              Collect the <strong>network, IP, telephony and endpoint information</strong>{" "}
              GoContact needs to provision the tenant.
            </li>
          </ol>

          <Callout>
            A site that does not meet the requirements in section 5 will not pass
            certification, regardless of commercial agreement.
          </Callout>

          <hr style={{ margin: "16px 0" }} />

          <SectionTitle num="2.">Support model & SLA framework</SectionTitle>
          <Body>
            GoContact ships with a <strong>four-tier SLA model</strong>, calculated
            annually over the calendar year (Jan 1 – Dec 31). Tier assignment depends on
            (a) which component is affected and (b) whether the impact is total or
            partial.
          </Body>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["Class", "Scope", "Annual Avail.", "Max Restore"]}
              colWidths={["10%", "55%", "17%", "18%"]}
              rows={[
                [
                  "A",
                  "Total unavailability of Core functions or platform access",
                  "99.9%",
                  "4 hours",
                ],
                [
                  "B",
                  "Partial unavailability of Core, OR total loss of operations-support functions",
                  "99.5%",
                  "8 hours",
                ],
                [
                  "C",
                  "Total unavailability of secondary functions (Quality, E-Learning, Calendar)",
                  "98.0%",
                  "5 business days",
                ],
                [
                  "D",
                  "Partial unavailability of operations-support functions",
                  "98.0%",
                  "10 business days",
                ],
              ]}
            />
          </div>

        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – SLA detail ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 2 · SLA Detail" />
        <PageBody>
          <div style={{ height: 30 }} />
          {[
            {
              title: "SLA-A — Core / platform access (total outage)",
              intro: "Triggered when the customer cannot:",
              items: [
                "Access the platform at all",
                "Make or receive calls",
                "Send or receive email",
                "View or manage tickets",
                "Receive or manage webchats",
                "Use the Scripts module",
                "Use any communications channel",
              ],
            },
            {
              title: "SLA-B — Core partial, or operations-support total",
              intro: "Partial / intermittent failures of any SLA-A item, or total loss of:",
              items: [
                "Reporting",
                "Dashboards",
                "User Management",
                "Call recording access",
                "CRM module",
                "Database Management module",
              ],
            },
            {
              title: "SLA-C — Secondary functions (total outage)",
              intro: "Total failure of any of these modules:",
              items: ["Quality", "E-Learning", "Calendar"],
            },
            {
              title: "SLA-D — Operations-support (partial outage)",
              intro: "Partial failures of:",
              items: [
                "Quality",
                "E-Learning",
                "Calendar",
                "Call recordings",
                "CRM",
                "Database Management",
                "Reporting",
                "Dashboards",
                "User Management",
              ],
            },
            {
              title: "Common SLA exclusions",
              intro: "The following downtime is not counted against any SLA:",
              items: [
                "Scheduled corrective or evolutive maintenance windows",
                "Events outside GoContact's reasonable control (internet faults/latency, customer or third-party misconfiguration, customer LAN faults, external integrations, customer-contracted telco services)",
                "Incidents whose remediation requires source-code changes to any component of the GoContact ecosystem",
              ],
            },
          ].map((sec, i) => (
            <div
              key={i}
              style={{
                border: "1px solid #E2E2EC",
                borderRadius: 8,
                padding: "12px 16px 10px",
                marginBottom: 10,
                background: "#FFFFFF",
              }}
            >
              <h2
                className="section-title"
                style={{
                  fontSize: 22,
                  margin: "0 0 6px",
                  lineHeight: 1.2,
                  display: "block",
                }}
              >
                {sec.title}
              </h2>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#555567",
                  margin: "0 0 6px",
                  lineHeight: 1.5,
                }}
              >
                {sec.intro}
              </p>
              <ul
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#555567",
                  lineHeight: 1.55,
                  paddingLeft: 20,
                  margin: 0,
                  listStyleType: "disc",
                  columnCount: 2,
                  columnGap: 28,
                }}
              >
                {sec.items.map((it, j) => (
                  <li key={j} style={{ marginBottom: 2, breakInside: "avoid" }}>
                    {it}
                  </li>
                ))}
              </ul>

            </div>
          ))}
        </PageBody>
        <PageFooter />
      </div>


      {/* ===== PAGE 3 – Availability, Penalties, Methodology ===== */}
      <div className="page">
        <PageHeader eyebrow="Sections 2.6 – 2.7 · Availability & Penalties" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="2.6">Service availability commitment</SectionTitle>
          <Body>
            The service is provided 24×7. Planned maintenance is performed in off-peak
            windows with prior notice; if it must occur in productive hours, the
            customer must approve it and a business-continuity plan is agreed — those
            windows are then also excluded from SLA calculation. SLA is measured{" "}
            <strong>globally</strong> across all sites where the platform runs. If
            monthly availability falls below the limit, the customer may request a
            credit <strong>within 30 days of month end</strong>.
          </Body>

          <div style={{ height: 28 }} />

          <SectionTitle num="2.7">Penalties (credit on monthly service fee)</SectionTitle>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["SLA", "Monthly SLA", "> 0% – ≤ 0.5%", "> 0.5% – ≤ 1%", "> 1%"]}
              colWidths={["12%", "22%", "22%", "22%", "22%"]}
              rows={[
                ["A", "99.90%", "2%", "5%", "10%"],
                ["B", "99.50%", "—", "2%", "5%"],
                ["C & D", "98.00%", "—", "—", "—"],
              ]}
            />
          </div>
          <Callout>
            Partners should price service credits into commercial models, especially for
            customers with heavy Core dependence (SLA-A exposure).
          </Callout>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – Delivery methodology & Pre-sales checklist ===== */}
      <div className="page">
        <PageHeader eyebrow="Sections 3 – 4 · Delivery & Discovery" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="3.">Delivery methodology</SectionTitle>
          <Body>
            Every GoContact CCaaS deployment runs through the same phased framework so
            partners and customers share a single playbook from contract signature to
            steady state. Section 3 outlines the four phases; section 4 lists the
            information you must collect from the customer before kickoff.
          </Body>
          <Body>GoContact CCaaS implementations are run as phased projects:</Body>
          <Bullets
            items={[
              <>
                <strong>Planning</strong> — discovery, requirements, design.
              </>,
              <>
                <strong>Execution / Implementation</strong> — provisioning,
                configuration, integration, testing.
              </>,
              <>
                <strong>Closure</strong> — handover, sign-off, transfer to the Customer
                Success Manager (CSM).
              </>,
              <>
                <strong>Nurturing</strong> — post go-live accompaniment by the CSM.
              </>,
            ]}
          />
          <Body>
            The methodology is based on <strong>PRINCE2®</strong>, aligned with PMI /
            PMBOK® best practices. Partners are expected to provide a counterpart PM,
            technical owner and a network contact during execution.
          </Body>

          <hr style={{ margin: "16px 0" }} />

          <SectionTitle num="4.">Pre-Sales Discovery</SectionTitle>
          <Body>
            Use these questions to qualify the opportunity and scope the deployment
            before quoting. Answers feed directly into sizing, network design, telephony
            integration and the project plan — gaps here are the most common cause of
            delayed go-lives. Work through each category with the customer's technical
            and business stakeholders.
          </Body>

          <SubHead>Sizing & Operations</SubHead>
          <Bullets
            items={[
              "How many concurrent agents will the platform need to support, and what is the expected 12-month growth?",
              "What is the agent shift pattern (24×7, business hours, peak windows) and busy-hour call volume?",
              "How many sites are in scope, where are they located, and are any remote/home agents expected?",
            ]}
          />

          <SubHead>Network & Connectivity</SubHead>
          <Bullets
            items={[
              "What is the existing WAN / Internet topology (dedicated internet, MPLS, hybrid) and what redundancy is in place?",
              "What LAN equipment is in place (switch models, manageability, PoE) and who owns it?",
              "Are any agents working over Wi-Fi today, and can that be eliminated before go-live?",
            ]}
          />

          <SubHead>Telephony & Numbering</SubHead>
          <Bullets
            items={[
              "Which public IPs will be used for the SIP trunk, and is a backup IP available for failover?",
              "Which carrier(s) will provide SIP services, which side originates calls, and is number porting required?",
              "What is the inbound number plan (DIDs, IVR menus, business hours, holiday schedules)?",
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – Pre-Sales Discovery (cont.) ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 4 · Pre-Sales Discovery (cont.)" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="4.">Pre-Sales Discovery (continued)</SectionTitle>

          <SubHead>Channels & Outbound</SubHead>
          <Bullets
            items={[
              "What outbound dialing modes are needed (preview, progressive, predictive) and what compliance rules apply (TCPA, DNC, opt-out)?",
              "Which channels are in scope beyond voice (email, webchat, WhatsApp, SMS, social) and at what volume?",
            ]}
          />

          <SubHead>Compliance & Recording</SubHead>
          <Bullets
            items={[
              "What call-recording retention period is required (default 90 days) and are any regulatory rules in play (PCI, HIPAA, GDPR)?",
            ]}
          />

          <SubHead>Endpoints & Integrations</SubHead>
          <Bullets
            items={[
              "What is the agent endpoint inventory (PC spec, headsets, OS, browser) and the desktop refresh cycle?",
              "Which integrations are required (CRM, ticketing, WFM, BI, external APIs) and who owns each system?",
            ]}
          />

          <SubHead>Reporting & Stakeholders</SubHead>
          <Bullets
            items={[
              "Who are the executive sponsor, technical owner, network contact and end-user champion on the customer side?",
            ]}
          />

          <SubHead>Timeline & Success Criteria</SubHead>
          <Bullets
            items={[
              "What is the target go-live date, and are there blackout periods (peak season, audits, system freezes)?",
              "What does success look like 30, 60 and 90 days post go-live?",
            ]}
          />

          <Callout>
            <strong>Close the loop:</strong> Before quoting, get sign-off on agent count,
            channels, integrations and go-live date — in writing. Every assumption you
            leave open becomes a change request, a delay, or a margin hit during delivery.
          </Callout>
        </PageBody>
        <PageFooter />
      </div>



      {/* ===== PAGE 4 – Technical requirements (IP, LAN, Access) ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 5 · Technical Requirements" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="5.1">IP addressing and ports</SectionTitle>
          <Body>
            <strong>GoContact platform IP range (PT / ES):</strong>{" "}
            <code style={{ background: "#F3F3F8", padding: "1px 6px", borderRadius: 3 }}>
              185.133.136.0/22
            </code>
          </Body>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["Purpose", "Protocol", "Ports"]}
              colWidths={["40%", "20%", "40%"]}
              rows={[
                ["SIP signalling", "UDP", "5060, 5062, 5090"],
                ["SIP signalling (TLS)", "TCP", "5061"],
                ["RTP audio (low)", "UDP", "16384–32767"],
                ["RTP audio (high)", "UDP", "49152–65535"],
                ["Local IPBX mgmt (on-prem only)", "UDP", "10000–10050"],
                ["GoContact platform mgmt", "TCP", "50000–50010"],
              ]}
            />
          </div>
          <Callout>
            All ports must be permitted bidirectionally through the customer firewall
            against the IP range above.
          </Callout>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 10,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.2">LAN requirements</SectionTitle>
            <Body>
              VoIP is highly sensitive to LAN stability. The platform{" "}
              <strong>does not support Wi-Fi</strong> for agents.
            </Body>
            <Bullets
              tight
              items={[
                "Structured cabling, Cat 5E or better.",
                "Layer-2 managed switches with: LACP, 802.1Q, STP, PoE.",
                "Switch ports 10/100/1000 Base-T.",
                "Forwarding: 24-port > 40 Mbps · 48-port > 70 Mbps.",
                "Reference: Huawei S5700 LI, S5710 LI (or equivalent).",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 10,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.3">IP access to the platform</SectionTitle>
            <Body>
              All traffic with the GoContact platform — HTTP/HTTPS, SIP, RTP, management
              ports — must be treated as <strong>real-time</strong>.
            </Body>
            <SubHead>Bandwidth per agent (rule of thumb)</SubHead>
            <Bullets
              tight
              items={[
                "~100 kbps voice",
                "~200 kbps other channels / features",
                "≈ 300 kbps total per concurrent agent",
              ]}
            />
            <Body>
              Access can be provided via dedicated Internet, MPLS VPN, or dedicated
              circuit. CPE router must be equivalent to or better than a{" "}
              <strong>Cisco 1921/K9</strong>.
            </Body>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Access types, QoS, Workstation ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 5 · Access & Quality" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.4">Dedicated Internet access</SectionTitle>
            <Bullets
              tight
              items={[
                "Does NOT guarantee QoS between site and datacenter.",
                "Works in practice up to ~50 agents on standard business internet.",
                "Recommended: a dedicated circuit separate from the customer's general internet.",
                "Reference profile in production: 100 Mbps symmetric, static IP.",
                "Latency to GoContact datacenter must be < 100 ms.",
                "All traffic crosses the public Internet — review customer security needs.",
                "> 50 and up to 200 agents: dedicated GoContact circuit OR MPLS / L2 is mandatory.",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.5">MPLS / VPN access</SectionTitle>
            <Bullets
              tight
              items={[
                "Recommended for any operation — satisfies QoS and security.",
                "Established between GoContact datacenter and the customer site.",
                "Must be sized for the per-agent bandwidth.",
                "GoContact datacenter can terminate redundant MPLS VPNs.",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.6">Voice quality (QoS) configuration</SectionTitle>
            <Bullets
              tight
              items={[
                "Dedicated VLAN for voice at each site, separated from data.",
                "Prioritise outbound voice (uplink) at the router with guaranteed bandwidth per channel.",
                <>
                  Codec: <strong>G.711a</strong>, ~95 kbps per channel.
                </>,
                "SIP phones mark signalling DSCP=40, audio DSCP=46.",
                "Apply QoS via VLAN segmentation, DSCP (40/46), or IP Precedence 5.",
                "Priority queue for audio packets: Expedited Forwarding (EF).",
              ]}
            />
          </div>

          <div style={{ marginBottom: 12 }}>
            <SectionTitle num="5.7">Agent workstation (PC)</SectionTitle>
            <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 4px" }}>
              <SimpleTable
                head={["Component", "Minimum"]}
                colWidths={["30%", "70%"]}
                rows={[
                  ["CPU", "Intel Core i3 / i5"],
                  ["Disk", "60 GB"],
                  ["RAM", "4 GB"],
                  ["OS", "Windows 7 or later"],
                  ["Browser", "Google Chrome (latest)"],
                  ["Softphone", "X-Lite, MicroSIP or Zoiper"],
                  ["Peripherals", "USB headset, monitor, keyboard, mouse"],
                ]}
              />
            </div>
          </div>

        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 – IPERF + Recording & SIP Trunking ===== */}
      <div className="page">
        <PageHeader eyebrow="Sections 5.8 – 6 · Testing, Recording & SIP" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.8">IPERF connectivity tests</SectionTitle>
            <Body>
              Before go-live, connectivity is validated with <strong>IPERF</strong>. The
              customer must temporarily <strong>open TCP/UDP 32000</strong> during the
              tests; it can be closed afterwards.
            </Body>
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="6.1">Call recording & retention</SectionTitle>
            <Body>
              Broadvoice (GoTelecom — "A Broadvoice Company") includes{" "}
              <strong>recording and retention up to 90 days at no extra cost</strong> as
              part of the CCaaS service. The partner must verify whether the customer's
              vertical or jurisdiction requires longer retention (e.g. CNPD Deliberation
              Nº 1039/2017 in Portugal). Extended retention is available, but technical
              and commercial conditions must be agreed up front.
            </Body>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – SIP Trunking ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 6.2 · SIP Trunking" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="6.2">SIP Trunk over Internet (IP-authenticated)</SectionTitle>
            <Body>
              GoContact's SIP infrastructure is based on <strong>FreeSWITCH</strong> with
              a proxy-registrar. The following constraints apply when a customer brings
              its own SIP trunk authenticated by public IP.
            </Body>

            <SubHead>Gateway configuration</SubHead>
            <Bullets
              tight
              items={[
                "Gateway must use a fixed public IP and a specific SIP port (default 5060).",
                <>
                  SIP traffic <strong>must originate from exactly that port</strong>, or
                  calls are rejected with <code>403 Forbidden</code>.
                </>,
                "Inbound gateways: DNS names are NOT supported — IP + port only. DNS allowed only on outbound.",
              ]}
            />

            <SubHead>Security & authentication</SubHead>
            <Bullets
              tight
              items={[
                "REGISTER is not allowed for inbound gateways. Auth is by source IP + port only.",
                "Mutual TLS (mTLS) is not supported — disable on customer SBCs.",
              ]}
            />

            <SubHead>Expected behaviour</SubHead>
            <Bullets
              tight
              items={[
                "Same IP cannot be used for SIP Trunk AND extension registration — causes auth conflicts.",
                "A single misconfigured extension (repeated failed REGISTERs) can temporarily block the whole source IP.",
              ]}
            />

            <SubHead>Failover</SubHead>
            <Bullets
              tight
              items={[
                "Triggered automatically on any non-2xx SIP response.",
                "No way to whitelist/blacklist specific SIP codes for failover.",
                <>
                  If the carrier returns <code>183 Session Progress</code> with early
                  media, FreeSWITCH considers the call established and failover is no
                  longer available.
                </>,
              ]}
            />

            <SubHead>Codecs, media & not supported</SubHead>
            <Bullets
              tight
              items={[
                "Native codecs: PCMA (G.711a), PCMU (G.711u), G.722, GSM.",
                "G.729 and Opus not available by default — require dev and possibly licensing.",
                "G.729 available only in specific US datacenters using the Perimeta SBC.",
                "DTMF: RFC 2833 only. No SRTP, no STIR/SHAKEN.",
                "No cross-domain calls between IPPBX and GoContact, or between GoContact cloud domains.",
                "FreeSWITCH does not generate ringback tones by default.",
              ]}
            />
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 – Go / No-Go Checklist ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 7 · Go / No-Go" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="7.">Partner go / no-go checklist</SectionTitle>
          <Body>
            This checklist is the final gate between a promising opportunity and a
            successful deployment. Treat any unchecked item as an open risk: resolve it
            in writing with the customer before the contract is signed, not after.
            Partners who run this discipline consistently see shorter implementations,
            fewer post-go-live escalations and stronger customer outcomes — which is
            exactly what the Broadvoice partnership is built to deliver.
          </Body>
          <Body>Use before quoting the customer:</Body>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr",
              gap: 6,
              marginTop: 8,
            }}
          >
            {[
              "Agent count sized; bandwidth at 300 kbps/agent confirmed",
              "Access type chosen (Internet / MPLS / Dedicated) and consistent with agent count",
              "Latency to GoContact DC measured < 100 ms",
              "Cat 5E + L2 managed switches in place, no Wi-Fi for agents",
              "Voice VLAN and QoS (DSCP 40/46, EF queue) planned",
              "Firewall opened for IP range 185.133.136.0/22 and the ports in §5.1",
              "IPERF test slot scheduled, port 32000 temporarily open",
              "PC fleet meets §5.7",
              "Recording retention requirement confirmed (default 90 days)",
              "SIP trunk plan validated against §6.2 (fixed public IP, no REGISTER inbound, no mTLS, supported codec)",
              "SLA class exposure and penalty model communicated to the customer",
              "PM, technical and network contacts named on the customer side",
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: "grid",
                  gridTemplateColumns: "20px 1fr",
                  gap: 10,
                  alignItems: "start",
                  padding: "8px 10px",
                  background: "#FAFAFA",
                  border: "1px solid #E2E2EC",
                  borderRadius: 4,
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 10,
                  color: "#1A1A2E",
                  lineHeight: 1.45,
                }}
              >
                <div
                  style={{
                    width: 14,
                    height: 14,
                    border: "1.5px solid #27698F",
                    borderRadius: 3,
                    marginTop: 1,
                  }}
                />
                <div>{item}</div>
              </div>
            ))}
          </div>



          <div style={{ marginTop: 18 }}>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 13,
                fontWeight: 700,
                color: "#27698F",
                marginBottom: 4,
              }}
            >
              Ready for certification
            </div>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                color: "#1A1A2E",
                lineHeight: 1.5,
              }}
            >
              Once every box is ticked, the site is ready for certification and project
              kickoff.
            </div>
            <div
              style={{
                fontFamily: "'Besley', Georgia, serif",
                fontSize: 11,
                fontStyle: "italic",
                color: "#555",
                marginTop: 4,
              }}
            >
              More control. More traceability. Faster time-to-value for your customers.
            </div>
          </div>
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default PartnerTechGuide;
