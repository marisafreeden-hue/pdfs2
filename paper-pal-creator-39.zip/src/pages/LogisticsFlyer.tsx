import React from "react";
import VerticalFlyer, { buildSolutions } from "./VerticalFlyer";
import hero from "@/assets/hero-logistics.jpg.asset.json";

const LogisticsFlyer: React.FC = () => (
  <VerticalFlyer
    eyebrow="Broadvoice for Logistics"
    headlineLine1="Keep Every Shipment"
    headlineAccent="Conversation Moving"
    heroImage={hero.url}
    pullQuote="Give customers, partners, and operations teams clearer updates when timing matters."
    intro="Broadvoice helps logistics leaders improve customer visibility and reduce communications complexity — connecting offices, warehouses, dispatch, drivers, partners, and support teams with cloud contact center, text messaging, agentic AI, and deep analytics."
    stats={[
      { num: "99.999%", label: <><strong>Platform uptime SLA</strong>keeping dispatch, customer service, and partner lines online through peak and exception events.</> as any },
      { num: "80%", label: <><strong>Self-service success rate</strong>when routine status, ETA, and pickup inquiries are routed to agentic AI.</> as any },
      { num: "$11", label: <><strong>Saved per call</strong>using AI vs. a live agent for tracking, delivery windows, and service updates.</> as any },
    ]}
    sectionTitle="Built for the"
    sectionTitleEm="pace of modern logistics operations"
    sectionBody="Logistics teams coordinate across customers, dispatch, warehouses, drivers, and partners — under constant pressure to resolve exceptions quickly, keep customers informed, and absorb volume spikes without breaking SLAs."
    challenges={[
      { n: "01", title: "Status-check call volume", body: "“Where's my shipment?” calls consume agent capacity that should go to exceptions and revenue-generating service." },
      { n: "02", title: "Dispatch & warehouse coordination", body: "Office, dock, dispatch, and driver communications fragmented across radios, mobile phones, and aging PBX." },
      { n: "03", title: "Exception & delay handling", body: "Weather, customs, and capacity events generate sudden spikes that overwhelm fixed-capacity contact centers." },
      { n: "04", title: "Partner & broker support", body: "Carriers, brokers, and 3PL partners need fast, structured contact with operations — not voicemail tag." },
      { n: "05", title: "Mobile & distributed teams", body: "Drivers, account managers, and yard staff need a business line and SMS that work from any device." },
      { n: "06", title: "Operational visibility", body: "Leaders need workload, queue, and service-trend insight in real time — across every site and team." },
    ]}
    page2Title="A unified platform for"
    page2TitleEm="every shipment conversation"
    page2Body="Four integrated solutions — phone system, contact center, agentic AI, and analytics — built for the pace, surges, and distributed teams of modern logistics."
    solutions={buildSolutions(
      {
        ucaas: "Connect offices, warehouses, dispatch, support, and mobile teams across every device and location.",
        ccaas: "Customer-facing contact center with smart routing, screen pop, and exception-ready capacity.",
        ai: "Agentic AI that resolves routine status, ETA, pickup, and service inquiries 24/7 — at a fraction of agent cost.",
        insights: "Real-time visibility into queue activity, workload patterns, and service-trend analytics.",
      },
      {
        ucaas: [["Multi-site routing", "office, dock, dispatch & mobile"], ["Recording", "for service and partner calls"], ["Bubble texting", "delivery, pickup, and delay notifications"]],
        ccaas: [["Shipment routing", "by account, lane, or service tier"], ["TMS screen pop", "shipment context before answer"], ["Supervisor view", "live queue & coaching tools"]],
        ai: [["24/7 status & ETA", "secure self-service tracking"], ["Pickup & appointment intake", "structured handoff to ops"], ["Warm escalation", "exceptions go straight to a human"]],
        insights: [["Workload heatmaps", "by lane, account & site"], ["Service trends", "topic, resolution & SLA risk"], ["Plain-language reports", "no analyst required"]],
      }
    )}
    cta="Connect with Broadvoice to improve customer visibility, reduce operational friction, and modernize logistics communications."
    flexibleSolutionsLabel="Flexible Solutions for Logistics Organizations"
    sectionOffset={10}
  />
);

export default LogisticsFlyer;
