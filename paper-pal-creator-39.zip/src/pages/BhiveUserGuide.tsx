import React from "react";
import "./GoEngageDatasheet.css";

const ScreenshotPlaceholder = ({ label }: { label: string }) => (
  <div
    style={{
      width: "100%",
      height: 220,
      background: "#F3F3F8",
      border: "2px dashed #C8C8D8",
      borderRadius: 8,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "14px 0",
      color: "#888899",
      fontSize: 12,
      fontWeight: 600,
      fontFamily: "'Inter', sans-serif",
    }}
  >
    📷 Screenshot: {label}
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const GuideSection = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => (
  <div className="faq-section">
    <div className="faq-section-header">
      <h3 className="faq-section-title">{title}</h3>
    </div>
    {children}
  </div>
);

const StepList = ({ steps }: { steps: string[] }) => (
  <ol
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#555567",
      lineHeight: 1.7,
      paddingLeft: 18,
      margin: "4px 0 8px",
    }}
  >
    {steps.map((s, i) => (
      <li key={i}>{s}</li>
    ))}
  </ol>
);

const BulletList = ({ items }: { items: string[] }) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#555567",
      lineHeight: 1.7,
      paddingLeft: 18,
      margin: "4px 0 8px",
    }}
  >
    {items.map((s, i) => (
      <li key={i}>{s}</li>
    ))}
  </ul>
);

const BodyText = ({ children }: { children: React.ReactNode }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#555567",
      lineHeight: 1.7,
      margin: "4px 0 8px",
    }}
  >
    {children}
  </p>
);

const SubHead = ({ children }: { children: React.ReactNode }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 11,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "10px 0 2px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </p>
);

const Tip = ({ children }: { children: React.ReactNode }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 9.5,
      color: "#43B5BF",
      fontWeight: 600,
      margin: "6px 0",
    }}
  >
    👉 {children}
  </p>
);

const TocRow = ({ label, page }: { label: string; page: string }) => (
  <div
    style={{
      display: "flex",
      alignItems: "baseline",
      gap: 6,
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#555567",
      lineHeight: 2,
    }}
  >
    <span style={{ whiteSpace: "nowrap" }}>{label}</span>
    <span
      style={{
        flex: 1,
        borderBottom: "1px dotted #C8C8D8",
        transform: "translateY(-3px)",
      }}
    />
    <span style={{ color: "#27698F", fontWeight: 700 }}>{page}</span>
  </div>
);

const TocGroup = ({
  title,
  items,
}: {
  title: string;
  items: [string, string][];
}) => (
  <div style={{ marginBottom: 12 }}>
    <p
      style={{
        fontFamily: "'Instrument Sans', 'Inter', sans-serif",
        fontSize: 12,
        fontWeight: 700,
        color: "#27698F",
        margin: "0 0 4px",
      }}
    >
      {title}
    </p>
    {items.map(([label, page]) => (
      <TocRow key={label} label={label} page={page} />
    ))}
  </div>
);


const Warning = ({ children }: { children: React.ReactNode }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 9.5,
      color: "#D97706",
      fontWeight: 600,
      margin: "6px 0",
    }}
  >
    ⚠️ {children}
  </p>
);

const BhiveUserGuide: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 – Intro & Login ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="partner-hero">
          <h1 className="hero-headline">
            b-<em>hive</em>
          </h1>
          <div className="faq-title-sub">User Guide</div>
        </div>

        <hr />

        <GuideSection title="Introduction">
          <BodyText>
            Welcome to the b-hive Portal User Guide! This guide has been designed to provide you with all the necessary information to fully understand and utilize the features and capabilities of your portal.
          </BodyText>
          <BodyText>
            Whether you are a new or experienced user, this guide is here to help you get the most out of your phone portal. We cover everything from essential functions like making calls and sending faxes to more advanced features like blocking unwanted numbers and setting out-of-office messages.
          </BodyText>
        </GuideSection>

        <hr style={{ margin: "14px 0" }} />

        <GuideSection title="Tabla de Contenidos">
          <div style={{ marginTop: 8 }}>
            <TocGroup
              title="b-hive"
              items={[
                ["Iniciar y Cerrar Sesión", "4"],
                ["Navegación del Menú", "6"],
                ["Mis Llamadas", "12"],
                ["Configuración Personal", "17"],
                ["Configuración Personal: Buzón de Voz", "19"],
                ["Configuración Personal: Captura de Llamadas", "19"],
                ["Administrador de Sonidos", "22"],
                ["Estrategia de Timbrado Personal", "27"],
              ]}
            />
            <TocGroup
              title="Communicator"
              items={[
                ["Navegación", "21"],
                ["Configuración", "22"],
                ["Estado y Disponibilidad", "23"],
                ["Mensajes", "23"],
                ["Llamadas", "25"],
                ["Video", "26"],
                ["Buzón de Voz", "30"],
                ["Fax", "31"],
                ["Directorio", "32"],
                ["Contactos", "32"],
              ]}
            />
          </div>
        </GuideSection>

        <PageFooter />
      </div>

      {/* ===== PAGE 1b – Logging In & Out ===== */}
      <div className="page">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <GuideSection title="Logging In & Out">
          <SubHead>To log in:</SubHead>
          <StepList
            steps={[
              "Navigate to portal.broadvoice.com from your browser.",
              "Enter your Username or email address.",
              "If single sign-on (SSO) is enabled, select your platform.",
              "Click Continue.",
              "If not using SSO, enter your password.",
              "If forgotten, click Forgot Password to reset.",
            ]}
          />
          <ScreenshotPlaceholder label="Login Screen" />
          <SubHead>To log out:</SubHead>
          <BodyText>Click your avatar (top right) → Sign Out</BodyText>
        </GuideSection>

        <PageFooter />
      </div>


      {/* ===== PAGE 2 – Personal Settings ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <GuideSection title="Personal Settings">
          <SubHead>Access:</SubHead>
          <BodyText>Click avatar (top right) → Personal Settings</BodyText>
          <SubHead>You can:</SubHead>
          <BulletList
            items={[
              "Update name and email",
              "Add mobile number (for call forwarding)",
              "View extension",
              "Override time zone",
              "Update job title & department",
              "Update login email (admin must reissue access if changed)",
            ]}
          />
          <ScreenshotPlaceholder label="Personal Settings Panel" />
          <SubHead>Phone Settings:</SubHead>
          <BulletList
            items={[
              "Welcome Message – plays before calls connect",
              "Forwarding Whisper – announces forwarded calls",
              "Hot Desking – log into another phone using extension + PIN",
              "Intercom Settings – enable/disable intercom",
            ]}
          />
          <Tip>Click Save after changes</Tip>
          <SubHead>Confirm Calls:</SubHead>
          <BodyText>
            Press 1 to accept / 2 to decline. Recommended when using forwarding + whisper.
          </BodyText>
        </GuideSection>

        <PageFooter />
      </div>

      {/* ===== PAGE 3 – Presence & Voicemail ===== */}
      <div className="page page-3">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <GuideSection title="Presence Settings">
          <SubHead>Access:</SubHead>
          <BodyText>Avatar → Presence Settings</BodyText>
          <SubHead>Status Options:</SubHead>
          <BulletList items={["Busy", "Available", "Away"]} />
          <SubHead>Call Behavior Options:</SubHead>
          <BulletList
            items={[
              "Ring My Desk",
              "Ring My Mobile",
              "Forward Calls",
              "Voicemail",
            ]}
          />
          <BodyText>
            Toggle features ON/OFF. Adjust timing with slider. Example: ring devices for 30 seconds → then voicemail.
          </BodyText>
          <Tip>Click Save to apply</Tip>
          <ScreenshotPlaceholder label="Presence Settings" />
        </GuideSection>

        <hr style={{ margin: "14px 0" }} />

        <GuideSection title="Voicemail Setup">
          <SubHead>Access:</SubHead>
          <BodyText>Personal Settings → Voicemail Settings</BodyText>
          <SubHead>Options:</SubHead>
          <BulletList
            items={[
              "Set 4-digit PIN",
              "Always require PIN",
              "Empty voicemail notifications (email alerts)",
              "Greeting & temporary greeting (via Sound Manager)",
            ]}
          />
          <Tip>Click Save</Tip>
        </GuideSection>

        <PageFooter />
      </div>

      {/* ===== PAGE 4 – Sound Manager & Manage Voicemails ===== */}
      <div className="page page-4">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <GuideSection title="Sound Manager">
          <BodyText>Accessed via cloud icon.</BodyText>
          <SubHead>Options:</SubHead>
          <BulletList
            items={[
              "Existing greeting",
              "Upload recording",
              "Text-to-speech",
              "Record by phone",
            ]}
          />
          <SubHead>You can:</SubHead>
          <BulletList items={["Play", "Replace", "Remove greetings"]} />
          <ScreenshotPlaceholder label="Sound Manager" />
          <SubHead>Temporary Greeting:</SubHead>
          <BodyText>
            Overrides main greeting when away. Remove when no longer needed.
          </BodyText>
        </GuideSection>

        <hr style={{ margin: "14px 0" }} />

        <GuideSection title="Manage Voicemails">
          <SubHead>Access:</SubHead>
          <BodyText>Click Voicemail tab</BodyText>
          <SubHead>You can view:</SubHead>
          <BulletList
            items={[
              "Date/time",
              "Caller info",
              "Status (read/unread)",
              "Duration",
              "Playback",
            ]}
          />
          <SubHead>Actions:</SubHead>
          <BulletList items={["Forward", "Download (.mp3)", "Delete"]} />
        </GuideSection>

        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Voicemails (cont'd) & Faxing ===== */}
      <div className="page page-5">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <GuideSection title="Manage Voicemails (continued)">
          <SubHead>Additional:</SubHead>
          <BulletList
            items={[
              "Playback controls (volume, speed)",
              "Transcription (if enabled)",
            ]}
          />
          <SubHead>Bulk Delete:</SubHead>
          <BodyText>Select messages → Delete Selected</BodyText>
          <BodyText>
            <strong>Note:</strong> Emails marked "unread" until listened to in portal/app/phone.
          </BodyText>
          <ScreenshotPlaceholder label="Voicemail List" />
        </GuideSection>

        <hr style={{ margin: "14px 0" }} />

        <GuideSection title="Faxing">
          <SubHead>Access:</SubHead>
          <BodyText>Click Faxes</BodyText>
          <SubHead>Features:</SubHead>
          <BulletList
            items={[
              "Send new fax",
              "Sort (delivered, processing, failed)",
              "Search",
              "View details (date, sender, recipient, size)",
            ]}
          />
          <SubHead>Send Fax:</SubHead>
          <StepList
            steps={[
              "Select sender",
              "Enter recipient(s)",
              "Upload file",
              "Optional cover sheet",
              "Click Send Fax",
            ]}
          />
          <SubHead>Status:</SubHead>
          <BodyText>Processing → Delivered → Failed</BodyText>
          <ScreenshotPlaceholder label="Fax Interface" />
        </GuideSection>

        <PageFooter />
      </div>

      {/* ===== PAGE 6 – E-Faxing ===== */}
      <div className="page page-6">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <GuideSection title="E-Faxing (Email to Fax)">
          <SubHead>Steps:</SubHead>
          <StepList
            steps={[
              "Open new email",
              'In To: faxnumber@fax.voipment.com (Example: 7145551212@fax.voipment.com)',
              "Subject: your fax number (Example: 9493257000)",
              "Attach file",
              "Click Send",
            ]}
          />
          <Warning>Email body text will NOT transmit</Warning>
          <ScreenshotPlaceholder label="E-Fax Email Example" />
        </GuideSection>

        <PageFooter />
      </div>
    </div>
  );
};

export default BhiveUserGuide;
