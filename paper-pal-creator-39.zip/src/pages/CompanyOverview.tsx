import React from "react";
import { Heart, Shield, Truck, DollarSign, Home, Handshake, BarChart3, ArrowRight, Coins, Package, TrendingUp, ClipboardList, BarChart2, Award, BookOpen, HeadphonesIcon, Rocket } from "lucide-react";
import "./GoEngageDatasheet.css";

const CompanyOverview: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      <div className="page page-1" style={{ position: "relative", overflow: "hidden" }}>
        {/* Header */}
        <div className="logo" style={{ marginBottom: 12 }}>
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div style={{ marginBottom: 12 }}>
          <h1 className="hero-headline" style={{ fontSize: 42, marginBottom: 2 }}>
            Built for <em>conversations.</em><br />Not complexity.
          </h1>
          <p className="hero-desc" style={{ maxWidth: 520, fontSize: 13, lineHeight: 1.6 }}>
            UCaaS, CCaaS, and AI — intelligent solutions, priced for the midmarket, and delivered with partner-first support that removes friction from every deal.
          </p>
        </div>

        {/* Stat bar */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          background: "#F8FAFB",
          padding: "18px 0.625in",
          marginBottom: 16,
          marginLeft: "-0.625in",
          marginRight: "-0.625in",
          borderTop: "1px solid #E2E2EC",
          borderBottom: "1px solid #E2E2EC",
        }}>
          {[
            { num: "~97%", label: "Accuracy in call routing" },
            { num: "~40%", label: "Reduction in IVR navigation time" },
            { num: "+10pts", label: "Average NPS increase" },
            { num: "8X", label: "SPIFF potential" },
          ].map((s, i) => (
            <div key={i} style={{ paddingRight: 16, borderRight: i < 3 ? "1px solid #E2E2EC" : "none", paddingLeft: i > 0 ? 16 : 0, textAlign: "center" }}>
              <div style={{
                fontFamily: "'Instrument Sans', -apple-system, sans-serif",
                fontStyle: "normal",
                fontSize: 28,
                fontWeight: 500,
                marginBottom: 4,
                lineHeight: 1.1,
                background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}>{s.num}</div>
              <div style={{ fontSize: 9, color: "#555567", lineHeight: 1.4, fontFamily: "'Inter', sans-serif" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Two-column: Opportunity + Verticals */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 16, marginTop: 20 }}>
          {/* Left: The Opportunity */}
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>The Opportunity</div>
            <h2 className="hero-headline" style={{ fontSize: 26, marginBottom: 8, lineHeight: 1.15 }}>
              The market shifted.<br /><em>We built for it.</em>
            </h2>
            <p style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.85, marginBottom: 8, fontFamily: "'Inter', sans-serif" }}>
              Midmarket companies are under pressure to modernize while controlling costs — to improve CX without adding complexity, and to adopt AI without hiring new teams.
            </p>
            <p style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.85, marginBottom: 8, fontFamily: "'Inter', sans-serif" }}>
              They remain underserved. Overpaying for platforms they can't fully use. Sold features they can't operationalize. Left without the support to execute.
            </p>
            <p style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.85, marginBottom: 10, fontFamily: "'Inter', sans-serif" }}>
              Broadvoice helps everyday businesses deliver better customer experiences with intelligent CX solutions that are easy to use, fast to deploy, and deliver value from day one.
            </p>
            <div style={{ borderTop: "1px solid #E2E2EC", paddingTop: 25 }}>
              <p style={{ fontSize: 12, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.4 }}>
                Easy to implement. Simple to use. Easy to sell.
              </p>
            </div>
          </div>

          {/* Right: Target Verticals */}
          <div style={{ border: "1px solid #D0E8EA", borderRadius: 10, padding: "14px 16px", background: "rgba(67, 181, 191, 0.04)" }}>
            <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}>Target Verticals</div>
            <svg width="0" height="0" style={{ position: "absolute" }}>
              <defs>
                <linearGradient id="vert-icon-grad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#43B5BF" />
                  <stop offset="100%" stopColor="#27698F" />
                </linearGradient>
              </defs>
            </svg>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
              {[
                { Icon: Heart, title: "Healthcare", desc: "Patient CX & scheduling" },
                { Icon: Shield, title: "Insurance", desc: "Claims & renewals" },
                { Icon: Truck, title: "Logistics", desc: "Ops-critical comms" },
                { Icon: DollarSign, title: "Finance", desc: "Compliance-ready" },
                { Icon: Home, title: "Real Estate", desc: "High-volume inbound & outbound" },
              ].map((v, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: "#FFFFFF", borderRadius: 8, border: "1px solid #E2E2EC" }}>
                  <v.Icon size={18} style={{ stroke: "url(#vert-icon-grad)", flexShrink: 0 }} />
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>{v.title}</div>
                    <div style={{ fontSize: 9, color: "#888899", fontFamily: "'Inter', sans-serif" }}>{v.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            {/* Callout */}
            <div style={{ border: "1px solid #43B5BF", padding: "10px 14px", background: "rgba(67, 181, 191, 0.04)", borderRadius: 8 }}>
              <p style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                Industries where <strong style={{ color: "#1A1A2E" }}>CX matters, margins matter, and value — not excess — wins.</strong> Customers who stay, grow, and refer.
              </p>
            </div>
          </div>
        </div>

        

        {/* Platform Overview */}
        <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10, marginTop: 8 }}>Platform Overview</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
          {[
            {
              title: "Contact Center", sub: "GoContact · CCaaS",
              items: [{ name: "Omnichannel" }, { name: "Dialer" }, { name: "Smart Scripting" }, { name: "Self Service" }, { name: "Quality Management" }]
            },
            {
              title: "Unified Comms", sub: "b-hive · UCaaS",
              items: [{ name: "Business PBX" }, { name: "Video & Messaging" }, { name: "Business SMS" }, { name: "SIP Trunking" }, { name: "CX Lite" }]
            },
            {
              title: "AI Solutions", sub: "GoAI Suite",
              items: [{ name: "Voice Chatbots" }, { name: "Post Call AI" }, { name: "AI Analyst" }, { name: "Agent Assist" }, { name: "Compounding Intelligence" }]
            },
            {
              title: "Integrations", sub: "Native Connectors",
                items: [
                  { name: "MS Dynamics" },
                  { name: "Salesforce", comingSoon: true },
                  { name: "Zoho", comingSoon: true },
                  { name: "Zapier" },
                  { name: "Webhooks" },
                ]
            },
          ].map((col, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "10px 12px" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", marginBottom: 1, fontFamily: "'Inter', sans-serif" }}>{col.title}</div>
              <div style={{ fontSize: 8, color: "#888899", marginBottom: 8, fontFamily: "'Inter', monospace", letterSpacing: "0.02em" }}>{col.sub}</div>
              {col.items.map((item, j) => (
                <div key={j} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 5 }}>
                  <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#43B5BF", flexShrink: 0 }} />
                  <div style={{ fontSize: 9.5, color: "#1A1A2E", fontWeight: 600, fontFamily: "'Inter', sans-serif", display: "flex", alignItems: "center", gap: 4 }}>
                    {item.name}
                    {(item as any).comingSoon && (
                      <span style={{ fontSize: 6.5, fontWeight: 700, color: "#888899", background: "#F0F0F5", borderRadius: 3, padding: "1px 4px", letterSpacing: "0.03em", textTransform: "uppercase" }}>Coming Soon</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="page-bottom-cta" style={{ bottom: "0.3in" }}>
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" style={{ height: 53 }} />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
        </div>
      </div>

      {/* Page 2 */}
      <div className="page page-2">
        {/* Logo */}
        <div className="logo" style={{ marginBottom: 32 }}>
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* GoAI Framework Hero */}
        <div style={{
          background: "linear-gradient(130.54deg, #FCF6FF 5.82%, #E8FCFF 113.26%)",
          borderRadius: 12,
          padding: "28px 28px 24px",
          marginBottom: 18,
          position: "relative",
          overflow: "hidden",
          border: "1px solid #E2E2EC",
        }}>
          {/* Subtle grid pattern overlay */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 6 }}>GoAI Platform</div>
                <h2 className="hero-headline" style={{ fontSize: 30, marginBottom: 0, lineHeight: 1.15 }}>
                  Practical AI. <em>No specialist required.</em>
                </h2>
            </div>
            </div>

            {/* Three product cards */}
            <svg width="0" height="0" style={{ position: "absolute" }}>
              <defs>
                <linearGradient id="goai-icon-grad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#7DD4B8" />
                  <stop offset="100%" stopColor="#43B5BF" />
                </linearGradient>
              </defs>
            </svg>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginTop: 8 }}>
              {[
                {
                  name: "Engage", sub: "VOICE AI", Icon: ClipboardList,
                  desc: "Virtual agents handle routine inquiries instantly so human agents focus on conversations that actually need them.",
                  bullets: ["Handles routine inbound 24/7", "Natural language, no DTMF menus", "Escalates seamlessly to live agent"]
                },
                {
                  name: "GoAssist", sub: "AGENT AI", Icon: Handshake,
                  desc: "Real-time coaching, smart suggestions, and automated after-call work. Every agent performs like your best one from their first day.",
                  bullets: ["Live guidance during calls", "Auto-generates call summaries", "Reduces post-call admin to zero"]
                },
                {
                  name: "GoInsights", sub: "ANALYTICS AI", Icon: BarChart2,
                  desc: "Sentiment, trends, and performance insights surface automatically — so you're optimizing operations, not just reporting on what already happened.",
                  bullets: ["Real-time sentiment scoring", "Trend detection across all calls", "Proactive alerts before issues compound"]
                },
              ].map((product, i) => (
                <div key={i} style={{
                  background: "#FFFFFF",
                  border: "1px solid #E2E2EC",
                  borderRadius: 10,
                  padding: "14px 16px",
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                    <product.Icon size={20} style={{ color: "#43B5BF", flexShrink: 0 }} />
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Besley', serif", fontStyle: "italic" }}>{product.name}</div>
                      <div style={{ fontSize: 7, fontWeight: 600, letterSpacing: "0.12em", color: "#43B5BF", fontFamily: "'Inter', sans-serif" }}>{product.sub}</div>
                    </div>
                  </div>
                  <p style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.65, margin: "8px 0 10px", fontFamily: "'Inter', sans-serif" }}>
                    {product.desc}
                  </p>
                  {product.bullets.map((b, j) => (
                    <div key={j} style={{ display: "flex", alignItems: "flex-start", gap: 6, marginBottom: 4 }}>
                      <span style={{ color: "#43B5BF", fontSize: 9, lineHeight: 1.6 }}>•</span>
                      <span style={{ fontSize: 9, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
        </div>

        {/* Two-column: Partner Program + Why Broadvoice */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          {/* Left: Partner Program */}
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "18px 20px" }}>
            <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}>Partner Program</div>
            <h2 className="hero-headline" style={{ fontSize: 24, marginBottom: 8, lineHeight: 1.2 }}>
              Built to help you move <em>upmarket.</em>
            </h2>
            <p style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.7, marginBottom: 14, fontFamily: "'Inter', sans-serif" }}>
              New programs designed to help partners confidently go upmarket — with the enablement, support, and economics to make it worth your time.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {[
                { Icon: Award, title: "Clear Incentives", desc: "Transparent deal economics with no surprises mid-opportunity" },
                { Icon: BookOpen, title: "Deeper Enablement", desc: "Co-sell support, vertical-specific messaging, and deal desk access" },
                { Icon: HeadphonesIcon, title: "Hands-On Deal Support", desc: "We remove friction from complex opportunities so you close faster" },
                { Icon: Rocket, title: "Long-Term Growth Focus", desc: "Programs built around profitability and retention — not noise" },
              ].map((item, i) => (
                <div key={i} style={{
                  display: "flex", alignItems: "flex-start", gap: 10,
                  padding: "10px 14px",
                  background: "rgba(67,181,191,0.06)",
                  borderRadius: 8,
                  border: "1px solid #E2E2EC",
                }}>
                  <item.Icon size={15} style={{ stroke: "url(#vert-icon-grad)", flexShrink: 0, marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 2 }}>{item.title}</div>
                    <div style={{ fontSize: 9, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Why Broadvoice */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 20px" }}>
              <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}>Why Broadvoice</div>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <tbody>
                  {[
                    { label: "Deployment speed", value: "Days, not months" },
                    { label: "Platform model", value: "UCaaS + CCaaS + AI unified" },
                    { label: "Target segment", value: "Midmarket 50–750 employees" },
                    { label: "AI approach", value: "Built-in, not bolted-on" },
                    { label: "Support model", value: "Hands-on, partner-first" },
                    { label: "Deal desk", value: "Co-sell available" },
                  ].map((row, i) => (
                    <tr key={i} style={{ borderBottom: i < 5 ? "1px solid #F0F0F5" : "none" }}>
                      <td style={{ fontSize: 10, color: "#555567", fontFamily: "'Inter', sans-serif", padding: "7px 0" }}>{row.label}</td>
                      <td style={{ fontSize: 10, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", padding: "7px 0", textAlign: "right" }}>{row.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Sales Rep Cards */}
            <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 20px", flex: 1, background: "#F8FAFB" }}>
              <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}>Your Team</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                {[
                  { name: "Yvette Bratt", title: "Channel Manager", email: "yvetteb@broadvoice.com", photo: "/assets/yvette-bratt.png" },
                  { name: "Darlene Paisano", title: "Partner Sales Manager", email: "darlenep@broadvoice.com", photo: "/assets/darlene-paisano.png" },
                  { name: "Jacob Fox", title: "Sales Engineer", email: "jacobfox@broadvoice.com", photo: "/assets/jacob-fox.jpeg" },
                ].map((rep, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    {rep.photo ? (
                      <img src={rep.photo} alt={rep.name} style={{ width: 50, height: 50, borderRadius: "50%", objectFit: "cover", border: "1px solid #E2E2EC", flexShrink: 0 }} />
                    ) : (
                      <div style={{ width: 44, height: 44, borderRadius: "50%", background: "#F0F0F5", border: "1px solid #E2E2EC", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <span style={{ fontSize: 18, color: "#888899" }}>👤</span>
                      </div>
                    )}
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 1 }}>{rep.name}</div>
                      <div style={{ fontSize: 9, color: "#555567", fontFamily: "'Inter', sans-serif", marginBottom: 1 }}>{rep.title}</div>
                      <div style={{ fontSize: 9, color: "#338FAD", fontFamily: "'Inter', sans-serif" }}>{rep.email}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="page-bottom-cta" style={{ bottom: "0.3in" }}>
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" style={{ height: 53 }} />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
        </div>
      </div>
    </div>
  );
};

export default CompanyOverview;
