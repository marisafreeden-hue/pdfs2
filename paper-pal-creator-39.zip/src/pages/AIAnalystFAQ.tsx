import React from "react";
import "./GoEngageDatasheet.css";

interface FAQItem {
  q: string;
  a: string;
}

interface FAQSection {
  title: string;
  subtitle: string;
  items: FAQItem[];
}

const ctoItemsPage1: FAQItem[] = [
  {
    q: "What is Analyst and why use it versus pasting data into an AI like ChatGPT or Claude?",
    a: "Analyst is an AI-powered conversational analytics interface built natively into GoContact. This means Analyst does not send your operational data to a public AI model or external LLM service. Instead, it operates entirely within the GoContact platform and queries the same internal analytics dataset used by existing dashboards and reports. This means your contact center data never leaves the Broadvoice environment for AI processing. By contrast, pasting data into a general-purpose LLM involves transmitting sensitive operational information to an external service where governance and retention policies may not align with enterprise requirements.",
  },
  {
    q: "Does Analyst train AI models on our data?",
    a: "No. Analyst does not train external models using your company's operational data. The system generates responses by querying approved datasets within the GoContact analytics repository and presenting the results through a conversational interface. Customer data remains isolated within the platform and is not used to train shared models.",
  },
  {
    q: "Where is the AI processing occurring?",
    a: "Analyst operates within the GoContact analytics environment and processes queries against the platform's internal reporting dataset used by dashboards and reports. Because it is embedded within GoContact, it avoids exporting operational data to third-party analytics services or external AI engines.",
  },
  {
    q: "What compliance frameworks does the platform support?",
    a: "Analyst inherits the security and compliance posture of the GoContact platform. The platform aligns with enterprise frameworks such as ISO 27001, SOC, GDPR, HIPAA, and PCI-related controls depending on deployment region and configuration. These compliance measures are built into the underlying GoContact platform and extend to AI-powered analytics features.",
  },
  {
    q: "How is tenant isolation handled?",
    a: "Analyst inherits the same multi-tenant security architecture used by the GoContact platform. Each organization's operational data is logically separated and accessible only to authenticated users belonging to that organization. AI responses are generated solely from that tenant's approved dataset.",
  },
  {
    q: "Can Analyst access external systems or customer data sources?",
    a: "In the current release, Analyst focuses on analytics derived from GoContact voice performance data and related operational KPIs. Access to additional systems or external datasets may expand in future roadmap milestones as the platform evolves toward deeper analytics and cross-channel intelligence.",
  },
  {
    q: "How are AI queries audited or logged?",
    a: "AI queries occur within the analytics environment and are associated with authenticated users. Query activity can be reviewed through platform logging and analytics usage monitoring. Enhanced AI interaction logging and audit visibility may expand in future platform updates as adoption grows.",
  },
  {
    q: "How is prompt injection or malicious input handled?",
    a: "Analyst is intentionally constrained to descriptive analytics based on approved operational datasets. It does not execute workflows, access external systems, or generate open-ended outputs outside the reporting scope. These guardrails reduce the risk of prompt injection or unsafe instructions affecting system behavior.",
  },
];

const ctoItemsPage2: FAQItem[] = [
  {
    q: "Does Analyst generate answers or query our analytics data?",
    a: "Analyst does not generate answers independently like a general-purpose AI assistant. Instead, it translates natural language questions into structured queries against the GoContact analytics dataset. The system retrieves results from the same governed KPI definitions used by dashboards and reports and presents those results in a conversational format. Because responses are grounded in the platform's reporting dataset, every answer can be validated against existing analytics metrics.",
  },
  {
    q: "Which AI model powers Analyst?",
    a: "Analyst uses a conversational interface designed specifically for analytics queries. The system interprets natural language questions and converts them into structured queries against the GoContact analytics dataset rather than relying on open-ended generative outputs. This architecture ensures responses remain grounded in governed operational data.",
  },
];

const sections: FAQSection[] = [
  {
    title: "CTO / IT Leadership FAQs",
    subtitle: "Security architecture, data governance, platform risk",
    items: ctoItemsPage1,
  },
  {
    title: "Security / Compliance Team FAQs",
    subtitle: "Risk, privacy, governance",
    items: [
      {
        q: "Can Analyst expose sensitive customer information?",
        a: "Analyst is designed to work with operational analytics metrics rather than raw customer interaction data. The system applies role-based access controls inherited from GoContact permissions, ensuring users only see data they are authorized to access. Sensitive customer information is not surfaced unless it already exists in permitted analytics reports.",
      },
      {
        q: "How do you ensure AI responses are accurate and not fabricated?",
        a: "Analyst answers are derived directly from the platform's reporting dataset, which serves as the single source of truth for analytics. Unlike open-ended generative AI systems, Analyst is restricted to describing historical performance data and approved KPIs. If the system cannot safely answer a question from available data, it will return a fallback response rather than generating unsupported information.",
      },
      {
        q: "Can administrators control who can use Analyst?",
        a: "Yes. Analyst follows the same role-based permissions model used throughout GoContact. Administrators can control which users have access to analytics features and which datasets they are allowed to view. This ensures that agents, supervisors, and executives each see only the information appropriate to their role.",
      },
      {
        q: "Does the AI store conversations or user queries?",
        a: "AI interactions function as analytics queries rather than persistent knowledge records. The system processes the request and returns results based on available data. Future roadmap enhancements may introduce additional features for saving or sharing insights, depending on customer demand and governance considerations.",
      },
      {
        q: "How long is data retained for AI queries?",
        a: "Analyst does not maintain a separate dataset. It accesses the historical reporting dataset configured within GoContact, and the available historical range depends on the organization's data retention policies and reporting configuration.",
      },
      {
        q: "Does Analyst allow data export to external systems?",
        a: "AI-generated insights can typically be validated or reproduced through existing dashboards and reports within the analytics platform. Exporting AI conversation summaries or insights directly may be considered in future roadmap iterations as customers look for ways to share findings across teams.",
      },
      {
        q: "Can Analyst modify or write data in operational systems?",
        a: "No. Analyst is a read-only analytics interface. It retrieves information from the reporting dataset but does not modify operational systems, execute workflows, or write data.",
      },
    ],

  },
  {
    title: "Operations Leadership FAQs",
    subtitle: "Trust, usability, operational impact",
    items: [
      {
        q: "How can we validate that an AI answer is correct?",
        a: "Because Analyst queries the same analytics dataset used by dashboards and reports, the results can be verified by comparing them to existing metrics in the platform. Supervisors can cross-check results in dashboards or standard reports to confirm the accuracy of the AI-generated summary.",
      },
      {
        q: "How far back can Analyst analyze performance data?",
        a: "Analyst can analyze historical performance data available in the GoContact reporting environment. This typically includes historical metrics for queues, agents, and contact center performance trends within the platform's configured retention period.",
      },
      {
        q: "Can agents see the same data that supervisors see?",
        a: "No. Analyst respects role-based permissions. Agents typically see their own performance metrics, while supervisors may see team or queue performance and executives may see higher-level KPI summaries. The AI will not return information outside a user's access scope.",
      },
      {
        q: "Can supervisors save or share AI insights with leadership?",
        a: "Today, many organizations use Analyst to generate quick summaries that can be validated and shared through reports or dashboards. Over time, the platform may introduce enhanced capabilities for saving insights, sharing AI summaries, or integrating them into operational reporting workflows.",
      },
    ],
  },
  {
    title: "Procurement / Vendor Risk FAQs",
    subtitle: "Contract, vendor risk, operational reliability",
    items: [
      {
        q: "What uptime and reliability commitments exist for the analytics platform?",
        a: "Analyst runs on the same infrastructure as the GoContact analytics environment, which targets enterprise-grade reliability and uptime levels consistent with the platform's service commitments.",
      },
      {
        q: "What happens if the AI cannot answer a question?",
        a: "If Analyst cannot confidently retrieve an answer from the available dataset, it will return a fallback response indicating that the question cannot be answered from current data. This approach prevents the system from generating unsupported conclusions.",
      },
      {
        q: "What happens if we stop using Analyst?",
        a: "Analyst does not create a separate data repository or proprietary dataset. All analytics data remains within the GoContact platform's reporting environment, meaning organizations retain access to their operational data regardless of AI usage.",
      },
    ],
  },
  {
    title: "Strategic AI Adoption FAQ",
    subtitle: "",
    items: [
      {
        q: "Why is an embedded AI analytics tool safer than using external AI tools?",
        a: "Embedded AI solutions like Analyst operate within the same security, governance, and data boundaries as the core platform. External AI tools typically require exporting data outside the operational environment, which introduces additional risk around data exposure, retention policies, and compliance obligations. By keeping AI inside the platform, organizations maintain full control over their operational data while still benefiting from conversational analytics.",
      },
    ],
  },
];

const renderSection = (section: FAQSection, idx: number) => (
  <div key={idx} className="faq-section">
    <div className="faq-section-header">
      <h3 className="faq-section-title">{section.title}</h3>
    </div>
    {section.items.map((item, i) => (
      <div key={i} className="faq-item">
        <div className="faq-question">{item.q}</div>
        <div className="faq-answer">{item.a}</div>
      </div>
    ))}
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const AIAnalystFAQ: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  // Page 1: Hero + CTO (all 8) + Operations (4) + Procurement (3) + Strategic (1)
  // Page 2: Security/Compliance (6)

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="partner-hero">
          <h1 className="hero-headline">
            GoContact Analyst
          </h1>
          <div className="faq-title-sub">Frequently Asked Questions</div>
        </div>

        <hr />

        {renderSection(sections[0], 0)}

        <PageFooter />
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="faq-section">
          <div className="faq-section-header">
            <h3 className="faq-section-title">CTO / IT Leadership FAQs (continued)</h3>
          </div>
          {ctoItemsPage2.map((item, i) => (
            <div key={i} className="faq-item">
              <div className="faq-question">{item.q}</div>
              <div className="faq-answer">{item.a}</div>
            </div>
          ))}
        </div>

        {renderSection(sections[1], 1)}

        <PageFooter />
      </div>

      {/* ===== PAGE 3 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="faq-section">
          <div className="faq-section-header">
            <h3 className="faq-section-title">Security / Compliance Team FAQs (continued)</h3>
          </div>
          <div className="faq-item">
            <div className="faq-question">Does Analyst process personally identifiable information (PII)?</div>
            <div className="faq-answer">Analyst focuses on operational analytics metrics rather than raw customer interaction data. Access to any underlying information follows the same role-based permissions applied across the GoContact platform. Users only see the data they are authorized to access based on their role and permissions.</div>
          </div>
        </div>

        {renderSection(sections[2], 2)}
        {renderSection(sections[3], 3)}
        {renderSection(sections[4], 4)}

        <PageFooter />
      </div>
    </div>
  );
};

export default AIAnalystFAQ;