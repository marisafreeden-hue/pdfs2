import React from "react";
import VerticalFlyer, { buildSolutions } from "./VerticalFlyer";
import hero from "@/assets/hero-realestate.jpg.asset.json";

const RealEstateFlyer: React.FC = () => (
  <VerticalFlyer
    eyebrow="Broadvoice for Real Estate"
    headlineLine1="Turn Responsiveness"
    headlineAccent="Into Revenue"
    heroImage={hero.url}
    pullQuote="Help teams act faster on client, tenant, resident, and property conversations."
    intro="Broadvoice helps real estate organizations reduce communications complexity while improving customer responsiveness — connecting agents, leasing, property, and operations teams with unified communications, contact center, text messaging, agentic AI, and analytics."
    stats={[
      { num: "99.999%", label: <><strong>Platform uptime SLA</strong>so inbound leads, tenant lines, and after-hours calls never hit a dead end.</> as any },
      { num: "$11", label: <><strong>Saved per call</strong>using AI vs. a live agent for routine showing, leasing, and maintenance intake.</> as any },
      { num: "<2 mo", label: <><strong>Payback on AI</strong>across leasing, property management, and resident services.</> as any },
    ]}
    sectionTitle="Built for the"
    sectionTitleEm="speed of every property conversation"
    sectionBody="Real estate teams compete on responsiveness — buyers, sellers, tenants, and residents call from every channel, at every hour, expecting an immediate answer from the right person."
    challenges={[
      { n: "01", title: "Lead response speed", body: "Inbound buyer and renter leads convert when answered in minutes. Missed calls go straight to a competitor." },
      { n: "02", title: "Multi-property routing", body: "Agents, leasing offices, and property managers across many sites — without a dedicated operator at each location." },
      { n: "03", title: "After-hours coverage", body: "Showings, maintenance emergencies, and prospect inquiries don't follow business hours. Voicemail isn't enough." },
      { n: "04", title: "Mobile-first teams", body: "Agents and field staff live on their phones — they need a business line, SMS, and recording from any device." },
      { n: "05", title: "Resident & tenant service", body: "Maintenance intake, rent questions, and lease renewals create steady volume that overwhelms small back-office teams." },
      { n: "06", title: "Performance visibility", body: "Leaders need response, conversion, and missed-opportunity insight across every office and property." },
    ]}
    page2Title="A unified platform for"
    page2TitleEm="every property and resident interaction"
    page2Body="Four integrated solutions — phone system, contact center, agentic AI, and analytics — built for the speed and scale of modern real estate operations."
    solutions={buildSolutions(
      {
        ucaas: "Connect agents, leasing offices, property teams, and operations leaders across locations and devices.",
        ccaas: "Client, tenant, and resident contact center with consistent routing and full interaction context.",
        ai: "Agentic AI that resolves routine inbound calls — hours, availability, showings, maintenance intake — 24/7.",
        insights: "Real-time visibility into response patterns, call volume, and missed-opportunity trends.",
      },
      {
        ucaas: [["Mobile app", "agents respond without sharing personal numbers"], ["Multi-office routing", "one number, any team"], ["Bubble texting", "showing, lease, and rent reminders"]],
        ccaas: [["Lead & tenant queues", "routed by property or service type"], ["Screen pop", "CRM & PMS context before answer"], ["Supervisor view", "live queue & coaching"]],
        ai: [["24/7 answering", "hours, availability, directions"], ["Maintenance intake", "structured ticket creation"], ["Warm escalation", "to the right human, every time"]],
        insights: [["Response trends", "speed-to-lead by team & property"], ["Missed-call alerts", "after-hours & abandonment"], ["Plain-language reports", "no analyst required"]],
      }
    )}
    cta="Connect with Broadvoice to improve responsiveness, reduce coordination friction, and modernize real estate communications."
    flexibleSolutionsLabel="Flexible Solutions for Real Estate Organizations"
    sectionOffset={10}
  />
);

export default RealEstateFlyer;
