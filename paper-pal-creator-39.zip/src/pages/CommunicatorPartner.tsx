import React from "react";
import broadvoiceLogo from "@/assets/broadvoice-logo.svg";

const CommunicatorPartner: React.FC = () => {
  return (
    <div className="gc-site">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Instrument+Sans:wght@400;500;600&family=Besley:ital,wght@1,400;1,500&display=swap');

        .gc-site {
          font-family: 'Inter', -apple-system, sans-serif;
          color: #0F1B2A;
          background: #FFFFFF;
          -webkit-font-smoothing: antialiased;
          line-height: 1.5;
          overflow-x: hidden;
        }
        .gc-site * { box-sizing: border-box; }
        .gc-site a { color: inherit; text-decoration: none; }
        .gc-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }

        /* ===== NAV ===== */
        .gc-nav {
          position: sticky; top: 0; z-index: 50;
          background: rgba(255,255,255,0.85);
          backdrop-filter: saturate(180%) blur(14px);
          -webkit-backdrop-filter: saturate(180%) blur(14px);
          border-bottom: 1px solid rgba(15,27,42,0.06);
        }
        .gc-nav-inner {
          display: flex; align-items: center; justify-content: space-between;
          height: 72px;
        }
        .gc-cobrand { display: flex; align-items: center; gap: 16px; }
        .gc-cobrand-bv { display: flex; flex-direction: column; align-items: flex-start; gap: 3px; }
        .gc-cobrand-bv img { height: 22px; width: auto; display: block; }
        .gc-cobrand-bv .ap {
          font-size: 7.5px; font-weight: 700;
          letter-spacing: 0.18em; text-transform: uppercase;
          color: #27698F; line-height: 1;
        }
        .gc-cobrand-divider {
          width: 1px; height: 36px;
          background: linear-gradient(180deg, transparent, #C9D2DA, transparent);
        }
        .gc-cobrand-partner {
          display: inline-flex; align-items: center; justify-content: center;
          min-width: 110px; height: 38px; padding: 0 14px;
          border: 1px dashed #C9D2DA; border-radius: 6px;
          font-size: 9px; font-weight: 600;
          letter-spacing: 0.16em; text-transform: uppercase;
          color: #8A93A0;
        }
        .gc-nav-links { display: flex; gap: 28px; align-items: center; }
        .gc-nav-links a { font-size: 14px; font-weight: 500; color: #44546A; }
        .gc-nav-links a:hover { color: #27698F; }
        .gc-cta {
          display: inline-flex; align-items: center; justify-content: center;
          padding: 10px 18px; border-radius: 999px;
          background: linear-gradient(135deg, #43B5BF, #27698F);
          color: #fff !important; font-weight: 600; font-size: 13.5px;
          letter-spacing: 0.01em;
          box-shadow: 0 8px 24px -8px rgba(39,105,143,0.5);
          transition: transform .2s ease, box-shadow .2s ease;
        }
        .gc-cta:hover { transform: translateY(-1px); box-shadow: 0 14px 28px -10px rgba(39,105,143,0.55); }
        .gc-nav-toggle { display: none; }

        /* ===== HERO ===== */
        .gc-hero {
          position: relative;
          padding: 96px 0 88px;
          overflow: hidden;
        }
        .gc-hero::before {
          content: ""; position: absolute; inset: 0;
          background:
            radial-gradient(900px 480px at 85% -10%, rgba(198,134,248,0.18), transparent 60%),
            radial-gradient(900px 600px at -10% 10%, rgba(67,181,191,0.22), transparent 60%),
            radial-gradient(700px 500px at 50% 110%, rgba(39,105,143,0.12), transparent 60%);
          pointer-events: none;
        }
        .gc-hero-inner { position: relative; display: grid; grid-template-columns: 1.15fr .85fr; gap: 56px; align-items: center; }
        .gc-eyebrow {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 6px 12px; border-radius: 999px;
          background: rgba(39,105,143,0.08);
          border: 1px solid rgba(39,105,143,0.18);
          font-size: 12px; font-weight: 600;
          letter-spacing: 0.10em; text-transform: uppercase;
          color: #27698F;
          margin-bottom: 22px;
        }
        .gc-eyebrow::before {
          content: ""; width: 6px; height: 6px; border-radius: 50%;
          background: linear-gradient(135deg, #43B5BF, #27698F);
        }
        .gc-h1 {
          font-family: 'Instrument Sans', sans-serif;
          font-size: clamp(40px, 5.4vw, 72px);
          line-height: 1.04; font-weight: 500;
          letter-spacing: -0.025em;
          margin: 0 0 18px;
          background: linear-gradient(90deg, #43B5BF 0%, #27698F 55%, #C686F8 100%);
          -webkit-background-clip: text; background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .gc-h1 em {
          font-family: 'Besley', serif; font-style: italic; font-weight: 400;
        }
        .gc-sub {
          font-family: 'Besley', Georgia, serif; font-style: italic;
          font-size: clamp(18px, 1.8vw, 22px);
          color: #44546A; max-width: 560px;
          margin: 0 0 20px;
        }
        .gc-lede {
          font-size: 16px; color: #44546A; max-width: 560px;
          margin: 0 0 28px;
        }
        .gc-lede strong { color: #27698F; font-weight: 600; }
        .gc-hero-actions { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
        .gc-cta-ghost {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 10px 16px; font-weight: 600; font-size: 13.5px;
          color: #27698F;
        }
        .gc-cta-ghost::after { content: "→"; transition: transform .2s ease; }
        .gc-cta-ghost:hover::after { transform: translateX(4px); }

        /* hero stat card */
        .gc-hero-card {
          position: relative; justify-self: end;
          width: 100%; max-width: 380px;
          padding: 32px 32px 30px;
          border-radius: 24px;
          background: linear-gradient(160deg, #FFFFFF 0%, #F4F8FB 100%);
          border: 1px solid rgba(39,105,143,0.12);
          box-shadow: 0 30px 60px -30px rgba(15,27,42,0.25);
        }
        .gc-hero-card::before {
          content: ""; position: absolute; inset: -1px; border-radius: 24px;
          background: linear-gradient(135deg, rgba(67,181,191,0.5), rgba(198,134,248,0.4));
          -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
          mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
          -webkit-mask-composite: xor; mask-composite: exclude;
          padding: 1px; pointer-events: none;
        }
        .gc-hc-label { font-size: 12px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #27698F; }
        .gc-hc-value {
          font-family: 'Instrument Sans', sans-serif;
          font-size: 88px; line-height: 1; font-weight: 500; letter-spacing: -0.04em;
          background: linear-gradient(135deg, #43B5BF, #27698F);
          -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
          margin: 10px 0 4px;
        }
        .gc-hc-value em { font-family: 'Besley', serif; font-style: italic; font-size: 56px; }
        .gc-hc-desc { font-size: 14px; color: #44546A; }
        .gc-hc-chips { display: flex; gap: 8px; margin-top: 18px; flex-wrap: wrap; }
        .gc-hc-chips span {
          font-size: 11px; font-weight: 600; padding: 5px 10px;
          border-radius: 999px; background: rgba(67,181,191,0.10); color: #1F6478;
        }

        /* ===== CHECK BENEFITS BAR ===== */
        .gc-benefits {
          padding: 28px 0;
          border-top: 1px solid rgba(15,27,42,0.06);
          border-bottom: 1px solid rgba(15,27,42,0.06);
        }
        .gc-benefits-inner { display: grid; grid-template-columns: repeat(3, 1fr); gap: 28px; }
        .gc-benefit { display: flex; gap: 12px; align-items: flex-start; }
        .gc-check {
          flex: none; width: 22px; height: 22px; border-radius: 50%;
          background: linear-gradient(135deg, #43B5BF, #27698F);
          display: inline-flex; align-items: center; justify-content: center;
          color: #fff; font-size: 12px; font-weight: 800;
        }
        .gc-benefit h4 { margin: 0 0 2px; font-size: 14px; font-weight: 600; color: #0F1B2A; }
        .gc-benefit p { margin: 0; font-size: 13px; color: #6B7280; }

        /* ===== SECTION ===== */
        .gc-section { padding: 96px 0; position: relative; }
        .gc-section.alt { background: linear-gradient(180deg, #F7FAFC 0%, #FFFFFF 100%); }
        .gc-section-head { max-width: 760px; margin: 0 auto 56px; text-align: center; }
        .gc-kicker {
          display: inline-block; font-size: 12px; font-weight: 700;
          letter-spacing: 0.16em; text-transform: uppercase;
          color: #27698F; margin-bottom: 12px;
        }
        .gc-h2 {
          font-family: 'Instrument Sans', sans-serif;
          font-size: clamp(32px, 3.6vw, 48px);
          line-height: 1.1; font-weight: 500; letter-spacing: -0.022em;
          color: #0F1B2A; margin: 0 0 14px;
        }
        .gc-h2 em {
          font-family: 'Besley', serif; font-style: italic; font-weight: 400;
          background: linear-gradient(90deg, #43B5BF, #27698F);
          -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
        }
        .gc-section-head p { font-size: 17px; color: #44546A; margin: 0; }

        /* feature grid */
        .gc-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .gc-card {
          padding: 28px; border-radius: 18px;
          background: #FFFFFF;
          border: 1px solid rgba(15,27,42,0.08);
          transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease;
        }
        .gc-card:hover {
          transform: translateY(-3px);
          border-color: rgba(39,105,143,0.25);
          box-shadow: 0 24px 40px -24px rgba(15,27,42,0.18);
        }
        .gc-card-icon {
          width: 40px; height: 40px; border-radius: 10px;
          background: linear-gradient(135deg, rgba(67,181,191,0.16), rgba(39,105,143,0.16));
          display: inline-flex; align-items: center; justify-content: center;
          color: #27698F; font-weight: 700; font-size: 16px;
          margin-bottom: 16px;
        }
        .gc-card h3 { margin: 0 0 8px; font-size: 17px; font-weight: 600; color: #0F1B2A; }
        .gc-card p { margin: 0; font-size: 14px; color: #6B7280; line-height: 1.55; }

        /* stats */
        .gc-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }
        .gc-stat {
          padding: 28px; border-radius: 18px;
          background: linear-gradient(160deg, #FFFFFF, #F4F8FB);
          border: 1px solid rgba(39,105,143,0.12);
          text-align: left;
        }
        .gc-stat .num {
          font-family: 'Instrument Sans', sans-serif;
          font-size: 56px; line-height: 1; font-weight: 500; letter-spacing: -0.03em;
          background: linear-gradient(135deg, #43B5BF, #27698F);
          -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
        }
        .gc-stat .num em { font-family: 'Besley', serif; font-style: italic; font-size: 36px; }
        .gc-stat strong { display: block; margin: 10px 0 4px; font-size: 15px; color: #0F1B2A; }
        .gc-stat p { margin: 0; font-size: 13.5px; color: #6B7280; }

        /* CTA banner */
        .gc-banner {
          position: relative; overflow: hidden;
          padding: 56px;
          border-radius: 28px;
          background: linear-gradient(135deg, #1F6478 0%, #27698F 50%, #43B5BF 100%);
          color: #fff;
          display: grid; grid-template-columns: 1.4fr auto; align-items: center; gap: 28px;
        }
        .gc-banner::after {
          content: ""; position: absolute; inset: 0;
          background:
            radial-gradient(600px 300px at 90% 110%, rgba(198,134,248,0.45), transparent 60%),
            radial-gradient(500px 250px at 10% -20%, rgba(255,255,255,0.18), transparent 60%);
          pointer-events: none;
        }
        .gc-banner > * { position: relative; z-index: 1; }
        .gc-banner h2 {
          font-family: 'Instrument Sans', sans-serif;
          font-size: clamp(28px, 3vw, 40px); line-height: 1.15; font-weight: 500; letter-spacing: -0.02em;
          margin: 0 0 8px; color: #fff;
        }
        .gc-banner h2 em { font-family: 'Besley', serif; font-style: italic; font-weight: 400; }
        .gc-banner p { margin: 0; opacity: 0.9; font-size: 15px; max-width: 540px; }
        .gc-banner-cta {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 14px 24px; border-radius: 999px;
          background: #fff; color: #27698F !important;
          font-weight: 700; font-size: 14px;
          box-shadow: 0 20px 40px -16px rgba(0,0,0,0.35);
        }

        /* WFM table */
        .gc-table-wrap {
          border-radius: 18px; overflow: hidden;
          border: 1px solid rgba(15,27,42,0.08);
          background: #fff;
        }
        .gc-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .gc-table th {
          text-align: left; padding: 16px 20px;
          background: linear-gradient(135deg, rgba(67,181,191,0.10), rgba(39,105,143,0.10));
          color: #0F1B2A; font-weight: 700; font-size: 12px;
          letter-spacing: 0.10em; text-transform: uppercase;
          border-bottom: 1px solid rgba(15,27,42,0.08);
        }
        .gc-table td {
          padding: 16px 20px; border-bottom: 1px solid rgba(15,27,42,0.06);
          color: #44546A; vertical-align: top;
        }
        .gc-table td:first-child { font-weight: 600; color: #0F1B2A; }
        .gc-table tr:last-child td { border-bottom: none; }

        /* ===== FOOTER ===== */
        .gc-footer {
          padding: 56px 0 32px;
          background: #0F1B2A;
          color: #B6C2D2;
        }
        .gc-footer-inner {
          display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr; gap: 40px;
          padding-bottom: 36px; border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .gc-footer h5 { color: #fff; font-size: 13px; font-weight: 700; letter-spacing: 0.10em; text-transform: uppercase; margin: 0 0 14px; }
        .gc-footer ul { list-style: none; padding: 0; margin: 0; display: grid; gap: 10px; }
        .gc-footer ul a { font-size: 14px; color: #B6C2D2; }
        .gc-footer ul a:hover { color: #fff; }
        .gc-footer .gc-cobrand-bv img { filter: brightness(0) invert(1); height: 24px; }
        .gc-footer .gc-cobrand-bv .ap { color: #6BB6C7; }
        .gc-footer p.tag { font-size: 13.5px; line-height: 1.6; margin: 14px 0 0; max-width: 360px; color: #8FA0B5; }
        .gc-footer-bottom {
          display: flex; justify-content: space-between; align-items: center;
          padding-top: 24px; font-size: 12px; color: #6E7E92;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 960px) {
          .gc-hero { padding: 64px 0 56px; }
          .gc-hero-inner { grid-template-columns: 1fr; gap: 40px; }
          .gc-hero-card { justify-self: stretch; max-width: none; }
          .gc-benefits-inner { grid-template-columns: 1fr; gap: 18px; }
          .gc-grid { grid-template-columns: 1fr 1fr; }
          .gc-stats { grid-template-columns: 1fr 1fr; }
          .gc-banner { grid-template-columns: 1fr; padding: 36px; text-align: left; }
          .gc-footer-inner { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 640px) {
          .gc-nav-inner { height: 64px; }
          .gc-cobrand { gap: 12px; }
          .gc-cobrand-partner { min-width: 90px; height: 34px; font-size: 8px; padding: 0 10px; }
          .gc-nav-links { display: none; }
          .gc-section { padding: 64px 0; }
          .gc-section-head { margin-bottom: 36px; }
          .gc-grid, .gc-stats { grid-template-columns: 1fr; }
          .gc-table th, .gc-table td { padding: 12px 14px; font-size: 13px; }
          .gc-banner { padding: 28px; border-radius: 20px; }
          .gc-footer-inner { grid-template-columns: 1fr; gap: 28px; }
          .gc-footer-bottom { flex-direction: column; gap: 10px; }
        }
      `}</style>

      {/* NAV */}
      <header className="gc-nav">
        <div className="gc-container gc-nav-inner">
          <div className="gc-cobrand">
            <div className="gc-cobrand-bv">
              <img src={broadvoiceLogo} alt="Broadvoice" />
              <span className="ap">Authorized Partner</span>
            </div>
            <div className="gc-cobrand-divider" aria-hidden="true" />
            <div className="gc-cobrand-partner">Partner Logo</div>
          </div>
          <nav className="gc-nav-links" aria-label="Primary">
            <a href="#plataforma">Plataforma</a>
            <a href="#ecosistema">Ecosistema</a>
            <a href="#wfm">WFM</a>
            <a href="#contacto" className="gc-cta">Solicitar Demo</a>
          </nav>
        </div>
      </header>

      {/* HERO */}
      <section className="gc-hero">
        <div className="gc-container gc-hero-inner">
          <div>
            <span className="gc-eyebrow">Contact Center · 100% Cloud</span>
            <h1 className="gc-h1">Go<em>Contact</em>.<br/>Conversaciones <em>inteligentes</em>, operaciones simples.</h1>
            <p className="gc-sub">Plataforma de Contact Center omnicanal 100% en Cloud.</p>
            <p className="gc-lede">
              Reduce la complejidad tecnológica y aumenta el control, el rendimiento y la eficiencia de tu operación. <strong>GoContact</strong> es la solución que une voz, datos e IA en un único entorno.
            </p>
            <div className="gc-hero-actions">
              <a href="#contacto" className="gc-cta">Solicitar Demo</a>
              <a href="#plataforma" className="gc-cta-ghost">Conoce la plataforma</a>
            </div>
          </div>

          <aside className="gc-hero-card" aria-label="Resultado clave">
            <div className="gc-hc-label">Reducción de</div>
            <div className="gc-hc-value">40<em>%</em></div>
            <div className="gc-hc-desc">en costes de implementación gracias a la autonomía de configuración.</div>
            <div className="gc-hc-chips">
              <span>+20% eficiencia</span>
              <span>26% ahorro ROI</span>
              <span>70% automatización</span>
            </div>
          </aside>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="gc-benefits">
        <div className="gc-container gc-benefits-inner">
          <div className="gc-benefit">
            <span className="gc-check">✓</span>
            <div><h4>Know-how operacional</h4><p>Años especializados exclusivamente en Contact Centers.</p></div>
          </div>
          <div className="gc-benefit">
            <span className="gc-check">✓</span>
            <div><h4>Presencia global</h4><p>Despliegues internacionales con soporte local y multi-idioma.</p></div>
          </div>
          <div className="gc-benefit">
            <span className="gc-check">✓</span>
            <div><h4>Seguridad y robustez</h4><p>Infraestructura cloud con altos estándares de continuidad operativa.</p></div>
          </div>
        </div>
      </section>

      {/* PLATAFORMA / REPORTING */}
      <section id="plataforma" className="gc-section">
        <div className="gc-container">
          <div className="gc-section-head">
            <span className="gc-kicker">Reporting en tiempo real</span>
            <h2 className="gc-h2">Datos que <em>cuentan la historia</em> de tu operación</h2>
            <p>Informes claros, accionables y a medida — diseñados para que cada equipo entienda lo que está pasando, justo cuando importa.</p>
          </div>

          <div className="gc-grid">
            <article className="gc-card">
              <div className="gc-card-icon">◇</div>
              <h3>Autonomía de configuración</h3>
              <p>Más del 40% de reducción en costes de implementación gracias a la configuración self-service.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">≡</div>
              <h3>Datos simples y concisos</h3>
              <p>Información fácil de interpretar para tomar decisiones rápidas en cualquier nivel del equipo.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">◐</div>
              <h3>Informes en tiempo real</h3>
              <p>Reportes históricos y en vivo, totalmente personalizables según los KPIs de tu operación.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">▦</div>
              <h3>Dashboards &amp; Wallboards</h3>
              <p>Visualización en vivo para supervisores y agentes con métricas que se actualizan al instante.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">!</div>
              <h3>Alertas &amp; Notificaciones</h3>
              <p>Configura umbrales y recibe avisos automáticos cuando algo cambie en la operación.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">★</div>
              <h3>Análisis del agente</h3>
              <p>Segmentación, filtrado y desempeño individual para impulsar coaching basado en datos reales.</p>
            </article>
          </div>
        </div>
      </section>

      {/* RESULTS / STATS */}
      <section className="gc-section alt">
        <div className="gc-container">
          <div className="gc-section-head">
            <span className="gc-kicker">Resultados medibles</span>
            <h2 className="gc-h2">Mejora considerablemente <em>tu negocio</em></h2>
            <p>Cifras reales que la plataforma ayuda a desbloquear en operaciones de Contact Center.</p>
          </div>

          <div className="gc-stats">
            <div className="gc-stat">
              <div className="num">40<em>%</em></div>
              <strong>Menos costes</strong>
              <p>De implementación, con autonomía de configuración.</p>
            </div>
            <div className="gc-stat">
              <div className="num">30<em>%</em></div>
              <strong>Optimización de tiempo</strong>
              <p>En tareas rutinarias de los equipos humanos.</p>
            </div>
            <div className="gc-stat">
              <div className="num">20<em>%</em></div>
              <strong>Más eficiencia</strong>
              <p>Aumento medible en la eficiencia de la operación.</p>
            </div>
            <div className="gc-stat">
              <div className="num">26<em>%</em></div>
              <strong>Ahorro ROI</strong>
              <p>Reducción directa de costes operativos.</p>
            </div>
          </div>
        </div>
      </section>

      {/* ECOSISTEMA */}
      <section id="ecosistema" className="gc-section">
        <div className="gc-container">
          <div className="gc-section-head">
            <span className="gc-kicker">Ecosistema CX</span>
            <h2 className="gc-h2">Donde la IA y los datos <em>impulsan tu negocio</em></h2>
            <p>Una plataforma única que reúne automatización, análisis y herramientas para agentes en un mismo flujo.</p>
          </div>

          <div className="gc-grid">
            <article className="gc-card">
              <div className="gc-card-icon">▥</div>
              <h3>Advanced Analytics</h3>
              <p>Dashboards personalizables, informes detallados y análisis en tiempo real e histórico.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">✓</div>
              <h3>Quality Assurance Automation</h3>
              <p>Coaching basado en interacciones reales. Identifica áreas de mejora y mide el progreso.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">◉</div>
              <h3>Virtual Agent</h3>
              <p>Chatbot, voicebot y emailbot con ASR, speech-to-text e IA generativa para FAQs.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">⌁</div>
              <h3>Agent Assist</h3>
              <p>Sentiment en tiempo real, smart scripts, next-best-action y guidance contextual.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">∞</div>
              <h3>Go.AI — 100% Automated</h3>
              <p>Self-service avanzado, IVR transaccional y NLP que resuelve sin intervención humana.</p>
            </article>
            <article className="gc-card">
              <div className="gc-card-icon">⟲</div>
              <h3>Post-Call AI</h3>
              <p>Resumen de llamada, sentiment, transcripción y soporte para equipos de QA y auditoría.</p>
            </article>
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="gc-section" style={{ paddingTop: 0 }}>
        <div className="gc-container">
          <div className="gc-banner">
            <div>
              <h2>Transforma eficiencia en <em>ROI</em> para tu Contact Center.</h2>
              <p>Con el poder de la IA, automatiza hasta el 70% de las tareas repetitivas y libera a tus equipos para lo que realmente importa.</p>
            </div>
            <a href="#contacto" className="gc-banner-cta">Empieza hoy →</a>
          </div>
        </div>
      </section>

      {/* WFM */}
      <section id="wfm" className="gc-section alt">
        <div className="gc-container">
          <div className="gc-section-head">
            <span className="gc-kicker">WFM</span>
            <h2 className="gc-h2">WorkForce <em>Management</em></h2>
            <p>Planificación, monitoreo y optimización de tu fuerza de trabajo en un módulo integrado a GoContact.</p>
          </div>

          <div className="gc-table-wrap">
            <table className="gc-table">
              <thead>
                <tr>
                  <th>Capacidad</th>
                  <th>Qué hace</th>
                  <th>Beneficio</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>Planificación &amp; Programación</td><td>Turnos, agendas y forecasting</td><td>Cobertura óptima sin sobre-staffing</td></tr>
                <tr><td>Monitoreo en Tiempo Real</td><td>Visibilidad live de la operación</td><td>Decisiones rápidas y reactivas</td></tr>
                <tr><td>Gestión de Capacidades</td><td>Habilidades y skill-based routing</td><td>Cliente correcto, agente correcto</td></tr>
                <tr><td>Asistencia &amp; Puntualidad</td><td>Control de adherencia</td><td>Disciplina operativa medible</td></tr>
                <tr><td>Optimización de Costes</td><td>Análisis de coste laboral</td><td>Eficiencia sin perder calidad</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer id="contacto" className="gc-footer">
        <div className="gc-container">
          <div className="gc-footer-inner">
            <div>
              <div className="gc-cobrand">
                <div className="gc-cobrand-bv">
                  <img src={broadvoiceLogo} alt="Broadvoice" />
                  <span className="ap">Authorized Partner</span>
                </div>
              </div>
              <p className="tag">
                Broadvoice ofrece soluciones inteligentes de comunicaciones y CX para empresas en crecimiento y organizaciones mid-market — para que tus equipos trabajen, conecten y atiendan clientes desde cualquier lugar.
              </p>
            </div>
            <div>
              <h5>Plataforma</h5>
              <ul>
                <li><a href="#plataforma">Reporting</a></li>
                <li><a href="#ecosistema">Ecosistema CX</a></li>
                <li><a href="#wfm">WFM</a></li>
              </ul>
            </div>
            <div>
              <h5>Recursos</h5>
              <ul>
                <li><a href="#">Casos de éxito</a></li>
                <li><a href="#">Documentación</a></li>
                <li><a href="#">Soporte</a></li>
              </ul>
            </div>
            <div>
              <h5>Contacto</h5>
              <ul>
                <li><a href="#contacto">Solicitar demo</a></li>
                <li><a href="mailto:hello@broadvoice.com">hello@broadvoice.com</a></li>
                <li><a href="tel:+18666001007">866.600.1007</a></li>
              </ul>
            </div>
          </div>
          <div className="gc-footer-bottom">
            <span>© {new Date().getFullYear()} Broadvoice. Todos los derechos reservados.</span>
            <span>Llevado a ti por tu Broadvoice Authorized Partner.</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CommunicatorPartner;
