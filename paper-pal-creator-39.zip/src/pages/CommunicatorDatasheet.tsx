import React from "react";
import "./GoEngageDatasheet.css";

const CommunicatorDatasheet: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="hero">
          <div>
            <h1 className="hero-headline">
              b-<em>hive</em> Communicator
            </h1>
            <p className="hero-body">
              Stay productive from anywhere.
            </p>
            <p className="hero-desc">
              Communicator combines calling, video, messaging, collaboration, voicemail, and fax in a single experience — developed, managed, and continuously enhanced by Broadvoice. Built for growing businesses and mid-market organizations to replace disconnected tools with one application.
            </p>
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <div className="stat-label-top">One App For</div>
              <div className="stat-value">
                <span className="stat-value-sans">6 </span><em>tools</em>
              </div>
              <div className="stat-desc">
                Calling, video, messaging,<br />collaboration, voicemail &amp; fax
              </div>
            </div>
          </div>
        </div>

        <hr />

        {/* One App For Business Communications */}
        <h2 className="section-title">One App for Business <em>Communications</em></h2>
        <p className="section-body">
          Replace the patchwork of disconnected tools with a single Broadvoice experience. Setup is straightforward, the interface is intuitive, and our team works closely with you to ensure a smooth rollout, strong adoption, and long-term success.
        </p>

        <div className="feature-grid">
          <div className="feature-item">
            <div className="feature-title">Calling, Messaging, Voicemail &amp; Fax</div>
            <div className="feature-body">
              Manage business calls, SMS, voicemail, fax, and call handling functions from a single application.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Video Meetings &amp; Collaboration</div>
            <div className="feature-body">
              Connect employees through video conferencing, screen sharing, team chat, group messaging, meeting lobbies, and collaboration tools.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Work from Anywhere</div>
            <div className="feature-body">
              The same communications experience across desktop and mobile — in the office, at home, or on the go.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Connect with Individuals or Teams</div>
            <div className="feature-body">
              Chat one-on-one or collaborate in group conversations to keep employees aligned and productive.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Built-In Call Management</div>
            <div className="feature-body">
              Manage calls with hold, mute, blind transfer, call history, and on-demand call recording — all built in.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Presence &amp; Availability</div>
            <div className="feature-body">
              View employee status in real time, with calendar integrations that automatically reflect when employees are in meetings.
            </div>
          </div>
        </div>

        <hr className="section-divider" />

        {/* Why Organizations Choose */}
        <h2 className="section-title" style={{ marginTop: '12px' }}>Why Organizations Choose <em>Communicator</em></h2>

        <div className="stats-row" style={{ marginTop: '8px' }}>
          <div className="stat-item">
            <div className="num" style={{ fontSize: '22px' }}>One App</div>
            <div className="lbl">
              <strong>One Experience</strong>
              Calling, messaging, meetings, voicemail, and fax in a single application.
            </div>
          </div>
          <div className="stat-item">
            <div className="num" style={{ fontSize: '22px' }}>Hybrid Ready</div>
            <div className="lbl">
              <strong>Built for Hybrid Work</strong>
              A consistent experience across desktop and mobile for office, remote, and mobile employees.
            </div>
          </div>
          <div className="stat-item">
            <div className="num" style={{ fontSize: '22px' }}>Easy to Deploy</div>
            <div className="lbl">
              <strong>Simple to Use &amp; Manage</strong>
              Get up and running quickly with a straightforward deployment and intuitive interface.
            </div>
          </div>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <h2 className="section-title">Designed for the Way <em>Teams Work</em></h2>
        <p className="section-body">
          Communicator is purpose-built for growing businesses and mid-market organizations that need to keep employees connected without the complexity of stitching together multiple vendors.
        </p>

        <div className="feature-grid">
          <div className="feature-item">
            <div className="feature-title">Keep Employees Connected</div>
            <div className="feature-body">
              Give every employee the tools they need to communicate and collaborate from anywhere.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Simplify Communications</div>
            <div className="feature-body">
              Reduce complexity by replacing multiple disconnected tools with a single Broadvoice solution.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Easy to Manage</div>
            <div className="feature-body">
              An intuitive admin experience and straightforward deployment process — no specialized expertise required.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Backed by Broadvoice</div>
            <div className="feature-body">
              Onboarding, training, and support teams that help drive adoption and maximize value.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Continuously Enhanced</div>
            <div className="feature-body">
              Developed and managed by Broadvoice with ongoing improvements — not a third-party patchwork.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Consistent Experience</div>
            <div className="feature-body">
              The same look, feel, and capabilities across every user, device, and location.
            </div>
          </div>
        </div>

        <hr />

        <h2 className="section-title">Available for iOS, Android &amp; <em>Desktop</em></h2>
        <p className="section-body">
          Communicator works across desktop and mobile devices, helping employees stay connected whether they are in the office, working remotely, or on the move. One login. One experience. Everywhere.
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Platform</th>
                <th>Built For</th>
                <th>Key Capabilities</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Desktop</td>
                <td>Windows &amp; macOS</td>
                <td>Calling, video, messaging, screen share, call control</td>
              </tr>
              <tr>
                <td>iOS</td>
                <td>iPhone &amp; iPad</td>
                <td>Full calling, messaging, voicemail &amp; meetings on the go</td>
              </tr>
              <tr>
                <td>Android</td>
                <td>Phone &amp; Tablet</td>
                <td>Full calling, messaging, voicemail &amp; meetings on the go</td>
              </tr>
              <tr>
                <td>Web</td>
                <td>Any Modern Browser</td>
                <td>Quick access without installs — same Communicator experience</td>
              </tr>
            </tbody>
          </table>
        </div>


        <div className="about-section" style={{ transform: 'translateY(20px)' }}>
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent communications and CX solutions for growing businesses and mid-market organizations — empowering teams to work, connect, and serve customers from anywhere.
          </p>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default CommunicatorDatasheet;
