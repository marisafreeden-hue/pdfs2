import React from "react";
import "./GoEngageDatasheet.css";

const DOC_NAME = "Performance & Goal Management · Rippling User Guide";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>{DOC_NAME}</div>
    <div>© Broadvoice 2026 · Internal</div>
  </div>
);

const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}
  </h2>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Ordered: React.FC<{ items: React.ReactNode[]; start?: number }> = ({ items, start }) => (
  <ol
    start={start}
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.65,
      paddingLeft: 22,
      margin: "6px 0 10px",
      listStyleType: "decimal",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 4 }}>
        {it}
      </li>
    ))}
  </ol>
);

const Bullets: React.FC<{ items: React.ReactNode[] }> = ({ items }) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      paddingLeft: 20,
      margin: "6px 0 10px",
      listStyleType: "disc",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 4 }}>
        {it}
      </li>
    ))}
  </ul>
);

const Callout: React.FC<{ children: React.ReactNode; tone?: "info" | "warn" }> = ({
  children,
  tone = "info",
}) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: tone === "warn" ? "#8a4a00" : "#1A1A2E",
      background: tone === "warn" ? "#FFF6E5" : "#EEF7F8",
      borderLeft: `3px solid ${tone === "warn" ? "#D97706" : "#43B5BF"}`,
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const ImageSlot: React.FC<{ height?: number }> = ({ height = 150 }) => (
  <div style={{ width: "100%", height, background: "#FFFFFF", margin: "8px 0 12px" }} />
);

const StepCard: React.FC<{ num: string; title: string; children: React.ReactNode }> = ({
  num,
  title,
  children,
}) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      padding: "14px 18px 10px",
      marginBottom: 14,
      background: "#FFFFFF",
    }}
  >
    <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 4 }}>
      <span
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 10,
          fontWeight: 700,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "#43B5BF",
        }}
      >
        Step {num}
      </span>
    </div>
    <h2
      className="section-title"
      style={{ fontSize: 18, margin: "0 0 6px", lineHeight: 1.2, display: "block" }}
    >
      {title}
    </h2>
    {children}
  </div>
);

const PerformanceGoalGuide: React.FC = () => {
  const handleExportPDF = () => window.print();

  const toc = [
    { title: "Add a Goal in Rippling", desc: "Create a new goal and configure ownership, alignment and key results.", page: "02" },
    { title: "Configure Key Results & Measurement", desc: "Add key results, measurement types, dates and department tags.", page: "03" },
    { title: "Ownership, Scope & Visibility", desc: "Advanced scope, contributors and visibility settings.", page: "04" },
    { title: "Updating Goals & Key Results", desc: "Record progress, edit details and manage key results.", page: "05" },
    { title: "1:1s — SBI Feedback Model", desc: "How Broadvoice uses Situation · Behavior · Impact in 1:1s.", page: "06" },
    { title: "Working with 1:1s in Rippling", desc: "Access the landing page, create a 1:1 and use templates.", page: "07" },
    { title: "Templates, Action Items & Insights", desc: "Broadvoice templates and manager Insights view.", page: "08" },
  ];

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
        .rounded-table table { margin: 0 !important; }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 – Cover & TOC ===== */}
      <div className="page">
        <PageHeader eyebrow="Internal User Guide" />

        <div className="partner-hero" style={{ marginTop: 40, marginBottom: 10 }}>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "#43B5BF",
              marginBottom: 10,
            }}
          >
            Performance & Goal Management
          </div>
          <h1 className="hero-headline" style={{ fontSize: 34, lineHeight: 1.05, marginBottom: 6 }}>
            Goals & <em>1:1s</em> in Rippling
          </h1>
          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            A step-by-step guide for Broadvoice employees on creating goals, tracking key
            results and running effective 1:1s inside Rippling.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />

        <PageBody>
          <div style={{ height: 14 }} />
          <SectionTitle>Contents</SectionTitle>
          <Body>A quick map of the workflows covered in this guide.</Body>

          <div style={{ marginTop: 10 }}>
            {toc.map((item, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: 14,
                  padding: "10px 0",
                  borderBottom: "1px solid #E2E2EC",
                }}
              >
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 13,
                      fontWeight: 700,
                      color: "#1A1A2E",
                      lineHeight: 1.3,
                    }}
                  >
                    {item.title}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 11,
                      color: "#888899",
                      marginTop: 2,
                      lineHeight: 1.4,
                    }}
                  >
                    {item.desc}
                  </div>
                </div>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 11,
                    fontWeight: 700,
                    color: "#27698F",
                    flex: "0 0 auto",
                    letterSpacing: "0.08em",
                  }}
                >
                  p. {item.page}
                </span>
              </div>
            ))}
          </div>
        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – Add Goal (open + create) ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 1 · Add a Goal in Rippling" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>Add a Goal in Rippling</SectionTitle>
          <Body>
            To add a goal in Rippling, open <strong>Goals</strong> from the Apps section on
            your home screen, or navigate to <strong>Talent → Goals</strong>.
          </Body>
          <ImageSlot height={140} />

          <StepCard num="1" title="Create a new goal">
            <Body>
              In the top-right corner of the Goals page, select <strong>Create Goal</strong>.
              Choose the appropriate goal cycle for the applicable goal year, then click{" "}
              <strong>Create</strong>.
            </Body>
            <Callout tone="warn">
              <strong>Note:</strong> Goals must be created within the current goal year cycle.
              Do not create goals in previous year cycles.
            </Callout>
          </StepCard>

          <StepCard num="2" title="Complete the goal details">
            <Bullets
              items={[
                <>Enter a goal name in the <em>"What do you want to accomplish?"</em> field.</>,
                <>Add a description outlining what the goal will accomplish (optional).</>,
                <>
                  Enter the name of the goal owner if it is not assigned to you. Your name
                  appears by default — type another employee's name to reassign ownership.
                </>,
                <>
                  Select the <strong>Parent Goal</strong> drop-down to align the goal to a
                  company OKR, department goal, or team goal.
                </>,
                <>
                  Choose whether this goal will <strong>automatically update the parent goal</strong>.
                  When enabled, progress rolls up automatically; when disabled, the goal is
                  linked but progress must be updated separately.
                </>,
              ]}
            />
            <ImageSlot height={130} />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 3 – Key Results & measurement ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 3 · Key Results & Measurement" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>Configure Key Results & Measurement</SectionTitle>

          <StepCard num="3" title="Add a Key Result">
            <Body>
              Click the <strong>+ icon</strong> to add a Key Result, then complete the following
              fields:
            </Body>
            <Ordered
              items={[
                "Enter a clear, descriptive name for the Key Result.",
                "Add a description outlining what the result will accomplish (optional).",
                <>
                  Select the measurement type used to track progress:
                  <Bullets
                    items={["Complete / Incomplete", "Percentage", "Numeric total"]}
                  />
                </>,
              ]}
            />
            <ImageSlot height={130} />
          </StepCard>

          <StepCard num="4" title="Set values, dates and tags">
            <Body>
              If <strong>Percent</strong> or <strong>Numeric Total</strong> is selected as the
              measurement type, enter a <strong>starting value</strong>, a{" "}
              <strong>current value</strong>, and the <strong>target value</strong> you want to
              achieve.
            </Body>
            <Bullets
              items={[
                <>Select a <strong>start date</strong> and an <strong>end date</strong> for the goal.</>,
                <>
                  Choose the appropriate <strong>tag</strong> to associate the goal with the
                  relevant department. The tag should align with the department responsible for
                  or primarily contributing to the goal.
                </>,
              ]}
            />
            <ImageSlot height={110} />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 4 – Advanced ownership + visibility ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 5 · Ownership, Scope & Visibility" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>Ownership, Scope & Visibility</SectionTitle>
          <Body>
            Click the <strong>Advanced ownership and visibility settings</strong> drop-down to
            expand additional settings.
          </Body>

          <StepCard num="5" title="Choose the scope">
            <Body>Under <strong>Scope</strong>, select the goal type:</Body>
            <Bullets
              items={[
                <>
                  <strong>Group objective:</strong> A shared objective for a company,
                  department, or team.
                </>,
                <>
                  <strong>Individual objective:</strong> An objective assigned to a single
                  individual.
                </>,
              ]}
            />
            <Body>
              If you select a Group objective, add the goal <strong>contributors</strong>.
              Contributors can include individual employees, departments, or teams. Use the{" "}
              <strong>Preview people</strong> drop-down to review everyone who has visibility
              into the goal.
            </Body>
            <ImageSlot height={110} />
          </StepCard>

          <StepCard num="6" title="Set contributor permissions and visibility">
            <Body>
              Check the <em>"Contributors can update goal's progress"</em> box to allow
              contributors to make updates to the goal and its progress.
            </Body>
            <Body>Select the <strong>Visibility</strong> setting for the goal:</Body>
            <Bullets
              items={[
                <><strong>Public:</strong> Visible to the entire organization.</>,
                <>
                  <strong>Restricted:</strong> Visible only to individuals assigned to the goal.
                </>,
              ]}
            />
            <Callout>
              <strong>Note:</strong> For personal goals, be sure to include your manager so
              they have visibility into progress and updates.
            </Callout>
            <Body>
              Click <strong>Save</strong> to finish creating your goal.
            </Body>
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Updating Goals & Key Results ===== */}
      <div className="page">
        <PageHeader eyebrow="Updating Goals & Key Results" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>Updating Goals & Key Results</SectionTitle>

          <Callout>
            Goal progress should be updated in Rippling <strong>at least once per quarter</strong>.
            Updates can be made at any time as progress occurs.
          </Callout>

          <Body>
            In the Goals section, select <strong>My Goals</strong> to view your current goals.
            You can also filter by goal cycle to view current or past goals, as well as by
            department or goal status. From the list, select the goal you want to update.
          </Body>
          <ImageSlot height={110} />

          <SubHead>On the goal page you can:</SubHead>
          <Ordered
            items={[
              <>
                Use the <strong>checkmark</strong> to mark the goal as complete. Select the
                ellipsis menu to add a key result or link, create supporting goals, move the
                goal to a different cycle, archive, or delete the goal.{" "}
                <em>Archiving a goal automatically marks it 100% complete.</em>
              </>,
              <>
                For key results you own or contribute to, you'll have options to make changes
                and record progress.
              </>,
              <>
                Under <strong>Goal Details</strong>, select <strong>Edit</strong> to change the
                goal name, properties, target dates, scope, tags, and visibility at any time.
              </>,
              <>
                Each time a goal is updated, add <strong>comments</strong> documenting
                completed work, items in progress, and any roadblocks that may affect progress.
              </>,
            ]}
          />

          <SubHead>Working inside a key result</SubHead>
          <Body>
            Within the key result, select the <strong>checkmark</strong> to mark it as complete,
            the <strong>pencil icon</strong> to update the value, or the{" "}
            <strong>settings gear</strong> to adjust the measurements. Once you adjust the key
            result value, the progress bar updates automatically.
          </Body>
          <ImageSlot height={100} />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 – 1:1s Intro + SBI ===== */}
      <div className="page">
        <PageHeader eyebrow="1:1s · SBI Feedback Model" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>1:1s in Rippling</SectionTitle>
          <Body>
            With Rippling's 1:1s, you can easily track meetings with colleagues, managers, and
            direct reports — all in one place. Notes from each 1:1 are stored in a centralized
            location within your Rippling account, making it easy to reference past
            conversations and follow up on action items.
          </Body>

          <Callout>
            Managers should meet with each team member <strong>at least every other week</strong>{" "}
            to support ongoing feedback, alignment, and development. Using 1:1s in Rippling is
            encouraged as a helpful way to document conversations, track action items, and
            reference past discussions.
          </Callout>

          <SubHead>The SBI feedback model</SubHead>
          <Body>
            In Broadvoice 1:1s, feedback is guided by the <strong>SBI</strong> model —
            <strong> Situation, Behavior, Impact</strong>. SBI is a simple and effective
            framework for delivering feedback that is clear, objective, and focused on outcomes
            rather than assumptions or intent. It helps ensure feedback is specific and
            actionable, while reducing confusion or defensiveness.
          </Body>

          <Bullets
            items={[
              <>
                <strong>Situation —</strong> Describe the specific context so both people are
                aligned on when and where it occurred.{" "}
                <em>Example: During last week's customer onboarding call.</em>
              </>,
              <>
                <strong>Behavior —</strong> Focus on what was observed, using clear facts rather
                than interpretation.{" "}
                <em>
                  Example: You clearly outlined the next steps and confirmed understanding
                  before ending the call.
                </em>
              </>,
              <>
                <strong>Impact —</strong> Explain the result of the behavior and why it matters.{" "}
                <em>
                  Example: This helped the customer feel confident and reduced follow-up
                  questions.
                </em>
              </>,
            ]}
          />

          <Body>
            When using SBI in a 1:1, focus on providing <strong>timely, balanced feedback</strong>.
            SBI can be used for both positive reinforcement and development conversations. It
            works best when paired with open dialogue, allowing space for reflection, questions,
            and next steps.
          </Body>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 – Working with 1:1s ===== */}
      <div className="page">
        <PageHeader eyebrow="Working with 1:1s in Rippling" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>Working with 1:1s in Rippling</SectionTitle>

          <Body>
            In Rippling, open <strong>1:1s</strong> from the Apps section on your home screen,
            or navigate to <strong>Talent → 1:1s</strong>.
          </Body>
          <ImageSlot height={110} />

          <SubHead>On the landing page you can:</SubHead>
          <Ordered
            items={[
              "View your existing 1:1s.",
              "Create a new 1:1.",
              "View action items from previous 1:1s and check off completed tasks.",
            ]}
          />
          <Body>
            To access a 1:1, click any line item.{" "}
            <em>
              A 1:1 can be opened and updated at any time, allowing you to add notes or document
              discussion topics ahead of a meeting.
            </em>
          </Body>

          <StepCard num="Create" title="Create a new 1:1">
            <Body>
              You can create a 1:1 with any other Broadvoice employee, including your manager,
              direct reports, teammates, or anyone you're collaborating with.
            </Body>
            <Ordered
              items={[
                <>Click <strong>Create 1:1</strong> to set one up.</>,
                <>
                  From the drop-down menu, select the person you would like to meet with, then
                  choose <strong>Get Started</strong>.
                </>,
              ]}
            />
            <ImageSlot height={110} />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 8 – Templates, action items, Insights ===== */}
      <div className="page">
        <PageHeader eyebrow="Templates, Action Items & Insights" />
        <PageBody>
          <div style={{ height: 24 }} />
          <SectionTitle>Inside a 1:1</SectionTitle>

          <SubHead>Inside the 1:1 page you can:</SubHead>
          <Ordered
            items={[
              "Use the taskbar to format text, add links, upload photos, and more.",
              "Click the menu icon to access past meeting notes.",
              "Select New Meeting Notes to add a new section for your next meeting.",
              "Click the calendar icon to add the meeting date.",
              "Insert a template.",
            ]}
          />
          <ImageSlot height={110} />

          <SubHead>Templates</SubHead>
          <Body>
            Templates help guide the conversation, keep discussions consistent, and give both
            participants space to add discussion topics.
          </Body>
          <Bullets
            items={[
              <>
                The <strong>Broadvoice Manager 1:1 Template</strong> should be used for all
                manager-to-team member conversations. It's designed to support goal discussions,
                performance check-ins, and ongoing development.
              </>,
              <>
                The <strong>Broadvoice Collaboration Template</strong> can be used when
                connecting with peers or others across the organization and is ideal for
                alignment, planning, and cross-functional work.
              </>,
            ]}
          />
          <Callout>
            Both templates include an <strong>Action Items</strong> section. Use this space to
            capture follow-up work, assign an owner, and set a due date so next steps are clear
            and tracked.
          </Callout>

          <SubHead>Insights</SubHead>
          <Body>
            In a 1:1 between a manager and a team member, both participants will see the{" "}
            <strong>Insights</strong> button. Within Insights, managers can view a team member's
            goals and past reviews. Team members can also view their own information for shared
            visibility to support a more productive conversation.
          </Body>
          <ImageSlot height={110} />
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default PerformanceGoalGuide;
