import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>GoContact · Homepage Navigation Guide</div>
    <div>© Broadvoice 2026</div>
  </div>
);

const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}
  </h2>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const ImageSlot: React.FC<{ height?: number; label?: string }> = ({ height = 150, label }) => (
  <div
    style={{
      width: "100%",
      height,
      background: "#F7F7FB",
      border: "1px dashed #D4D4DE",
      borderRadius: 6,
      margin: "8px 0 12px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10.5,
      color: "#9999A8",
      fontStyle: "italic",
      padding: "0 18px",
      textAlign: "center",
    }}
  >
    {label}
  </div>
);

const TOC_ITEMS = [
  { title: "User Information", desc: "Profile details, password, language, and avatar.", page: "02" },
  { title: "Messages & Performance", desc: "Internal messages, broadcasts, and real-time metrics.", page: "03" },
  { title: "News & Announcements", desc: "Latest GoContact updates and release notes.", page: "03" },
  { title: "Vertical Menu", desc: "Module navigation: Analytics, Actions, Channels, and more.", page: "04" },
  { title: "Top Menu Bar", desc: "Channel logins and quick-access shift controls.", page: "05" },
  { title: "Breaks", desc: "Requesting breaks and tracking break status.", page: "06" },
  { title: "Break Approval", desc: "Supervisor review and approval workflow.", page: "07" },
  { title: "Create Tickets and Emails", desc: "Create tickets or send emails from the top bar.", page: "07" },
  { title: "Inbox", desc: "Broadcast messages and online user chat.", page: "08" },
  { title: "Logging Out", desc: "End your shift and exit the platform.", page: "08" },
];

const GoContactHomepageGuide: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 – Cover, Introduction & TOC ===== */}
      <div className="page">
        <PageHeader eyebrow="Navigation Guide" />

        <div className="partner-hero" style={{ marginTop: 30, marginBottom: 10 }}>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "#43B5BF",
              marginBottom: 10,
            }}
          >
            GoContact Homepage
          </div>
          <h1
            className="hero-headline"
            style={{ fontSize: 38, lineHeight: 1.05, marginBottom: 6 }}
          >
            Homepage <em>Navigation</em> Guide
          </h1>
          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Get oriented with the GoContact Homepage and the day-to-day controls available to you.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />

        <PageBody>
          <SectionTitle>Introduction</SectionTitle>
          <Body>
            In this guide, you will learn how to navigate the Homepage, previously known as the
            Profile page. The Homepage provides access to important platform information,
            including the number of people in your group, your profile details, and real-time
            call statistics. You will also learn how to update your password and personal
            information, request breaks, send messages, and log out of the platform.
          </Body>

          <div style={{ height: 14 }} />

          <SectionTitle>Contents</SectionTitle>
          <Body>A quick map of the sections covered in this guide.</Body>

          <div style={{ marginTop: 10 }}>
            {TOC_ITEMS.map((item, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: 14,
                  padding: "8px 0",
                  borderBottom: "1px solid #E2E2EC",
                }}
              >
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 12,
                      fontWeight: 700,
                      color: "#1A1A2E",
                      lineHeight: 1.3,
                    }}
                  >
                    {item.title}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 10.5,
                      color: "#888899",
                      marginTop: 2,
                      lineHeight: 1.4,
                    }}
                  >
                    {item.desc}
                  </div>
                </div>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 11,
                    fontWeight: 700,
                    color: "#27698F",
                    flex: "0 0 auto",
                    letterSpacing: "0.08em",
                  }}
                >
                  p. {item.page}
                </span>
              </div>
            ))}
          </div>
        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – User Information ===== */}
      <div className="page">
        <PageHeader eyebrow="User Information" />
        <PageBody>
          <SectionTitle>User Information</SectionTitle>
          <Body>
            In the center of the page, you can view key user details, including the user's
            name and surname, their username used to access GoContact, and the email
            associated with the account used for password delivery. You will also see the
            user's phone number, a link to change their password, and their selected language
            preference.
          </Body>
          <ImageSlot
            height={180}
            label="User profile information card showing name, username, email, phone number, change password link, and language setting."
          />
          <Body>
            By clicking on the center of the photo, you can customize your profile picture
            using an image from the GoContact image catalog.
          </Body>
          <ImageSlot
            height={170}
            label="Avatar gallery modal showing a selection of profile icons and a preview of a selected avatar."
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 3 – Messages & Performance + News ===== */}
      <div className="page">
        <PageHeader eyebrow="Messages, Performance & News" />
        <PageBody>
          <SectionTitle>Messages & Performance</SectionTitle>
          <Body>
            Under user information, you can view any internal messages sent to you, either
            by broadcast (marked with the megaphone) or internal chat.
          </Body>
          <ImageSlot
            height={140}
            label="Messages interface showing messages from Ana, Afonso, and a broadcast update about Carnival break."
          />
          <Body>
            On the right side of the screen, you can view performance metrics, including the
            number of users in your group, which reflects how many users are included in the
            same work group as you. You will also see a real-time counter of inbound calls
            and outbound calls. Both inbound and outbound call statistics are automatically
            reset at midnight.
          </Body>
          <ImageSlot
            height={120}
            label="Performance metrics showing 12 inbound calls, 7 outbound calls, and 9 users in group."
          />

          <div style={{ height: 10 }} />

          <SectionTitle>News & Announcements</SectionTitle>
          <Body>
            Under the Performance section, you will find the News and Announcements area,
            where you can stay up to date with the latest GoContact news, platform updates,
            and newly available capabilities. Select <strong>Learn More</strong> to be
            redirected to the Broadvoice website for additional details and resources.
          </Body>
          <Body>
            Please note that the content displayed within the News and Announcements section
            may vary based on your role and permissions within the platform.
          </Body>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 4 – Vertical Menu ===== */}
      <div className="page">
        <PageHeader eyebrow="Vertical Menu" />
        <PageBody>
          <SectionTitle>Vertical Menu</SectionTitle>
          <Body>
            On the left is a vertical menu of the GoContact modules to which your profile
            has access. On the vertical menu, you will find the following expandable icons.
            Click any icon to expand the menu and access the available options within that
            section:
          </Body>
          <ul
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: "#555567",
              lineHeight: 1.65,
              paddingLeft: 22,
              margin: "6px 0 10px",
            }}
          >
            <li><strong>Analytics</strong> — Access tools to measure and evaluate performance, including dashboards, wallboards, and built-in reporting features.</li>
            <li><strong>Actions</strong> — Manage day-to-day operations with tools such as the CRM for contact data, the Callback Manager, Dialer Control for live campaign adjustments, and Agent Management.</li>
            <li><strong>Channels</strong> — Create, configure, and manage all communication channels to align with your operational requirements.</li>
            <li><strong>Optimize</strong> — Enhance platform functionality by building custom agent scripts, configuring contact template fields, uploading external databases, and using the calendar feature.</li>
            <li><strong>Quality</strong> — Create and manage eLearning content and quality audits, and access your assigned trainings and evaluations.</li>
            <li><strong>Admin</strong> — Manage users and groups, customize user profiles, and configure integrations such as social network connections.</li>
          </ul>
          <ImageSlot
            height={140}
            label="Vertical menu options showing Analytics, Actions, Channels, Optimize, Quality, and Admin modules."
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Top Menu Bar ===== */}
      <div className="page">
        <PageHeader eyebrow="Top Menu Bar" />
        <PageBody>
          <SectionTitle>Top Menu Bar</SectionTitle>
          <Body>
            The top bar provides access to your communication channels. On the left side,
            select <strong>Voice</strong>, <strong>Tickets</strong>, or <strong>Webchat</strong>{" "}
            to log in to these communication channels.
          </Body>
          <ImageSlot height={70} label="Top bar showing Voice, Tickets, and Webchat channel logins." />
          <Body>
            The right side of the top bar provides quick access to key features throughout
            your shift:
          </Body>
          <ul
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: "#555567",
              lineHeight: 1.65,
              paddingLeft: 22,
              margin: "6px 0 10px",
            }}
          >
            <li><strong>Coffee Cup Icon:</strong> Request or start a break.</li>
            <li><strong>Compose Icon:</strong> Create a new ticket or email.</li>
            <li><strong>Message Icon:</strong> View notifications, initiate and view broadcast messages, and chat conversations.</li>
            <li><strong>Profile Icon:</strong> Access account options, including logging out of the platform.</li>
          </ul>
          <Body>
            If you have Supervisor permissions, the <strong>Review</strong> icon allows you
            to review and authorize employee break requests.
          </Body>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 – Breaks ===== */}
      <div className="page">
        <PageHeader eyebrow="Breaks" />
        <PageBody>
          <SectionTitle>Breaks</SectionTitle>
          <Body>
            The coffee cup icon allows you to take a break during your shift. To request a
            break, click the coffee cup icon to open the list of available break options.
          </Body>
          <Body>
            In the Breaks pop-up window, you may see additional icons next to certain break
            types. A lock icon indicates that the break requires approval, while a chat
            bubble icon indicates that a comment is required when selecting that break.
            Break options that appear shaded or grayed out are not currently available.
          </Body>
          <Body>
            Each break option also displays a ratio of the current number of users in your
            group on break to the maximum number allowed at the same time. For example,
            3/5 means that 3 group users are currently on break, and up to 5 group users
            may be on that break simultaneously.
          </Body>
          <ImageSlot
            height={130}
            label="Take a break pop-up window showing a list of break options with their respective ratios and icons."
          />
          <Body>
            After submitting your break request, a notification will appear on the home
            page indicating that your request is pending approval. Once your supervisor
            approves the request, you will receive an additional notification confirming
            the approval.
          </Body>
          <Body>
            If you are currently handling an active voice interaction, your break will be
            queued automatically and will begin as soon as the interaction is completed.
          </Body>
          <Body>
            Once your break begins, a notification will appear in the top bar showing the
            active break and the remaining time available. Your status will also update
            from Online to Break, and your communication channels on the left side of the
            screen will reflect your break status. To end your break early, click the
            break notification and select <strong>End Break</strong>.
          </Body>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 – Break Approval + Create Tickets ===== */}
      <div className="page">
        <PageHeader eyebrow="Break Approval & Create" />
        <PageBody>
          <SectionTitle>Break Approval</SectionTitle>
          <Body>
            Supervisors will see a red badge notification on the <strong>Review</strong>{" "}
            icon when there are pending break requests that require attention. Click the
            Review icon to view all pending requests and approve or deny them as needed.
          </Body>
          <Body>
            From the Review pop-up window, you can select the <strong>Breaks Manager</strong>{" "}
            button to access additional break management options.
          </Body>
          <ImageSlot
            height={130}
            label="Review break requests pop-up window showing pending requests from Rose Jones and Nicky Jordan."
          />

          <div style={{ height: 8 }} />

          <SectionTitle>Create Tickets and Emails</SectionTitle>
          <Body>
            Click the <strong>Create</strong> icon to open the creation menu, where you
            can choose to create either a new ticket or a new email. You can then create
            a ticket manually or send an email by entering the customer's email and phone
            number, selecting the appropriate queue, adding a subject, and applying a
            predefined response template.
          </Body>
          <ImageSlot
            height={120}
            label="Create menu showing options for Create ticket and Send email."
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 8 – Inbox + Logging Out ===== */}
      <div className="page">
        <PageHeader eyebrow="Inbox & Logging Out" />
        <PageBody>
          <SectionTitle>Inbox</SectionTitle>
          <Body>
            Click the <strong>Inbox</strong> icon to view broadcast messages and chat
            conversations. The blue badge notification will appear when you have an unread
            message. Please note that chat access may vary based on your assigned role and
            permissions.
          </Body>
          <Body>
            To start a new chat or reply to an existing conversation, select{" "}
            <strong>Online Users</strong> and search for the user by name. Only users who
            are currently online and available will appear in the list.
          </Body>
          <ImageSlot
            height={140}
            label="Inbox interface showing online users and a broadcast message about new training materials."
          />

          <div style={{ height: 8 }} />

          <SectionTitle>Logging Out</SectionTitle>
          <Body>
            To log out of the platform at the end of your shift, click your profile icon
            in the upper-right corner of the screen and select <strong>Logout</strong>.
          </Body>
          <Body>
            A confirmation window will appear asking you to verify that you want to log out
            before the action is completed.
          </Body>
          <ImageSlot
            height={120}
            label="Account logout confirmation window with Cancel and Logout buttons."
          />
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default GoContactHomepageGuide;
