import React from "react";
import "./GoEngageDatasheet.css";

const PartnerSuccessPlan: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        {/* Logo */}
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="partner-hero">
          <h1 className="hero-headline">
            Partner Success <em>Plan</em>
          </h1>
          <h2 className="partner-subtitle">
            Let's Grow <em>Together</em>
          </h2>
          <p className="partner-intro">
            Thank you for joining the Broadvoice Partner Program! We're excited to share our Co‑Success Plan with you — a framework built to give you complete clarity, visibility, and support as we grow together. Our goal is simple: a partnership where both sides win, every step of the way.
          </p>
        </div>

        <hr />

        <div className="partner-pillars">
          <div className="partner-pillar">
            <div className="partner-pillar-title">Stay aligned on the things that matter most</div>
            <div className="partner-pillar-body">
              We'll jointly define objectives, priorities, pipeline focus, and customer outcomes — same page, same playbook, same finish line.
            </div>
          </div>

          <div className="partner-pillar">
            <div className="partner-pillar-title">Establish clear ownership and accountability</div>
            <div className="partner-pillar-body">
              You'll always know who's doing what, what's coming next, and how we're supporting you. No gray areas, no guesswork.
            </div>
          </div>

          <div className="partner-pillar">
            <div className="partner-pillar-title">Accelerate results through structured collaboration</div>
            <div className="partner-pillar-body">
              Pipeline development, enablement, marketing, escalations — one central place to track progress and knock down roadblocks.
            </div>
          </div>

          <div className="partner-pillar">
            <div className="partner-pillar-title">Make your success measurable and visible</div>
            <div className="partner-pillar-body">
              Our dashboard and scorecard let us celebrate wins, spot gaps early, and invest where it matters most for you.
            </div>
          </div>

          <div className="partner-pillar">
            <div className="partner-pillar-title">Strengthen our long‑term partnership</div>
            <div className="partner-pillar-body">
              This isn't just a document — it's a commitment. We're invested in your growth, your revenue, and your customer experience.
            </div>
          </div>
        </div>

        <div className="partner-closing">
          <p>
            If there's anything you'd like to customize, let's shape it together. This plan is built <em>with</em> you and <em>for</em> you — and we can't wait to see what we accomplish side by side.
          </p>
          <p className="partner-closing-cta">Let's go make some noise.</p>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/wave-graphic.png" alt="" />
        </div>
      </div>
    </div>
  );
};

export default PartnerSuccessPlan;
