import React from "react";
import "./GoEngageDatasheet.css";

const GoEngageDatasheet: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        {/* Logo */}
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="hero">
          <div>
            <h1 className="hero-headline">
              Engage <em>Voice</em>
            </h1>
            <p className="hero-body">
              Your IVR routes calls. Engage resolves them.
            </p>
            <p className="hero-desc">
              Engage Voice automatically resolves the routine inbound calls that cost your contact center $8–$12 each — so your agents only pick up when it actually matters.
            </p>
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <div className="stat-label-top">Estimated Payback</div>
              <div className="stat-value">
                <span className="stat-value-sans">&lt;2 </span><em>mo.</em>
              </div>
              <div className="stat-desc">
                On a 50-seat contact center<br />at 70% AI containment
              </div>
            </div>
          </div>
        </div>

        <hr />

        {/* The Problem */}
        <h2 className="section-title">The <em>Problem</em></h2>
        <p className="section-body">
          Contact center leaders are caught in a cycle that headcount alone can't fix. Agent attrition
          drains budgets before productivity returns. Legacy IVRs route calls without resolving them.
          And every live interaction costs money that scales linearly with volume — until now.
        </p>

        <div className="stats-row">
          <div className="stat-item">
            <div className="num">52%</div>
            <div className="lbl">
              <strong>Avg. annual agent attrition</strong>
              You spend nearly as much replacing your team as running it
            </div>
          </div>
          <div className="stat-item">
            <div className="num">$11</div>
            <div className="lbl">
              <strong>Saved per AI-resolved call</strong>
              vs. a live agent interaction averaging $8–$12
            </div>
          </div>
          <div className="stat-item">
            <div className="num">91%</div>
            <div className="lbl">
              <strong>CX leaders pressure</strong>
              to deploy AI immediately or risk falling behind
            </div>
          </div>
        </div>

        <hr className="section-divider" />

        {/* What Engage Voice Does */}
        <h2 className="section-title" style={{ marginTop: '12px' }}>What Engage Voice <em>Does</em></h2>
        <p className="section-body">
          An AI-powered inbound voice assistant built natively into GoContact — not bolted on. It handles
          the calls your agents shouldn't have to take, and makes every escalation smarter.
        </p>

        <div className="feature-grid">
          <div className="feature-item">
            <div className="feature-title">Resolves calls without an agent</div>
            <div className="feature-body">
              Handles routine, high-volume inbound requests 24/7 — appointment scheduling, account inquiries, claims status — automatically and accurately.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">No-code call flow and configuration</div>
            <div className="feature-body">
              Admins build and update call flows and knowledge bases directly in GoContact using no-code tools with no developer resources or IT support tickets required.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Natural, real-time conversation</div>
            <div className="feature-body">
              Powered by OpenAI Realtime technology for low-latency, human-like voice — not the stuttering phone trees customers dread.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Full-context agent handoffs</div>
            <div className="feature-body">
              When a call needs a human, it transfers with a complete summary. Agents skip the re-explanation and go straight to solving.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Native to GoContact</div>
            <div className="feature-body">
              No integration overhead. Faster deployment, unified reporting, and one platform for your entire contact center operation.
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Built-in reporting and analytics</div>
            <div className="feature-body">
              GoContact tracks automation rates, common inquiry types, and escalation triggers so you can fine-tune call flows and make smarter staffing decisions over time.
            </div>
          </div>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        {/* Logo repeated for page 2 */}
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Proven Results */}
        <h2 className="section-title">Proven Results Across <em>Industries</em></h2>

        <div className="outcomes-container">
          <div className="outcomes-blur" />
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Industry</th>
                <th>Top Use Case</th>
                <th>Outcome</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Healthcare</td>
                <td>Appointment scheduling &amp; Rx refills</td>
                <td><span className="outcome-num">34%</span> fewer missed appointments</td>
              </tr>
              <tr>
                <td>Financial Services</td>
                <td>Loan status &amp; account inquiries</td>
                <td><span className="outcome-num">11 hrs</span>/week returned per banker</td>
              </tr>
              <tr>
                <td>Insurance</td>
                <td>First notice of loss &amp; claims status</td>
                <td><span className="outcome-num">95%</span> of routine claims auto-processed</td>
              </tr>
              <tr>
                <td>All Verticals</td>
                <td>FAQ containment &amp; after-hours coverage</td>
                <td><span className="outcome-num">$11</span> saved per AI-handled call vs. live agent</td>
              </tr>
            </tbody>
          </table>
        </div>

        <p className="table-footnote">
          Statistics referenced from recent analyst studies by McKinsey &amp; Company, KPMG, PwC, Deloitte, and Gartner.
        </p>

        <hr />

        {/* Why Now */}
        <h2 className="section-title">Why <em>Now</em></h2>
        <p className="section-body">
          77% of organizations are already investing in voice AI. Gartner projects 40% of enterprise
          applications will embed AI agents by end of 2026. The window to lead is open — but not indefinitely.
          Companies that move now are already deflecting calls, cutting costs, and pulling ahead on customer experience.
          Those that wait are not standing still. They are falling behind.
        </p>

        <p className="closing-line">
          Your customers' expectations aren't going down.<br />
          Your agent costs aren't going down.<br />
          Engage Voice is how you close the gap.
        </p>

        {/* About */}
        <div className="about-section">
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent CX solutions for midmarket organizations—empowering business teams to design modern, frictionless customer experiences with AI that's practical, easy to use, and purpose-built for how they work.
          </p>
          <p className="about-addon">
            Engage Voice is available as an add-on to GoContact.
          </p>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default GoEngageDatasheet;
