import React, { useState, useCallback, useEffect, useRef } from "react";
import { SheetElement } from "@/types/datasheet";
import Toolbar from "@/components/datasheet/Toolbar";
import SheetCanvas from "@/components/datasheet/SheetCanvas";
import AssetLibrary from "@/components/datasheet/AssetLibrary";
import { saveElements, loadElements } from "@/lib/datasheet-db";
import { toast } from "sonner";

let nextId = 1;
const genId = () => `el-${nextId++}`;
const SHEET_ID = "default";

const MAX_HISTORY = 50;

const Index: React.FC = () => {
  const [elements, setElements] = useState<SheetElement[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [clipboard, setClipboard] = useState<SheetElement | null>(null);
  const saveTimeout = useRef<ReturnType<typeof setTimeout>>();
  const historyRef = useRef<SheetElement[][]>([]);
  const historyIndexRef = useRef(-1);
  const isUndoRedoRef = useRef(false);

  const selectedElement = elements.find((e) => e.id === selectedId);

  // Push state to history
  const pushHistory = useCallback((state: SheetElement[]) => {
    if (isUndoRedoRef.current) return;
    const history = historyRef.current;
    const idx = historyIndexRef.current;
    // Truncate any redo states
    historyRef.current = history.slice(0, idx + 1);
    historyRef.current.push(JSON.parse(JSON.stringify(state)));
    if (historyRef.current.length > MAX_HISTORY) {
      historyRef.current.shift();
    }
    historyIndexRef.current = historyRef.current.length - 1;
  }, []);

  const undo = useCallback(() => {
    if (historyIndexRef.current <= 0) return;
    historyIndexRef.current -= 1;
    const prev = historyRef.current[historyIndexRef.current];
    isUndoRedoRef.current = true;
    setElements(prev);
    scheduleAutoSave(prev);
    isUndoRedoRef.current = false;
  }, []);

  const redo = useCallback(() => {
    if (historyIndexRef.current >= historyRef.current.length - 1) return;
    historyIndexRef.current += 1;
    const next = historyRef.current[historyIndexRef.current];
    isUndoRedoRef.current = true;
    setElements(next);
    scheduleAutoSave(next);
    isUndoRedoRef.current = false;
  }, []);

  // Keyboard shortcuts: Delete, Backspace, Ctrl+C, Ctrl+V, Ctrl+Z, Ctrl+Shift+Z
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.isContentEditable || target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;

      // Undo
      if (e.key === "z" && (e.ctrlKey || e.metaKey) && !e.shiftKey) {
        e.preventDefault();
        undo();
        return;
      }

      // Redo
      if ((e.key === "z" && (e.ctrlKey || e.metaKey) && e.shiftKey) ||
          (e.key === "y" && (e.ctrlKey || e.metaKey))) {
        e.preventDefault();
        redo();
        return;
      }

      if ((e.key === "Delete" || e.key === "Backspace") && selectedId) {
        e.preventDefault();
        setElements((prev) => {
          const next = prev.filter((el) => el.id !== selectedId);
          pushHistory(next);
          scheduleAutoSave(next);
          return next;
        });
        setSelectedId(null);
      }

      if (e.key === "c" && (e.ctrlKey || e.metaKey) && selectedId) {
        const el = elements.find((el) => el.id === selectedId);
        if (el) setClipboard({ ...el });
      }

      if (e.key === "v" && (e.ctrlKey || e.metaKey) && clipboard) {
        const newEl: SheetElement = {
          ...clipboard,
          id: genId(),
          x: clipboard.x + 20,
          y: clipboard.y + 20,
        };
        setElements((prev) => {
          const next = [...prev, newEl];
          pushHistory(next);
          scheduleAutoSave(next);
          return next;
        });
        setSelectedId(newEl.id);
        setClipboard({ ...clipboard });
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedId, elements, clipboard, undo, redo, pushHistory]);

  // Load from DB on mount
  useEffect(() => {
    loadElements(SHEET_ID).then((loaded) => {
      if (loaded.length > 0) {
        setElements(loaded);
        const maxNum = loaded.reduce((max, el) => {
          const num = parseInt(el.id.replace("el-", ""), 10);
          return isNaN(num) ? max : Math.max(max, num);
        }, 0);
        nextId = maxNum + 1;
        pushHistory(loaded);
      } else {
        // Add default background
        const defaultBg: SheetElement = {
          id: genId(),
          type: "image",
          x: 0,
          y: 0,
          width: 816,
          height: 1056,
          content: "/assets/teal-blur-bg.svg",
        };
        const initial = [defaultBg];
        setElements(initial);
        pushHistory(initial);
        scheduleAutoSave(initial);
      }
    });
  }, []);

  // Auto-save with debounce
  const scheduleAutoSave = useCallback((newElements: SheetElement[]) => {
    if (saveTimeout.current) clearTimeout(saveTimeout.current);
    saveTimeout.current = setTimeout(() => {
      saveElements(SHEET_ID, newElements);
    }, 1500);
  }, []);

  const setElementsAndSave = useCallback(
    (updater: (prev: SheetElement[]) => SheetElement[]) => {
      setElements((prev) => {
        const next = updater(prev);
        pushHistory(next);
        scheduleAutoSave(next);
        return next;
      });
    },
    [scheduleAutoSave, pushHistory]
  );

  const addElement = useCallback(
    (el: SheetElement) => {
      setElementsAndSave((prev) => [...prev, el]);
      setSelectedId(el.id);
    },
    [setElementsAndSave]
  );

  const updateElement = useCallback(
    (id: string, updates: Partial<SheetElement>) => {
      setElementsAndSave((prev) =>
        prev.map((el) => (el.id === id ? { ...el, ...updates } : el))
      );
    },
    [setElementsAndSave]
  );

  const deleteSelected = useCallback(() => {
    if (!selectedId) return;
    setElementsAndSave((prev) => prev.filter((el) => el.id !== selectedId));
    setSelectedId(null);
  }, [selectedId, setElementsAndSave]);

  const handleAddText = useCallback(() => {
    addElement({
      id: genId(),
      type: "text",
      x: 60,
      y: 60,
      content: "Type here...",
      fontSize: 16,
      fontWeight: "normal",
    });
  }, [addElement]);

  const handleAddTextAt = useCallback(
    (x: number, y: number) => {
      addElement({
        id: genId(),
        type: "text",
        x,
        y,
        content: "Type here...",
        fontSize: 16,
        fontWeight: "normal",
      });
    },
    [addElement]
  );

  const handleAddRect = useCallback(() => {
    addElement({
      id: genId(),
      type: "rect",
      x: 60,
      y: 60,
      width: 200,
      height: 100,
    });
  }, [addElement]);

  const handleAddLine = useCallback(() => {
    addElement({
      id: genId(),
      type: "line",
      x: 60,
      y: 120,
      width: 300,
    });
  }, [addElement]);

  const handleAddImage = useCallback(() => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        addElement({
          id: genId(),
          type: "image",
          x: 60,
          y: 60,
          width: 200,
          height: 150,
          content: ev.target?.result as string,
        });
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }, [addElement]);

  const handleDropAsset = useCallback(
    (assetUrl: string, x: number, y: number) => {
      addElement({
        id: genId(),
        type: "image",
        x: x - 100,
        y: y - 75,
        width: 200,
        height: 150,
        content: assetUrl,
      });
    },
    [addElement]
  );

  const handleToggleBold = useCallback(() => {
    if (!selectedElement || selectedElement.type !== "text") return;
    updateElement(selectedElement.id, {
      fontWeight: selectedElement.fontWeight === "bold" ? "normal" : "bold",
    });
  }, [selectedElement, updateElement]);

  const handleToggleItalic = useCallback(() => {
    if (!selectedElement || selectedElement.type !== "text") return;
    updateElement(selectedElement.id, {
      fontStyle: selectedElement.fontStyle === "italic" ? "normal" : "italic",
    });
  }, [selectedElement, updateElement]);

  const handleDragAssetClick = useCallback(
    (asset: { file_url: string }) => {
      addElement({
        id: genId(),
        type: "image",
        x: 60,
        y: 60,
        width: 200,
        height: 150,
        content: asset.file_url,
      });
    },
    [addElement]
  );

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden">
      <Toolbar
        onAddText={handleAddText}
        onAddRect={handleAddRect}
        onAddLine={handleAddLine}
        onAddImage={handleAddImage}
        onDelete={deleteSelected}
        onToggleBold={handleToggleBold}
        onToggleItalic={handleToggleItalic}
        hasSelection={!!selectedId}
      />
      <div className="flex flex-1 overflow-hidden">
        <AssetLibrary onDragAsset={handleDragAssetClick} />
        <SheetCanvas
          elements={elements}
          selectedId={selectedId}
          onSelectElement={setSelectedId}
          onUpdateElement={updateElement}
          onAddTextElement={handleAddTextAt}
          onDropAsset={handleDropAsset}
        />
      </div>
    </div>
  );
};

export default Index;
