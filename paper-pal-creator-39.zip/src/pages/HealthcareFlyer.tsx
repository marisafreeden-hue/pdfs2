import React from "react";
import VerticalFlyer, { buildSolutions } from "./VerticalFlyer";
import hero from "@/assets/hero-healthcare.jpg.asset.json";

const HealthcareFlyer: React.FC = () => (
  <VerticalFlyer
    eyebrow="Broadvoice for Healthcare"
    headlineLine1="Every Patient"
    headlineAccent="Interaction Matters"
    heroImage={hero.url}
    pullQuote="Help patients get answers faster while reducing the communications burden on care teams."
    intro="Broadvoice helps healthcare organizations improve patient responsiveness, reduce communications complexity, and support clinical, administrative, and operational teams with unified communications, contact center, text messaging, agentic AI, and deep analytics."
    stats={[
      { num: "99.999%", label: <><strong>Platform uptime SLA</strong>so scheduling, triage, and patient-facing lines stay live around the clock.</> as any },
      { num: "~95%", label: <><strong>Cost reduction</strong>achievable when consolidating legacy PBX, paging, and messaging into a single platform.</> as any },
      { num: "34%", label: <><strong>Fewer missed appointments</strong>when AI-driven reminders and confirmations replace manual outreach by front-desk staff.</> as any },
    ]}
    sectionTitle="Built for the"
    sectionTitleEm="complexity of modern care delivery"
    sectionBody="Healthcare leaders manage layered operations — clinics, specialty practices, call centers, billing, and on-call providers — all fielding inbound calls from patients who need to reach the right person quickly. Legacy phone systems weren't built for this."
    challenges={[
      { n: "01", title: "Patient access bottlenecks", body: "Long hold times and dropped calls during scheduling, refills, and referral requests push patients toward competitors or the ER." },
      { n: "02", title: "Multi-site care coordination", body: "Routing across primary care, specialty clinics, imaging, and labs without a dedicated operator at every location." },
      { n: "03", title: "After-hours & triage coverage", body: "Symptom calls, prescription needs, and care follow-ups don't stop at 5pm. Unanswered calls become clinical risk." },
      { n: "04", title: "Administrative overload", body: "Front-desk teams burn hours on confirmations, reminders, and routine status questions instead of supporting in-clinic patient flow." },
      { n: "05", title: "Distributed clinical staff", body: "Providers, nurses, and care managers split time across exam rooms, home visits, and remote work — communication must follow them." },
      { n: "06", title: "Compliance & continuity", body: "Patient data, recordings, and call routing must respect HIPAA, downtime tolerance, and audit requirements at every layer." },
    ]}
    page2Title="A unified platform for"
    page2TitleEm="every care-team workflow"
    page2Body="Four integrated solutions — phone system, contact center, agentic AI, and analytics — on a single platform, from a single provider."
    solutions={buildSolutions(
      {
        ucaas: "Enterprise-grade communications connecting clinics, providers, billing, and remote staff on any device.",
        ccaas: "Patient-facing contact center with smart routing, queue visibility, and full call context for service teams.",
        ai: "Agentic AI voice that handles routine inbound conversations 24/7 — scheduling, refills, directions, FAQs.",
        insights: "AI-enhanced visibility into queue activity, missed-call trends, and service performance across every location.",
      },
      {
        ucaas: [["Multi-site routing", "clinics, call center & on-call providers"], ["Mobile app", "providers respond without sharing personal numbers"], ["Bubble texting", "appointment & refill reminders without manual outreach"]],
        ccaas: [["Patient queues", "consistent routing across schedule, billing & referrals"], ["Screen pop", "EHR context surfaced before the agent answers"], ["Recording & QA", "HIPAA-aware retention and supervisor tools"]],
        ai: [["24/7 answering", "appointment booking, location & hours"], ["Bilingual", "English & Spanish out of the box"], ["Graceful escalation", "clinical calls routed to a live person"]],
        insights: [["Queue pressure", "real-time view of wait times by site & team"], ["Missed-call alerts", "after-hours and abandonment trends"], ["Plain-language summaries", "no manual reporting cycle"]],
      }
    )}
    cta="Connect with Broadvoice to improve patient access, reduce administrative workload, and modernize healthcare communications."
  />
);

export default HealthcareFlyer;
