import React from "react";
import { PhoneOff, Bot, Clock, Cloud, BarChart3, Building2, CheckCircle2, Mail, Globe } from "lucide-react";
import "./GoEngageDatasheet.css";

const IconDefs = () => (
  <svg width="0" height="0" style={{ position: "absolute" }}>
    <defs>
      <linearGradient id="cc-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#43B5BF" />
        <stop offset="100%" stopColor="#27698F" />
      </linearGradient>
    </defs>
  </svg>
);

const CoBrandLogos = () => (
  <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
    <img src="/assets/broadvoice-logo.png" alt="Broadvoice" style={{ height: 34, width: "auto", filter: "brightness(0) invert(1)" }} />
    <div style={{ width: 1, height: 38, background: "rgba(255,255,255,0.5)" }} />
    <img src="/assets/logo-data-integrity.png" alt="Data Integrity Services" style={{ height: 36, width: "auto", filter: "brightness(0) invert(1)" }} />
  </div>
);

const SectionLabel: React.FC<{ n: number; label: string }> = ({ n, label }) => (
  <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 6 }}>
    SECTION {n} · {label}
  </div>
);

const PageHeader = () => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18, fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#888899", letterSpacing: "0.08em", textTransform: "uppercase" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" style={{ height: 18, width: "auto" }} />
      <div style={{ width: 1, height: 20, background: "rgba(0,0,0,0.25)" }} />
      <img src="/assets/logo-data-integrity.png" alt="Data Integrity" style={{ height: 20, width: "auto", filter: "brightness(0)" }} />
    </div>
  </div>
);

const SolutionBlock: React.FC<{ Icon: React.ComponentType<any>; title: string; sub: string; desc: string; items: Array<[string, string]> }> = ({ Icon, title, sub, desc, items }) => (
  <div style={{ background: "#FFFFFF", border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px", height: "100%", display: "flex", flexDirection: "column" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
      <Icon size={22} style={{ stroke: "url(#cc-grad)", flexShrink: 0 }} strokeWidth={1.8} />
      <div>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Besley', Georgia, serif", fontStyle: "italic", lineHeight: 1.1 }}>{title}</div>
        <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: "#43B5BF", fontFamily: "'Inter', sans-serif", marginTop: 3 }}>{sub}</div>
      </div>
    </div>
    <p style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.65, margin: "10px 0 10px", fontFamily: "'Inter', sans-serif" }}>{desc}</p>
    <div style={{ marginTop: "auto", display: "flex", flexDirection: "column", gap: 4 }}>
      {items.map(([lead, rest], i) => (
        <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 6 }}>
          <span style={{ color: "#43B5BF", fontSize: 10, lineHeight: 1.6 }}>•</span>
          <span style={{ fontSize: 9, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>
            <span style={{ fontWeight: 700, color: "#1A1A2E" }}>{lead}</span>{rest ? ` — ${rest}` : ""}
          </span>
        </div>
      ))}
    </div>
  </div>
);



const ChallengeCard: React.FC<{ n: string; title: string; body: string }> = ({ n, title, body }) => (
  <div style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "10px 12px", background: "#FFFFFF" }}>
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4 }}>
      <span style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 18, fontWeight: 500, background: "linear-gradient(90deg, #43B5BF, #27698F)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", lineHeight: 1 }}>{n}</span>
      <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.25 }}>{title}</div>
    </div>
    <p style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.5, margin: 0, fontFamily: "'Inter', sans-serif" }}>{body}</p>
  </div>
);

const TrustedLogos = () => (
  <div style={{ marginTop: 18 }}>
    <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 12, textAlign: "center" }}>
      Trusted by Leading Ministries Across the United States
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 18, alignItems: "center", justifyItems: "center", padding: "6px 8px" }}>
      <img src="/assets/logo-st-joseph.png" alt="St. Joseph Church" style={{ maxHeight: 28, maxWidth: "100%", objectFit: "contain" }} />
      <img src="/assets/logo-olmc.png" alt="Our Lady of Mount Carmel" style={{ maxHeight: 32, maxWidth: "100%", objectFit: "contain" }} />
      <img src="/assets/logo-john-paul-ii.jpeg" alt="John Paul II Catholic School" style={{ maxHeight: 38, maxWidth: "100%", objectFit: "contain" }} />
      <img src="/assets/logo-st-martin.png" alt="St. Martin de Porres" style={{ maxHeight: 38, maxWidth: "100%", objectFit: "contain" }} />
      <img src="/assets/logo-catholic-charities.png" alt="Catholic Charities of Long Island" style={{ maxHeight: 30, maxWidth: "100%", objectFit: "contain" }} />
    </div>
  </div>
);

const PageFootText: React.FC<{ n: number }> = ({ n }) => (
  <div style={{ position: "absolute", bottom: 22, left: "0.625in", right: "0.625in", display: "flex", justifyContent: "space-between", fontSize: 9, color: "#888899", fontFamily: "'Inter', sans-serif", letterSpacing: "0.08em", textTransform: "uppercase" }}>
    <span>Learn more at <a href="https://broadvoice.com" style={{ color: "#27698F", textDecoration: "none", fontWeight: 600 }}>broadvoice.com</a></span>
    <span>Page {n}</span>
  </div>
);

const CatholicChurchesFlyer: React.FC = () => {
  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={() => window.print()}>Export as PDF</button>
      <IconDefs />

      {/* ===== PAGE 1 ===== */}
      <div className="page" style={{ padding: 0 }}>
        {/* Hero image header with overlay */}
        <div style={{ position: "relative", width: "100%", height: "3in", overflow: "hidden" }}>
          <img src="/assets/stained-glass.jpg" alt="Stained glass" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(10,20,40,0.6) 0%, rgba(10,20,40,0.4) 45%, rgba(39,105,143,0.85) 100%)" }} />
          {/* Co-brand logos overlay top */}
          <div style={{ position: "absolute", top: 22, left: "0.625in", right: "0.625in", display: "flex", alignItems: "center", gap: 14 }}>
            <img src="/assets/broadvoice-logo.png" alt="Broadvoice" style={{ height: 18.36, width: "auto", filter: "brightness(0) invert(1)" }} />
            <div style={{ width: 1, height: 20.4, background: "rgba(255,255,255,0.5)" }} />
            <img src="/assets/logo-data-integrity.png" alt="Data Integrity Services" style={{ height: 20.4, width: "auto", filter: "brightness(0) invert(1)" }} />
          </div>
          {/* Dark overlay at bottom */}
          <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: "55%", background: "linear-gradient(180deg, rgba(8,16,32,0) 0%, rgba(8,16,32,0.65) 55%, rgba(8,16,32,0.92) 100%)", pointerEvents: "none" }} />

          {/* H1 overlay bottom */}
          <div style={{ position: "absolute", bottom: 74, left: "0.625in", right: "0.625in" }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.22em", textTransform: "uppercase", color: "#A8E5EB", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>
              Broadvoice for Catholic Churches
            </div>
            <h1 style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 46, fontWeight: 500, lineHeight: 1.05, letterSpacing: "-0.02em", color: "#FFFFFF", margin: 0 }}>
              Never Miss a<br /><em style={{ fontFamily: "'Besley', serif", fontWeight: 400, fontStyle: "italic", background: "linear-gradient(90deg, #43B5BF, #A8E5EB, #C686F8)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent" }}>Ministry Moment</em>
            </h1>
          </div>
        </div>

        {/* Body */}
        <div style={{ padding: "0.45in 0.625in 0.7in" }}>
          <p style={{ fontFamily: "'Besley', Georgia, serif", fontSize: 15, fontStyle: "italic", color: "#1A1A2E", lineHeight: 1.4, margin: "0 0 14px 0", maxWidth: "6.5in" }}>
            Every unanswered call is a missed connection to your community.
          </p>
          <p style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, margin: "0 0 18px 0", fontFamily: "'Inter', sans-serif" }}>
            Broadvoice gives Catholic parishes and dioceses a unified communications platform built for the complexity of ministry operations — intelligent call routing, AI voice agents, multi-site management, and real-time analytics, all from a single provider.
          </p>

          {/* Stats row */}
          <div className="stats-row" style={{ marginBottom: 22, marginTop: -20 }}>
            <div className="stat-item">
              <div className="num">1 in 5</div>
              <div className="lbl"><strong>Churches go unanswered</strong>after five call attempts during normal business hours — parishioners in need of pastoral care turned away by silence.</div>
            </div>
            <div className="stat-item">
              <div className="num">70%</div>
              <div className="lbl"><strong>Of inbound parish calls</strong>are routine — Mass times, directions, event details — volume an AI voice agent can handle, freeing staff for ministry.</div>
            </div>
            <div className="stat-item">
              <div className="num">24/7</div>
              <div className="lbl"><strong>Pastoral needs don't wait</strong>Grief, crisis, and urgent calls don't follow office hours. Every call receives a response, every time.</div>
            </div>
          </div>

          
          <h2 className="section-title" style={{ marginTop: -15 }}>Built for the <em>complexity</em> of ministry operations</h2>
          <p className="section-body" style={{ maxWidth: "100%" }}>
            Catholic organizations manage layered operations — parish offices, schools, faith formation, pastoral care, facilities, and outreach — all fielding inbound calls from a congregation that needs to reach the right person quickly. Legacy phone systems weren't built for this.
          </p>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 6 }}>
            <ChallengeCard n="01" title="Multi-department call routing" body="A single campus may route calls across parish office, school, faith formation, facilities, and on-call pastoral staff — without a dedicated receptionist for each." />
            <ChallengeCard n="02" title="After-hours & crisis coverage" body="Grieving families, parishioners in crisis, and first-time visitors don't call only during business hours. Unanswered calls in these moments are real pastoral failures." />
            <ChallengeCard n="03" title="Seasonal volume spikes" body="Christmas, Easter, Ash Wednesday, funeral coordination, and RCIA enrollment create intense surges that overwhelm small staffs." />
            <ChallengeCard n="04" title="Multilingual ministry" body="More than 5,000 U.S. parishes celebrate Mass in a language other than English — 81% serving Spanish-speaking communities. Communications must reflect that." />
            <ChallengeCard n="05" title="Volunteer & mobile staff" body="With an average of eight ministry staff per parish plus rotating volunteers, team communication must work across devices and locations — no hardware required." />
            <ChallengeCard n="06" title="Diocesan oversight at scale" body="Diocese administrators need visibility and control across all parish phone environments without managing separate vendors or systems for each site." />
          </div>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page">
        <PageHeader />

        
        <h2 className="section-title">A unified platform for <em>every ministry need</em></h2>
        <p className="section-body" style={{ maxWidth: "100%", marginBottom: 14 }}>
          Four integrated solutions — phone system, AI voice agent, analytics, and diocesan management — on a single platform, from a single provider.
        </p>

        <div style={{ background: "linear-gradient(130.54deg, #FCF6FF 5.82%, #E8FCFF 113.26%)", border: "1px solid #E2E2EC", borderRadius: 12, padding: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <SolutionBlock
            Icon={Cloud}
            title="b-hive UCaaS"
            sub="Cloud Phone System"
            desc="Enterprise-grade communications priced and simplified for ministry budgets and non-technical staff."
            items={[
              ["Smart routing", "auto attendant, IVR & custom call trees"],
              ["Mobile app", "staff take calls without sharing personal numbers"],
              ["Always-on schedules", "holiday & after-hours flows, no IT ticket"],
            ]}
          />

          <SolutionBlock
            Icon={Building2}
            title="GoContact"
            sub="Multi-Site Diocese Management"
            desc="Centralized administration with local flexibility across dozens — or hundreds — of parishes."
            items={[
              ["One account", "manage every parish under a single platform"],
              ["Local autonomy", "each parish keeps its numbers, routing & flows"],
              ["One vendor", "one contract, one bill — at any scale"],
            ]}
          />

          <SolutionBlock
            Icon={Bot}
            title="Engage Voice"
            sub="AI Voice Agent"
            desc="An AI voice agent that handles repetitive inbound calls 24/7 — so staff focus on what only humans can do."
            items={[
              ["24/7 answering", "Mass times, directions, registration"],
              ["Bilingual", "English & Spanish flows out of the box"],
              ["Graceful escalation", "routes sensitive calls to a live person"],
            ]}
          />

          <SolutionBlock
            Icon={BarChart3}
            title="GoInsights AI Analyst"
            sub="Real-Time Visibility"
            desc="Real-time visibility into how your community is reaching you — and where calls are slipping through."
            items={[
              ["Call patterns", "volume by location, department & time of day"],
              ["Missed-call alerts", "after-hours and unanswered trends"],
              ["Diocesan view", "consolidated insight across every parish"],
            ]}
          />
        </div>



        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginTop: 28, marginBottom: 6, textAlign: "center" }}>Why Broadvoice</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginTop: 6, marginBottom: 6 }}>
          {[
            { t: "Easy to deploy", d: "No IT department required" },
            { t: "Easy to manage", d: "Non-technical staff handle day-to-day changes" },
            { t: "Easy to own", d: "Predictable pricing, U.S.-based support" },
            { t: "UCaaS + CCaaS", d: "Single platform — no vendor stitching" },
          ].map(({ t, d }, i) => (
            <div key={i} style={{ border: "1px solid #D0E8EA", borderRadius: 8, padding: "10px 12px", background: "rgba(67,181,191,0.04)" }}>
              <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "#27698F", marginBottom: 3, lineHeight: 1.15 }}>{t}</div>
              <div style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.45, fontFamily: "'Inter', sans-serif" }}>{d}</div>
            </div>
          ))}
        </div>

        <div className="about-section" style={{ position: "static", maxWidth: "100%", marginTop: 18 }}>
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent CX solutions for midmarket organizations—empowering business teams to design modern, frictionless customer experiences with AI that's practical, easy to use, and purpose-built for how they work.
          </p>
        </div>

        <TrustedLogos />

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default CatholicChurchesFlyer;
