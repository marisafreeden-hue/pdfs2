import React from "react";
import {
  Mail,
  Share2,
  CheckSquare,
  Users,
  Layers,
  Settings2,
  HeartHandshake,
  Handshake,
  MessageCircleQuestion,
  Linkedin,
  Twitter,
  Facebook,
  Image as ImageIcon,
} from "lucide-react";
import "./GoEngageDatasheet.css";

const teal = "#338FAD";
const ink = "#1A1A2E";
const body = "#555567";
const line = "#E2E2EC";

const Eyebrow: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div
    style={{
      fontSize: 8,
      fontWeight: 600,
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      color: teal,
      fontFamily: "'Inter', sans-serif",
      marginBottom: 8,
    }}
  >
    {children}
  </div>
);

const Card: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <div
    style={{
      border: `1px solid ${line}`,
      borderRadius: 10,
      padding: "14px 16px",
      ...style,
    }}
  >
    {children}
  </div>
);

const MetaRow: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div style={{ display: "grid", gridTemplateColumns: "112px 1fr", borderTop: `1px solid ${line}` }}>
    <div
      style={{
        padding: "9px 12px",
        background: "#F8FAFB",
        fontSize: 9,
        fontWeight: 700,
        letterSpacing: "0.06em",
        textTransform: "uppercase",
        color: teal,
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {label}
    </div>
    <div style={{ padding: "9px 12px", fontSize: 10.5, color: body, lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>
      {children}
    </div>
  </div>
);

const P: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <p style={{ fontSize: 10.5, color: body, lineHeight: 1.65, margin: "0 0 8px", fontFamily: "'Inter', sans-serif", ...style }}>
    {children}
  </p>
);

const Bullet: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
    <span
      style={{
        width: 5,
        height: 5,
        borderRadius: 999,
        background: "linear-gradient(135deg, #43B5BF, #27698F)",
        marginTop: 6,
        flexShrink: 0,
      }}
    />
    <div style={{ fontSize: 10.5, color: body, lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{children}</div>
  </div>
);

const Footer: React.FC<{ page: number }> = ({ page }) => (
  <div
    style={{
      position: "absolute",
      left: "0.625in",
      right: "0.625in",
      bottom: "0.45in",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      borderTop: `1px solid ${line}`,
      paddingTop: 8,
      fontSize: 8.5,
      color: "#888899",
      fontFamily: "'Inter', sans-serif",
      zIndex: 2,
    }}
  >
    <span>Partner Marketing Kit · New Supplier Announcement · V1</span>
    <span>© Broadvoice 2026 · Page {page}</span>
  </div>
);

const Gradients = () => (
  <svg width="0" height="0" style={{ position: "absolute" }}>
    <defs>
      <linearGradient id="kit-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#43B5BF" />
        <stop offset="100%" stopColor="#27698F" />
      </linearGradient>
    </defs>
  </svg>
);

const Page: React.FC<{ children: React.ReactNode; page: number }> = ({ children, page }) => (
  <div className="page" style={{ position: "relative", overflow: "hidden" }}>
    <div className="logo" style={{ marginBottom: 14 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {children}
    <Footer page={page} />
  </div>
);

const PartnerIntroKit: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>
      <Gradients />

      {/* PAGE 1 */}
      <Page page={1}>
        <Eyebrow>New Supplier Announcement · Partner Marketing Kit</Eyebrow>
        <h1 className="hero-headline" style={{ fontSize: 40, lineHeight: 1.1, marginBottom: 8 }}>
          Introducing Your <em>New Partner</em>:<br />Broadvoice
        </h1>
        <P style={{ fontSize: 12, maxWidth: 580, marginBottom: 16 }}>
          A grab-and-go kit for onboarded selling partners who want to tell their customer base about their new UCaaS +
          CCaaS supplier. Everything inside is ready to send as-is, or mix and match the pieces you need.
        </P>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
          <Card style={{ background: "rgba(67,181,191,0.05)", borderColor: "#D0E8EA" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <Mail size={15} style={{ stroke: "url(#kit-grad)" }} />
              <div style={{ fontSize: 11, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif" }}>What's Inside</div>
            </div>
            <P style={{ margin: 0, fontSize: 10 }}>
              A 2-touch email sequence (Day 0 announcement + Day 5–7 deep dive) and four ready-to-post social updates.
            </P>
          </Card>
          <Card>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <CheckSquare size={15} style={{ stroke: "url(#kit-grad)" }} />
              <div style={{ fontSize: 11, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif" }}>How To Use It</div>
            </div>
            <P style={{ margin: 0, fontSize: 10 }}>
              Replace bracketed [placeholders] with your company details, then send from your own domain and channels.
              See the checklist on the final page.
            </P>
          </Card>
        </div>

        <hr className="section-divider" />

        <h2 className="section-title" style={{ fontSize: 20 }}>
          About Broadvoice — <em>Talking Points</em>
        </h2>
        <P style={{ maxWidth: 600 }}>
          Use these points as source material for the emails and posts, or to answer questions your customers ask after
          they see the announcement.
        </P>

        <Card style={{ background: "#F8FAFB", marginBottom: 12 }}>
          <Eyebrow>The One-Line Positioning</Eyebrow>
          <div
            style={{
              fontFamily: "'Instrument Sans', -apple-system, sans-serif",
              fontSize: 15,
              lineHeight: 1.45,
              fontWeight: 500,
              background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Broadvoice is a unified UCaaS and CCaaS provider built for the midmarket — one platform, one partner, for
            both everyday business communications and customer experience.
          </div>
        </Card>

        <Eyebrow>Why Broadvoice, Specifically</Eyebrow>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
          {[
            { Icon: Users, t: "Midmarket-first", d: "Purpose-built for growing companies that have outgrown small-business phone tools but don't need enterprise complexity." },
            { Icon: Layers, t: "One portfolio, two engines", d: "Cloud voice, video, messaging and SMS (UC) alongside a full contact center platform (CX) — one relationship." },
            { Icon: Settings2, t: "Configurable, not rigid", d: "Flexible call flows, integrations and packaging that adapt to how a business actually operates." },
            { Icon: HeartHandshake, t: "White-glove onboarding", d: "Dedicated implementation and support — critical for buyers without a large in-house IT team." },
          ].map((i, k) => (
            <div key={k} style={{ display: "flex", gap: 9, padding: "10px 12px", border: `1px solid ${line}`, borderRadius: 8 }}>
              <i.Icon size={15} style={{ stroke: "url(#kit-grad)", flexShrink: 0, marginTop: 1 }} />
              <div>
                <div style={{ fontSize: 10.5, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif", marginBottom: 2 }}>{i.t}</div>
                <div style={{ fontSize: 9.5, color: body, lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{i.d}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 9, padding: "10px 12px", border: `1px solid ${line}`, borderRadius: 8, marginBottom: 14 }}>
          <Handshake size={15} style={{ stroke: "url(#kit-grad)", flexShrink: 0, marginTop: 1 }} />
          <div>
            <div style={{ fontSize: 10.5, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif", marginBottom: 2 }}>Channel-built</div>
            <div style={{ fontSize: 9.5, color: body, lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>
              Programs, SPIFFs and MDF designed around partner success, not just direct sales.
            </div>
          </div>
        </div>

        <Eyebrow>Good Discovery Questions To Plant In The Market</Eyebrow>
        <div style={{ display: "grid", gap: 6 }}>
          {[
            "Are you running your phone system and your contact center on two different vendors today?",
            "Has your current UC provider outgrown your company, or has your company outgrown it?",
            "What would it be worth to have one partner accountable for both your internal communications and your customer experience?",
          ].map((q, i) => (
            <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
              <MessageCircleQuestion size={14} style={{ stroke: "url(#kit-grad)", flexShrink: 0, marginTop: 2 }} />
              <div style={{ fontSize: 10.5, color: body, lineHeight: 1.55, fontStyle: "italic", fontFamily: "'Inter', sans-serif" }}>
                “{q}”
              </div>
            </div>
          ))}
        </div>
      </Page>

      {/* PAGE 2 — Touch 1 */}
      <Page page={2}>
        <Eyebrow>Email Sequence · Touch 1</Eyebrow>
        <h1 className="hero-headline" style={{ fontSize: 30, lineHeight: 1.15, marginBottom: 6 }}>
          Touch 1 — <em>Announcement Email</em>
        </h1>
        <P style={{ marginBottom: 12 }}>
          <strong style={{ color: ink }}>Send Day 0.</strong> Let your list know you now offer Broadvoice, in one
          sentence they'll actually read. Short, confident, no jargon.
        </P>

        <div style={{ border: `1px solid ${line}`, borderRadius: 10, overflow: "hidden", marginBottom: 14 }}>
          <MetaRow label="Subject Options">
            <div>1. Big news: we've added Broadvoice to our portfolio</div>
            <div>2. A new option for your phone system and contact center</div>
            <div>3. [Your Company] + Broadvoice: what it means for you</div>
          </MetaRow>
          <MetaRow label="Preview Text">
            <em>One partner for unified communications and customer experience — now available through us.</em>
          </MetaRow>
          <MetaRow label="Goal">Announce the new supplier relationship and earn a reply or click; not a hard sell.</MetaRow>
        </div>

        <Eyebrow>Body Copy</Eyebrow>
        <Card style={{ background: "#FCFDFD" }}>
          <P>Hi [First Name],</P>
          <P>Quick update: [Your Company] has added Broadvoice to the solutions we offer our clients.</P>
          <P>
            If you haven't come across them, Broadvoice is a cloud communications provider built specifically for
            growing, midmarket businesses. They bring together two things that are usually sold by two different
            vendors:
          </P>
          <div style={{ marginBottom: 8 }}>
            <Bullet>
              <strong style={{ color: ink }}>Unified Communications</strong> — cloud phone system, video meetings, team
              messaging, and SMS
            </Bullet>
            <Bullet>
              <strong style={{ color: ink }}>Customer Experience (CX)</strong> — a full contact center platform for
              support and sales teams
            </Bullet>
          </div>
          <P>Same platform, same partner, one bill, one team to call when something needs to change.</P>
          <P>
            We added Broadvoice because we kept hearing the same thing from clients: your business has outgrown your
            current phone system, but you don't want (or need) the cost and complexity of an enterprise-grade rollout.
            Broadvoice sits right in that gap — flexible enough to configure around how you actually work, with the kind
            of hands-on onboarding and support that a growing company needs.
          </P>
          <div
            style={{
              borderLeft: "3px solid #C686F8",
              paddingLeft: 12,
              margin: "10px 0",
            }}
          >
            <P style={{ margin: 0 }}>
              <strong style={{ color: teal }}>The short version:</strong> if you're evaluating your phone system, your
              contact center, or both, it's worth 20 minutes to see if Broadvoice is a fit.
            </P>
          </div>
          <P>Want to see what it could look like for your team?</P>
          <div
            style={{
              display: "inline-block",
              padding: "9px 16px",
              borderRadius: 6,
              background: "linear-gradient(90deg, #43B5BF, #27698F)",
              color: "#FFFFFF",
              fontSize: 10.5,
              fontWeight: 700,
              fontFamily: "'Inter', sans-serif",
              margin: "2px 0 10px",
            }}
          >
            Book a 20-Minute Fit Call →
          </div>
          <P>Talk soon,</P>
          <P style={{ margin: 0, color: ink }}>
            [Your Name]
            <br />
            [Your Title], [Your Company]
            <br />
            [Phone] | [Email]
          </P>
        </Card>
      </Page>

      {/* PAGE 3 — Touch 2 */}
      <Page page={3}>
        <Eyebrow>Email Sequence · Touch 2</Eyebrow>
        <h1 className="hero-headline" style={{ fontSize: 30, lineHeight: 1.15, marginBottom: 6 }}>
          Touch 2 — <em>Deep-Dive Email</em>
        </h1>
        <P style={{ marginBottom: 12 }}>
          <strong style={{ color: ink }}>Send Day 5–7.</strong> For the people who didn't respond to Touch 1, give them
          a concrete reason to look again — leading with the UC + CX portfolio story and a lower-friction ask.
        </P>

        <div style={{ border: `1px solid ${line}`, borderRadius: 10, overflow: "hidden", marginBottom: 14 }}>
          <MetaRow label="Subject Options">
            <div>1. Still using separate tools for phones and customer support?</div>
            <div>2. One platform for your team and your customers</div>
            <div>3. The UC + CX combo we mentioned last week</div>
          </MetaRow>
          <MetaRow label="Preview Text">
            <em>Here's what the Broadvoice portfolio actually covers, in plain terms.</em>
          </MetaRow>
          <MetaRow label="Goal">Re-engage non-responders with specifics and a lighter-weight CTA (resource, not a meeting).</MetaRow>
        </div>

        <Eyebrow>Body Copy</Eyebrow>
        <Card style={{ background: "#FCFDFD" }}>
          <P>Hi [First Name],</P>
          <P>
            Following up on the note I sent about adding Broadvoice to our portfolio — I wanted to give you a clearer
            picture of what's actually included, since “cloud communications” can mean a lot of different things
            depending on who you ask. With Broadvoice, you're looking at two connected pieces:
          </P>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, margin: "10px 0" }}>
            {[
              { t: "UC — Run the business", d: "Cloud phone system, HD video meetings, team messaging, and business SMS, on desktop and mobile." },
              { t: "CX — Support the customer", d: "A full contact center: routing, queues, reporting, and omnichannel support for sales and service teams." },
            ].map((c, i) => (
              <div key={i} style={{ border: "1px solid #D0E8EA", background: "rgba(67,181,191,0.05)", borderRadius: 8, padding: "11px 13px" }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif", marginBottom: 3 }}>{c.t}</div>
                <div style={{ fontSize: 9.5, color: body, lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{c.d}</div>
              </div>
            ))}
          </div>
          <P>
            Most midmarket companies we talk to are running these on two separate systems today, sometimes from two
            vendors who don't talk to each other. Broadvoice's pitch is simple: put both under one roof, with one team
            accountable for uptime, support, and how it all fits together as you grow.
          </P>
          <P>It's not the right fit for every business — but if any of this sounds familiar, it's worth a look:</P>
          <div style={{ marginBottom: 8 }}>
            <Bullet>Your team has outgrown your current phone provider's feature set</Bullet>
            <Bullet>Your contact center and your phone system are separate logins, separate vendors, separate headaches</Bullet>
            <Bullet>You want room to add locations, seats, or CX capabilities without re-platforming again in two years</Bullet>
          </div>
          <P>If that's you, I'd rather send you something to review on your own time than push for a meeting:</P>
          <div
            style={{
              display: "inline-block",
              padding: "9px 16px",
              borderRadius: 6,
              background: "linear-gradient(90deg, #43B5BF, #27698F)",
              color: "#FFFFFF",
              fontSize: 10.5,
              fontWeight: 700,
              fontFamily: "'Inter', sans-serif",
              margin: "2px 0 10px",
            }}
          >
            See the Broadvoice Overview →
          </div>
          <P>And if you'd rather just talk it through, I'm happy to do that too — just reply to this email.</P>
          <P style={{ margin: 0, color: ink }}>
            [Your Name]
            <br />
            [Your Title], [Your Company]
            <br />
            [Phone] | [Email]
          </P>
        </Card>
      </Page>

      {/* PAGE 4 — Social */}
      <Page page={4}>
        <Eyebrow>Ready-To-Post Content</Eyebrow>
        <h1 className="hero-headline" style={{ fontSize: 30, lineHeight: 1.15, marginBottom: 6 }}>
          Social Media <em>Elements</em>
        </h1>
        <P style={{ marginBottom: 14, maxWidth: 600 }}>
          Four ready-to-post options. Pair each with your logo lock-up, a Broadvoice co-brand graphic, or a simple
          text-on-color card in your brand colors.
        </P>

        <div style={{ display: "grid", gap: 10, marginBottom: 14 }}>
          {[
            {
              Icon: Linkedin,
              t: "LinkedIn — Announcement Post (long-form)",
              lines: [
                "Big update from our team: we've added Broadvoice to our partner portfolio.",
                "Broadvoice builds unified communications (cloud phone, video, messaging, SMS) and a full contact center platform for midmarket businesses — one partner, one platform, for how your team talks internally AND how you support your customers.",
                "If your phone system has outgrown your business (or your business has outgrown it), let's talk. Link in comments →",
              ],
              tags: "#UCaaS #CCaaS #CustomerExperience #CloudCommunications #Midmarket #Broadvoice",
            },
            {
              Icon: Linkedin,
              t: "LinkedIn — Short Update",
              lines: [
                "New in our portfolio: Broadvoice. One platform for cloud phones, meetings, messaging, and a full contact center — built for growing businesses. Ask us how it fits your stack.",
              ],
            },
            {
              Icon: Twitter,
              t: "X / Twitter",
              lines: [
                "We just added Broadvoice to our lineup — unified comms + contact center, one platform, built for midmarket teams.",
                "DM us if your phone system needs an upgrade.",
              ],
            },
            {
              Icon: Facebook,
              t: "Facebook / Instagram Caption",
              lines: [
                "Big news for our clients: we now partner with Broadvoice — bringing phones, video, messaging, and customer support tools together on one easy platform. Reach out if you're ready to simplify how your business communicates.",
              ],
            },
          ].map((s, i) => (
            <Card key={i}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
                <div
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: 6,
                    background: "linear-gradient(135deg, #43B5BF, #27698F)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  <s.Icon size={12} color="#FFFFFF" />
                </div>
                <div style={{ fontSize: 11, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif" }}>
                  {i + 1}. {s.t}
                </div>
              </div>
              {s.lines.map((l, k) => (
                <P key={k} style={{ marginBottom: 6 }}>
                  {l}
                </P>
              ))}
              {s.tags && (
                <div style={{ fontSize: 9.5, color: teal, fontWeight: 600, fontFamily: "'Inter', sans-serif" }}>{s.tags}</div>
              )}
            </Card>
          ))}
        </div>

        <Eyebrow>Visual Pairing Ideas</Eyebrow>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
          {[
            "Simple text-on-color card: “Now Partnering With Broadvoice” on a white or light-teal background",
            "Side-by-side icon graphic: “UC” (phone/video/chat) + “CX” (headset/support) under one roofline",
            "Your logo + Broadvoice logo lock-up, if co-branding is approved",
          ].map((v, i) => (
            <div key={i} style={{ border: `1px solid ${line}`, borderRadius: 8, padding: "10px 12px", background: "#F8FAFB" }}>
              <ImageIcon size={14} style={{ stroke: "url(#kit-grad)", marginBottom: 5 }} />
              <div style={{ fontSize: 9.5, color: body, lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{v}</div>
            </div>
          ))}
        </div>
      </Page>

      {/* PAGE 5 — Checklist */}
      <Page page={5}>
        <Eyebrow>Before You Send</Eyebrow>
        <h1 className="hero-headline" style={{ fontSize: 30, lineHeight: 1.15, marginBottom: 6 }}>
          Customization <em>Checklist</em>
        </h1>
        <P style={{ marginBottom: 16, maxWidth: 600 }}>
          Replace every bracketed placeholder and confirm the basics below before you send or post.
        </P>

        <div style={{ display: "grid", gap: 8, marginBottom: 18 }}>
          {[
            { t: "[Your Company]", d: "Your company name, used throughout both emails." },
            { t: "[Your Name] / [Your Title]", d: "Sender details for the email sign-off." },
            { t: "[Phone] / [Email]", d: "Direct contact info." },
            { t: "[First Name]", d: "Mail-merge field from your CRM or ESP." },
            { t: "Link destinations", d: "Point the CTA buttons to your booking page and your Broadvoice overview asset." },
            { t: "Logo lock-up", d: "Confirm co-branding approval before pairing your logo with the Broadvoice logo." },
          ].map((c, i) => (
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", border: `1px solid ${line}`, borderRadius: 8, padding: "11px 13px" }}>
              <div
                style={{
                  width: 16,
                  height: 16,
                  borderRadius: 4,
                  border: "1.5px solid #43B5BF",
                  flexShrink: 0,
                  marginTop: 1,
                }}
              />
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif", marginBottom: 2 }}>{c.t}</div>
                <div style={{ fontSize: 10, color: body, lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{c.d}</div>
              </div>
            </div>
          ))}
        </div>

        <Card style={{ background: "rgba(67,181,191,0.05)", borderColor: "#D0E8EA" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <Share2 size={15} style={{ stroke: "url(#kit-grad)" }} />
            <div style={{ fontSize: 12, fontWeight: 700, color: ink, fontFamily: "'Inter', sans-serif" }}>Need something else?</div>
          </div>
          <P style={{ margin: 0, fontSize: 11 }}>
            Questions on positioning, co-branded assets, or additional social variants? Reach out to your Broadvoice
            channel manager.
          </P>
        </Card>

        <div className="page-bottom-cta" style={{ bottom: "0.95in" }}>
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" style={{ height: 50 }} />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
        </div>
      </Page>
    </div>
  );
};

export default PartnerIntroKit;
