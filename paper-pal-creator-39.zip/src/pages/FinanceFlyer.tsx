import React from "react";
import VerticalFlyer, { buildSolutions } from "./VerticalFlyer";
import hero from "@/assets/hero-finance.jpg.asset.json";

const FinanceFlyer: React.FC = () => (
  <VerticalFlyer
    eyebrow="Broadvoice for Financial Services"
    headlineLine1="Earn Trust in"
    headlineAccent="Every Client Moment"
    heroImage={hero.url}
    pullQuote="Help clients get timely answers while giving teams a more consistent way to serve them."
    intro="Broadvoice helps financial services leaders improve client experience while reducing operating friction — connecting branches, advisors, service teams, and contact centers on a single cloud platform with messaging, agentic AI, and end-to-end analytics."
    stats={[
      { num: "99.999%", label: <><strong>Platform uptime SLA</strong>keeping branch lines, advisor desks, and client service queues continuously available.</> as any },
      { num: "80%", label: <><strong>Self-service success rate</strong>when routine balance, status, and appointment inquiries are handled by agentic AI.</> as any },
      { num: "11 hrs", label: <><strong>Returned per banker per week</strong>by automating repetitive inbound calls so advisors focus on high-value client conversations.</> as any },
    ]}
    sectionTitle="Built for the"
    sectionTitleEm="complexity of modern client service"
    sectionBody="Financial services teams operate across branches, advisory desks, contact centers, and hybrid work — fielding sensitive, time-critical client conversations that demand consistency, compliance, and speed."
    challenges={[
      { n: "01", title: "Client responsiveness", body: "Wealth, lending, and service clients expect fast answers. Hold times and transfers erode trust and AUM." },
      { n: "02", title: "Branch + hybrid teams", body: "Advisors split time between branch, home, and the road. Phone systems tied to a desk no longer fit the work." },
      { n: "03", title: "Routine call volume", body: "Balance, payment, statement, and appointment questions consume staff capacity that should go to revenue conversations." },
      { n: "04", title: "Compliance & recording", body: "Conversations must be captured, retained, and searchable to meet SEC, FINRA, and internal audit requirements." },
      { n: "05", title: "Multi-channel servicing", body: "Clients move between voice, SMS, and digital — service teams need one view of every interaction." },
      { n: "06", title: "Performance visibility", body: "Leaders need queue and service insight in real time, not in next month's spreadsheet." },
    ]}
    page2Title="A unified platform for"
    page2TitleEm="every client-facing team"
    page2Body="Four integrated solutions — phone system, contact center, agentic AI, and analytics — purpose-built for distributed financial services teams."
    solutions={buildSolutions(
      {
        ucaas: "Connect branches, advisors, operations, and back-office teams across hybrid and mobile work models.",
        ccaas: "Client-facing contact center with intelligent routing, screen pop, and supervisor visibility.",
        ai: "Agentic AI that resolves routine inbound calls so licensed staff focus on complex, revenue-impacting conversations.",
        insights: "Real-time visibility into queue activity, service trends, and team performance across every location.",
      },
      {
        ucaas: [["Branch + remote", "one number, any device"], ["Call recording", "compliant capture for advisor calls"], ["Bubble texting", "appointment, document & service reminders"]],
        ccaas: [["Smart routing", "by product, account, or VIP tier"], ["CRM screen pop", "context before the agent answers"], ["Supervisor view", "live queue & coaching tools"]],
        ai: [["Balance & status", "secure self-service inquiries"], ["Appointment booking", "with advisors & branches"], ["Warm escalation", "to licensed humans when needed"]],
        insights: [["Queue trends", "wait time & abandonment by team"], ["Service patterns", "topic, channel & resolution"], ["Plain-language reports", "no analyst required"]],
      }
    )}
    cta="Connect with Broadvoice to improve client responsiveness, reduce service friction, and modernize financial services communications."
    flexibleSolutionsLabel="Flexible Solutions for Financial Services Organizations"
  />
);

export default FinanceFlyer;
