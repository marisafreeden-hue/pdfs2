import React from "react";
import "./GoEngageDatasheet.css";

const BhiveDatasheet: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper bhive-datasheet">
      <style>{`
        .bhive-datasheet .stats-row.stats-4 { grid-template-columns: repeat(4, 1fr); }
        .bhive-datasheet .stats-row.stats-4 .stat-item { padding: 14px 14px 0 0; }
        .bhive-datasheet .stats-row.stats-4 .stat-item:not(:first-child) { padding-left: 14px; }
        .bhive-datasheet .stats-row.stats-4 .stat-item .num { font-size: 26px; margin-bottom: 6px; }
        .bhive-datasheet .stats-row.stats-4 .stat-item .lbl { font-size: 11px; line-height: 1.45; }
        .bhive-datasheet .stats-row.stats-4 .stat-item .lbl strong { font-size: 12px; }
      `}</style>
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>


      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="hero">
          <div>
            <h1 className="hero-headline">
              b-<em>hive</em> Unified Communications
            </h1>
            <p className="hero-body">
              All your business communications. One platform.
            </p>

            <p className="hero-desc">
              b-hive is Broadvoice's unified communications platform that brings business calling, messaging, video meetings, and collaboration together in a single cloud solution. Built for growing businesses and mid-market organizations, b-hive keeps employees connected and productive from anywhere — while simplifying management and reducing technology complexity.
            </p>
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <div className="stat-label-top">One Platform For</div>
              <div className="stat-value">
                <span className="stat-value-sans">4 </span><em>tools</em>
              </div>
              <div className="stat-desc">
                Calling, messaging,<br />meetings &amp; collaboration
              </div>
            </div>
          </div>
        </div>

        <hr />

        {/* Built for Today's Workforce */}
        <h2 className="section-title">Communications Built for <em>Today's Workforce</em></h2>
        <p className="section-body">
          Whether employees are in the office, working remotely, or on the go, b-hive delivers a consistent communications experience across devices and locations. Teams communicate more effectively, and IT benefits from simplified administration and management.
        </p>

        <div className="stats-row stats-4" style={{ marginTop: '8px' }}>
          <div className="stat-item">
            <div className="num">53%</div>
            <div className="lbl">
              <strong>Hybrid Workforce</strong>
              of the U.S. workforce works remotely at least 3 days per week.
            </div>
          </div>
          <div className="stat-item">
            <div className="num">87%</div>
            <div className="lbl">
              <strong>Better Connected</strong>
              of workers feel better connected with video conferencing.
            </div>
          </div>
          <div className="stat-item">
            <div className="num">28%</div>
            <div className="lbl">
              <strong>Tooling Gap</strong>
              of remote workers cannot access necessary communication tools.
            </div>
          </div>
          <div className="stat-item">
            <div className="num">75%</div>
            <div className="lbl">
              <strong>Text-First Buyers</strong>
              of consumers under 44 want to contact a business via text.
            </div>
          </div>
        </div>

        <hr className="section-divider" />

        {/* Why Organizations Choose */}
        <h2 className="section-title" style={{ marginTop: '12px' }}>Why Organizations Choose <em>b-hive</em></h2>

        <div className="feature-grid">
          <div className="feature-item">
            <div className="feature-title">Work from Anywhere</div>
            <div className="feature-body">Keep employees connected and productive in the office, remotely, or on the move.</div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Simplify Communications</div>
            <div className="feature-body">Calling, messaging, video meetings, and collaboration together in a single platform.</div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Reduce Complexity</div>
            <div className="feature-body">Eliminate the need to manage multiple communications applications and vendors.</div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Lower Costs</div>
            <div className="feature-body">Replace costly on-premises systems with a flexible cloud communications solution.</div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Easy to Deploy &amp; Adopt</div>
            <div className="feature-body">Accelerate time-to-value with streamlined implementation and an intuitive experience.</div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Expert Customer Success</div>
            <div className="feature-body">Hands-on guidance, training, and support from deployment through ongoing optimization.</div>
          </div>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <h2 className="section-title">Key <em>Features</em></h2>
        <p className="section-body">
          Everything teams need to connect, collaborate, and serve customers — across desktop, mobile, and the apps they already use every day.
        </p>

        <div className="feature-grid">
          <div className="feature-item">
            <div className="feature-title">Cloud PBX</div>
            <div className="feature-body">
              Business calling · Call forwarding · Call transfer · Call parking · Voicemail transcription
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Contact Center Integration</div>
            <div className="feature-body">
              Automatic call distribution · Call queueing · Call monitoring · Reporting · Time-of-day routing
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Microsoft Teams Integration</div>
            <div className="feature-body">
              Direct routing · Call analytics · Call recording · Click-to-call · CRM integration
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Meetings &amp; Collaboration</div>
            <div className="feature-body">
              Video meetings · Audio conferencing · Team messaging · Group chat · Screen sharing · Recording
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Mobile Application</div>
            <div className="feature-body">
              Business calling · Video meetings · Messaging &amp; SMS · Voicemail · Call history · Recording access
            </div>
          </div>
          <div className="feature-item">
            <div className="feature-title">Salesforce Integration</div>
            <div className="feature-body">
              Click-to-call · Screen pop · Contact matching · Activity logging · Notes &amp; dispositions
            </div>
          </div>
        </div>

        <hr />

        <h2 className="section-title">Flexible &amp; <em>Built to Scale</em></h2>
        <p className="section-body">
          Choose the capabilities each employee needs and scale as business requirements evolve. b-hive supports flexible user types so you only pay for what you use.
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Capability</th>
                <th>What It Delivers</th>
                <th>Best For</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Unified App</td>
                <td>Calling, messaging, meetings &amp; collaboration in one place</td>
                <td>Every employee</td>
              </tr>
              <tr>
                <td>Mobile</td>
                <td>Full calling, video &amp; messaging on iOS and Android</td>
                <td>Field &amp; mobile workers</td>
              </tr>
              <tr>
                <td>Teams &amp; Salesforce</td>
                <td>Direct routing, click-to-call, screen pop, activity logging</td>
                <td>Sales &amp; service teams</td>
              </tr>
              <tr>
                <td>Contact Center</td>
                <td>ACD, queueing, monitoring, time-of-day routing &amp; reporting</td>
                <td>Customer-facing teams</td>
              </tr>
              <tr>
                <td>Flexible Seats</td>
                <td>Mix-and-match user types so you only pay for what's needed</td>
                <td>Growing organizations</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="about-section" style={{ transform: 'translateY(40px)' }}>
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent communications and CX solutions for growing businesses and mid-market organizations — empowering teams to work, connect, and serve customers from anywhere.
          </p>
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

    </div>
  );
};

export default BhiveDatasheet;
