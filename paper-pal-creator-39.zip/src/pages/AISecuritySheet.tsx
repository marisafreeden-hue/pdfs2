import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const Logo = () => (
  <div className="logo">
    <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
  </div>
);

const AISecuritySheet: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <Logo />

        <div className="hero">
          <div>
            <h1 className="hero-headline" style={{ fontSize: 48 }}>
              AI Security for Your <em>Contact Center</em>
            </h1>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card" style={{ textAlign: "center" }}>
              <div className="stat-label-top">Certifications</div>
              <div className="stat-value">
                <span className="stat-value-sans">SOC </span><em>+</em>
              </div>
              <div className="stat-desc">
                AICPA SOC-certified, GDPR-aligned,<br />and PCI DSS embedded
              </div>
            </div>
          </div>
        </div>

        <h2 className="section-title" style={{ fontSize: 20, marginTop: 4 }}>
          Data Privacy & <em>Security Overview</em>
        </h2>
        <p className="section-body">
          AI serves as the intelligence layer across the GoContact platform and functions as the
          overarching AI framework for Broadvoice AI-powered applications, including Engage and
          GoInsights. Built on the same security, privacy, and reliability foundation as the broader
          GoContact platform, it ensures consistent controls across all AI-enabled capabilities. Data
          handling, security enforcement, and responsible AI operation are managed within customer
          environments as outlined below.
        </p>

        <hr />

        <h2 className="section-title">AI Management & <em>Governance</em></h2>
        <p className="section-body">
          The platform is designed and operated to ensure AI systems achieve intended outcomes in a
          controlled and measurable way, while preventing or reducing undesired effects such as
          unintended outputs or misuse. Continuous improvement is built in to strengthen performance,
          reliability, and overall risk posture over time.
        </p>

        <div className="stats-row" style={{ marginTop: 8 }}>
          <div className="stat-item">
            <div className="lbl">
              <strong>Ongoing monitoring</strong>
              Continuous observation of AI system behavior and performance across the platform.
            </div>
          </div>
          <div className="stat-item">
            <div className="lbl">
              <strong>Risk identification</strong>
              Identification and mitigation of risks across the entire AI lifecycle.
            </div>
          </div>
          <div className="stat-item">
            <div className="lbl">
              <strong>Continuous refinement</strong>
              Ongoing tuning of models, guardrails, and system configurations.
            </div>
          </div>
        </div>

        <hr />

        <h2 className="section-title">AI <em>Risk Management</em></h2>
        <p className="section-body">
          A structured approach is used to manage AI-related risk, including assessing risks tied to
          data processing, model behavior, and system outputs. Risk treatment is prioritized based on
          likelihood and potential impact, with controls implemented to mitigate identified risks and
          ongoing measurement to continuously reduce exposure over time. The platform is designed in
          alignment with GDPR principles, including ensuring that individuals are not subject to
          decisions based solely on automated processing.
        </p>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2 ai-security-page-2" style={{ paddingTop: 32, paddingBottom: 36 }}>
        <Logo />

        <h2 className="section-title">How AI Is <em>Used</em></h2>
        <p className="section-body">
          AI processing capabilities support operational workflows such as summarization, routing, and
          information retrieval, enabling faster and more efficient handling of customer interactions.
          These capabilities are designed to automate high-volume, repetitive tasks while supporting
          human oversight for more complex or sensitive scenarios. Just as important — the system does
          not perform profiling or make decisions with legal or meaningful individual impact. All
          outcomes remain subject to human review and organizational control.
        </p>

        <hr />

        <h2 className="section-title">Purpose of <em>Processing</em></h2>
        <p className="section-body">
          AI-driven capabilities span Engage (inbound interaction handling and automation) and
          GoInsights (operational and performance analysis). Processing is designed to improve
          operational efficiency, streamline interactions, and provide actionable insights — without
          profiling individuals or evaluating personal aspects of data subjects.
        </p>

        <hr />

        <h2 className="section-title">Data & <em>PII Handling</em></h2>
        <p className="section-body">
          A customer-controlled data model is maintained throughout. Data is accessed through
          configured APIs and integrations, with customers retaining full responsibility for
          determining what data — including any PII — is made available to the platform. Customers are
          responsible for ensuring that sensitive or regulated data is not exposed unless appropriate
          safeguards are in place.
        </p>
        <p className="section-body">
          Outputs such as transcripts, summaries, and insights may contain PII present in source
          interactions. Exposure is managed through customer-defined configurations, access controls,
          and guardrails, with logical data isolation ensuring separation between customer
          environments.
        </p>

        <hr />

        <h2 className="section-title">Data Processing & <em>Storage</em></h2>
        <p className="section-body">
          AI data is processed in real time to generate outputs such as transcripts, summaries, and
          insights. Third-party AI services may be used as part of processing workflows. Processing is
          designed to support immediate interaction handling and insight generation, not long-term
          profiling or behavioral analysis.
        </p>

        <div className="stats-row ai-security-storage-row" style={{ marginTop: 0 }}>
          <div className="stat-item">
            <div className="lbl">
              <strong>Customer-controlled storage</strong>
              Processed outputs may be stored under customer control within Broadvoice environments.
            </div>
          </div>
          <div className="stat-item">
            <div className="lbl">
              <strong>Encryption everywhere</strong>
              Encryption is applied in transit and at rest across all processing workflows.
            </div>
          </div>
          <div className="stat-item">
            <div className="lbl">
              <strong>Role-based access</strong>
              Access is governed through role-based access control (RBAC), with deletion available
              after a 45-day minimum retention.
            </div>
          </div>
        </div>

        <PageFooter />
      </div>

      {/* ===== PAGE 3 ===== */}
      <div className="page page-2">
        <Logo />

        <h2 className="section-title">Security Controls & <em>Guardrails</em></h2>
        <p className="section-body">
          Multiple layers of control are in place to ensure secure and predictable operation, including
          configurable guardrails, approved knowledge sources, and defined response boundaries.
          Role-based access control (RBAC) ensures only authorized users can access information. High
          availability and continuous monitoring support system reliability and performance over time.
        </p>

        <hr />

        <h2 className="section-title">Processing Activity & <em>DPIA</em></h2>
        <p className="section-body">
          AI-driven functionality introduces new data processing activities. A Data Protection Impact
          Assessment (DPIA) may be conducted to assess risk, validate safeguards, and ensure
          appropriate protective measures are in place where required. This includes evaluation of:
        </p>

        <div className="stats-row" style={{ marginTop: 8 }}>
          <div className="stat-item">
            <div className="num">01</div>
            <div className="lbl">
              <strong>Purpose & scope</strong>
              Defined scope and intent of processing activities
            </div>
          </div>
          <div className="stat-item">
            <div className="num">02</div>
            <div className="lbl">
              <strong>Types of data</strong>
              Including any PII involved in workflows
            </div>
          </div>
          <div className="stat-item">
            <div className="num">03</div>
            <div className="lbl">
              <strong>Flow & controls</strong>
              Data flow, storage, and access controls
            </div>
          </div>
        </div>

        <hr />

        <h2 className="section-title">Compliance & <em>Certifications</em></h2>
        <p className="section-body">
          The processes supporting AI are AICPA SOC-certified, ensuring appropriate due diligence and
          operational controls are in place. GDPR-aligned processes include recurring independent
          audits to validate that privacy controls are implemented and functioning as expected. PCI
          Data Security Standard compliance is also embedded within the broader GoContact platform.
        </p>

        <hr />

        <h2 className="section-title">Scale & <em>Data Volume</em></h2>
        <p className="section-body">
          The platform scales based on customer usage, interaction volume, and operational needs
          without requiring changes to underlying data architecture.
        </p>

        <PageFooter />
      </div>

      {/* ===== PAGE 4 ===== */}
      <div className="page page-2">
        <Logo />

        <h2 className="section-title">Customer <em>Responsibilities</em></h2>
        <p className="section-body">
          Customers retain control and responsibility for their data across the AI layer of the platform.
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 0,
            marginTop: 8,
          }}
        >
          {[
            ["Define access & permissions", "Set who can view, modify, and act on data within configured workflows."],
            ["Manage integrations", "Control connected systems and the data shared across them."],
            ["Configure guardrails", "Set knowledge sources, response boundaries, and escalation rules."],
            ["Request deletion", "Initiate deletion requests where required by policy or regulation."],
            ["Regulatory alignment", "Ensure alignment with internal policies and regulatory requirements."],
            ["Internal oversight", "Maintain organizational governance over how AI capabilities are used."],
          ].map(([t, b], i) => (
            <div
              key={i}
              style={{
                padding: "14px 18px 14px 0",
                borderRight: i % 3 !== 2 ? "1px solid #E2E2EC" : "none",
                borderTop: i >= 3 ? "1px solid #E2E2EC" : "none",
                paddingLeft: i % 3 !== 0 ? 18 : 0,
              }}
            >
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1A1A2E", marginBottom: 4 }}>
                {t}
              </div>
              <div style={{ fontSize: 11, color: "#555567", lineHeight: 1.55 }}>{b}</div>
            </div>
          ))}
        </div>

        <hr />

        <h2 className="section-title">Security & Governance <em>Overview</em></h2>
        <p className="section-body">
          A governed AI layer is maintained across the GoContact platform, supporting secure data
          handling, structured risk management, ongoing monitoring, and continuous improvement.
          Controls are designed to ensure systems operate predictably, within defined boundaries, and
          in alignment with enterprise security and compliance expectations, while maintaining clear
          separation of responsibilities between Broadvoice and the customer.
        </p>

        <p className="closing-line">
          Secure by design.<br />
          Governed by default.<br />
          AI is how trust scales with intelligence.
        </p>

        <div className="about-section" style={{ position: "static", marginTop: 18, maxWidth: "100%" }}>
          <h3 className="about-title">About Broadvoice</h3>
          <p className="about-body">
            Broadvoice delivers intelligent CX solutions for midmarket organizations—empowering
            business teams to design modern, frictionless customer experiences with AI that's
            practical, easy to use, and purpose-built for how they work.
          </p>
          <p className="about-addon" style={{ marginTop: 12 }}>
            AI powers the AI layer across GoContact, Engage, and GoInsights.
          </p>
        </div>

        <PageFooter />
      </div>
    </div>
  );
};

export default AISecuritySheet;
