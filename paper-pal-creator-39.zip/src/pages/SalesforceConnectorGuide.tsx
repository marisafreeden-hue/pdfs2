import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>GoContact CTI Plugin for Salesforce · Installation Guide</div>
    <div>© Broadvoice 2026</div>
  </div>
);

const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}
  </h2>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Ordered: React.FC<{ items: React.ReactNode[]; start?: number }> = ({ items, start }) => (
  <ol
    start={start}
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.65,
      paddingLeft: 22,
      margin: "6px 0 10px",
      listStyleType: "decimal",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 3 }}>
        {it}
      </li>
    ))}
  </ol>
);

const Callout: React.FC<{ children: React.ReactNode; tone?: "info" | "warn" }> = ({
  children,
  tone = "info",
}) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: tone === "warn" ? "#8a4a00" : "#1A1A2E",
      background: tone === "warn" ? "#FFF6E5" : "#EEF7F8",
      borderLeft: `3px solid ${tone === "warn" ? "#D97706" : "#43B5BF"}`,
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const StepCard: React.FC<{ num: string; title: string; children: React.ReactNode }> = ({
  num,
  title,
  children,
}) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      padding: "14px 18px 10px",
      marginBottom: 14,
      background: "#FFFFFF",
    }}
  >
    <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 4 }}>
      <span
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 10,
          fontWeight: 700,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "#43B5BF",
        }}
      >
        Step {num}
      </span>
    </div>
    <h2
      className="section-title"
      style={{ fontSize: 19, margin: "0 0 6px", lineHeight: 1.2, display: "block" }}
    >
      {title}
    </h2>
    {children}
  </div>
);

const ImageSlot: React.FC<{ height?: number }> = ({ height = 150 }) => (
  <div
    style={{
      width: "100%",
      height,
      background: "#FFFFFF",
      margin: "8px 0 12px",
    }}
  />
);

const ConfigTable: React.FC<{ rows: [string, React.ReactNode][] }> = ({ rows }) => (
  <div
    className="rounded-table"
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      overflow: "hidden",
      margin: "8px 0 12px",
    }}
  >
    <table
      style={{
        width: "100%",
        borderCollapse: "collapse",
        fontFamily: "'Inter', sans-serif",
        fontSize: 10.5,
        tableLayout: "fixed",
      }}
    >
      <colgroup>
        <col style={{ width: "38%" }} />
        <col style={{ width: "62%" }} />
      </colgroup>
      <thead>
        <tr style={{ background: "#F3F3F8" }}>
          {["Setting", "Value"].map((h) => (
            <th
              key={h}
              style={{
                padding: "9px 12px",
                textAlign: "left",
                fontSize: 10,
                fontWeight: 700,
                letterSpacing: "0.07em",
                textTransform: "uppercase",
                color: "#555567",
                borderBottom: "2px solid #E2E2EC",
              }}
            >
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map(([f, v], i) => (
          <tr key={i} style={{ background: i % 2 === 0 ? "#FFFFFF" : "#FAFAFA" }}>
            <td
              style={{
                padding: "10px 12px",
                color: "#1A1A2E",
                fontWeight: 700,
                borderBottom: i === rows.length - 1 ? "none" : "1px solid #E2E2EC",
                verticalAlign: "top",
                lineHeight: 1.45,
              }}
            >
              {f}
            </td>
            <td
              style={{
                padding: "10px 12px",
                color: "#555567",
                borderBottom: i === rows.length - 1 ? "none" : "1px solid #E2E2EC",
                verticalAlign: "top",
                lineHeight: 1.45,
              }}
            >
              {v}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

const SalesforceConnectorGuide: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
        .rounded-table table { margin: 0 !important; }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 – Cover & Table of Contents ===== */}
      <div className="page">
        <PageHeader eyebrow="Installation Guide" />

        <div className="partner-hero" style={{ marginTop: 40, marginBottom: 10 }}>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "#43B5BF",
              marginBottom: 10,
            }}
          >
            GoContact CTI Plugin for Salesforce
          </div>
          <h1
            className="hero-headline"
            style={{ fontSize: 38, lineHeight: 1.05, marginBottom: 6 }}
          >
            Broadvoice Salesforce <em>Connector</em>
          </h1>
          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Installation and configuration steps for the GoContact CTI Plugin inside
            Salesforce.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />

        <PageBody>
          <div style={{ height: 14 }} />
          <SectionTitle>Contents</SectionTitle>
          <Body>
            A quick map of the installation and troubleshooting steps covered in this guide.
          </Body>

          <div style={{ marginTop: 10 }}>
            {[
              { num: "01", title: "Create Your Salesforce Environment", desc: "Register a developer sandbox and set language preferences.", page: "02" },
              { num: "02", title: "Access Salesforce AppExchange", desc: "Open AppExchange to locate the GoContact package.", page: "03" },
              { num: "03", title: "Install the GoContact Package", desc: "Install the managed package into your Salesforce org.", page: "03" },
              { num: "04", title: "Configure the GoContact Call Center", desc: "Sign in to AppExchange and set up the Call Center.", page: "04" },
              { num: "05", title: "Configure the Softphone Layout", desc: "Define the softphone layout for your users.", page: "05" },
              { num: "06", title: "Create the Lightning App", desc: "Build the Lightning App that hosts the connector.", page: "06" },
              { num: "07", title: "Add the Utility Bar", desc: "Surface the GoContact softphone in the utility bar.", page: "07" },
              { num: "08", title: "Configure Navigation Items", desc: "Add the required navigation items to the app.", page: "07" },
              { num: "09", title: "Assign User Profiles", desc: "Grant access to the appropriate Salesforce profiles.", page: "08" },
              { num: "10", title: "Launch the Connector", desc: "Verify the app is available to end users.", page: "08" },
              { num: "11", title: "Login & First-Use Validation", desc: "Sign in to GoContact and confirm CTI behavior.", page: "09" },
              { num: "12", title: "Configure a Campaign", desc: "Set up an initial outbound campaign for testing.", page: "09" },
              { num: "—", title: "Troubleshooting · CSP & Trusted URLs", desc: "Resolve common CSP and Trusted URL issues.", page: "10" },
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  gap: 14,
                  padding: "8px 0",
                  borderBottom: "1px solid #E2E2EC",
                }}
              >
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 12,
                      fontWeight: 700,
                      color: "#1A1A2E",
                      lineHeight: 1.3,
                    }}
                  >
                    {item.title}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 10.5,
                      color: "#888899",
                      marginTop: 2,
                      lineHeight: 1.4,
                    }}
                  >
                    {item.desc}
                  </div>
                </div>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 11,
                    fontWeight: 700,
                    color: "#27698F",
                    flex: "0 0 auto",
                    letterSpacing: "0.08em",
                  }}
                >
                  p. {item.page}
                </span>
              </div>
            ))}
          </div>
        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – Step 1 ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 1 · Create Your Salesforce Environment" />
        <PageBody>
          <div style={{ height: 30 }} />

          <StepCard num="1" title="Create Your Salesforce Environment">
            <Ordered
              items={[
                <>
                  Access the Salesforce Developer registration page:{" "}
                  <span style={{ wordBreak: "break-all", color: "#27698F" }}>
                    https://www.salesforce.com/products/free-trial/developer/
                  </span>
                </>,
                <>
                  Complete the required fields and click <strong>"Sign me up"</strong>.
                </>,
                <>
                  You will receive an email containing a link to your Sandbox
                  environment (save this link) and your Salesforce username.
                </>,
                <>
                  Click <strong>"Verify Account"</strong>.
                </>,
                "Create your password when prompted.",
                "Log in to Salesforce.",
              ]}
            />
            <ImageSlot />
          </StepCard>

          <StepCard num="1a" title="Recommended: Change the Salesforce Language to English">
            <Ordered
              items={[
                "Click your profile image.",
                <>
                  Select <strong>"Settings"</strong>.
                </>,
                <>
                  Choose <strong>"Language & Time Zone"</strong>.
                </>,
                <>
                  Change the language to <strong>English</strong> and save your changes.
                </>,
              ]}
            />

            <ImageSlot />
          </StepCard>
        </PageBody>

        <PageFooter />
      </div>


      {/* ===== PAGE 2 – Steps 2 & 3 ===== */}
      <div className="page">
        <PageHeader eyebrow="Steps 2 – 3 · AppExchange & Package Install" />
        <PageBody>
          <div style={{ height: 30 }} />

          <StepCard num="2" title="Access Salesforce AppExchange">
            <Ordered
              items={[
                <>
                  In the Setup search field on the left, type{" "}
                  <strong>"AppExchange"</strong>.
                </>,
                <>
                  Click <strong>"AppExchange Marketplace"</strong>.
                </>,
              ]}
            />
            <ImageSlot />
            <Ordered
              start={3}
              items={[
                <>
                  Click <strong>"Go To AppExchange"</strong>.
                </>,
              ]}
            />
            <ImageSlot />
          </StepCard>

          <StepCard num="3" title="Locate and Install the GoContact Package">
            <Ordered
              items={[
                <>
                  In AppExchange, search for <strong>"GoContact"</strong>.
                </>,
                <>
                  Select <strong>"GoContact CTI Plugin for Salesforce"</strong>.
                </>,
                <>
                  Click <strong>"Get it Now"</strong>.
                </>,
              ]}
            />
            <ImageSlot />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 3 – Sign in to AppExchange & Step 4 ===== */}
      <div className="page">
        <PageHeader eyebrow="Sign In & Call Center Configuration" />
        <PageBody>
          <div style={{ height: 30 }} />

          <SectionTitle>Sign In to AppExchange</SectionTitle>
          <Ordered
            items={[
              <>
                Click <strong>"Log In"</strong>.
              </>,
            ]}
          />
          <ImageSlot height={120} />
          <Ordered
            start={2}
            items={[
              <>
                Select <strong>"Salesforce"</strong> as the login method.
              </>,
            ]}
          />
          <ImageSlot height={120} />
          <Ordered
            start={3}
            items={[
              "Log in with your Salesforce credentials.",
              <>
                Click <strong>"Allow"</strong>.
              </>,
            ]}
          />

          <div style={{ height: 12 }} />

          <StepCard num="4" title="Configure the GoContact Call Center">
            <Ordered
              items={[
                <>
                  Click the <strong>gear (cogwheel)</strong> icon.
                </>,
                <>
                  Select <strong>"Setup"</strong>.
                </>,
              ]}
            />
            <Callout tone="warn">
              <strong>Important:</strong> Do not select <strong>"Service Setup"</strong>.
            </Callout>
            <Ordered
              start={3}
              items={[
                <>
                  Search for <strong>"Call Center"</strong>.
                </>,
                <>
                  Select <strong>"Call Centers"</strong>.
                </>,
                <>
                  Click <strong>"Confirm"</strong>.
                </>,
                <>
                  Locate <strong>"GoContact CTI"</strong> and click{" "}
                  <strong>"Edit"</strong>.
                </>,
              ]}
            />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 4 – Step 4 cont. & Step 5 ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 4 (cont.) & Step 5 · Softphone Layout" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>Configure the GoContact Call Center (cont.)</SectionTitle>
          <ImageSlot />
          <Callout tone="warn">
            <strong>Important:</strong> In the <strong>"CTI Adapter URL"</strong> field,
            enter the plugin URL corresponding to the cloud environment you are using.
          </Callout>
          <Ordered
            start={7}
            items={[
              <>
                Click <strong>"Save"</strong>.
              </>,
              <>
                Click <strong>"Manage Call Center Users"</strong>.
              </>,
            ]}
          />
          <ImageSlot />
          <Ordered
            start={9}
            items={[
              <>
                Click <strong>"Add More Users"</strong>.
              </>,
            ]}
          />

          <div style={{ height: 14 }} />

          <StepCard num="5" title="Create the Softphone Layout">
            <Ordered
              items={[
                <>
                  Search for <strong>"Softphone Layout"</strong>.
                </>,
                <>
                  Select <strong>"Softphone Layouts"</strong>.
                </>,
                <>
                  Click <strong>"New"</strong>.
                </>,
                <>
                  Enter <strong>"Go_CTI"</strong> as the name.
                </>,
                <>
                  Select <strong>"Default"</strong>.
                </>,
                "Configure the layout according to the requirements shown in the guide.",
              ]}
            />
            <ImageSlot />
            <Ordered
              start={7}
              items={[
                <>
                  Click <strong>"Save"</strong>.
                </>,
              ]}
            />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Step 6 Lightning App ===== */}
      <div className="page">
        <PageHeader eyebrow="Step 6 · Lightning App" />
        <PageBody>
          <div style={{ height: 30 }} />

          <StepCard num="6" title="Create the Lightning App">
            <Ordered
              items={[
                <>
                  Search for <strong>"App Manager"</strong>.
                </>,
                <>
                  Click <strong>"New Lightning App"</strong>.
                </>,
                <>
                  Complete the application details using:
                  <ul style={{ margin: "4px 0 0 0", paddingLeft: 18 }}>
                    <li>
                      GoContact Logo:{" "}
                      <span style={{ color: "#27698F" }}>https://bit.ly/36QwCTa</span>
                    </li>
                    <li>
                      Hex Color: <strong>#1d78ad</strong>
                    </li>
                  </ul>
                </>,
              ]}
            />
            <ImageSlot />
            <Ordered
              start={4}
              items={[
                <>
                  Click <strong>"Next"</strong>.
                </>,
              ]}
            />
            <SubHead>Configure the following settings exactly</SubHead>
            <ConfigTable
              rows={[
                ["Navigation Style", "Console Navigation"],
                ["Supported Form Factors", "Desktop"],
                ["Setup Experience", "Setup (full set of Setup options)"],
                [
                  "App Personalization Settings",
                  "Disable end user personalization of nav items in this app",
                ],
              ]}
            />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 – Steps 7 & 8 ===== */}
      <div className="page">
        <PageHeader eyebrow="Steps 7 – 8 · Utility Bar & Navigation" />
        <PageBody>
          <div style={{ height: 30 }} />

          <StepCard num="7" title="Configure the Utility Bar">
            <Ordered
              items={[
                <>
                  Click <strong>"Add Utility Item"</strong>.
                </>,
                <>
                  Select <strong>"Open CTI Softphone"</strong>.
                </>,
              ]}
            />
            <ImageSlot />
            <Ordered
              start={3}
              items={[
                "Configure the settings exactly as shown.",
                <>
                  Click <strong>"Next"</strong>.
                </>,
              ]}
            />
          </StepCard>

          <StepCard num="8" title="Add Navigation Items">
            <Ordered
              items={[
                <>
                  Add: <strong>Accounts</strong>, <strong>Cases</strong>,{" "}
                  <strong>Contacts</strong>.
                </>,
                "Configure each item according to the screenshots provided.",
              ]}
            />
            <ImageSlot height={110} />
            <ImageSlot height={110} />
            <ImageSlot height={110} />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 – Steps 9 & 10 ===== */}
      <div className="page">
        <PageHeader eyebrow="Steps 9 – 10 · User Profiles & Launch" />
        <PageBody>
          <div style={{ height: 30 }} />

          <StepCard num="9" title="Assign User Profiles">
            <Ordered
              items={[
                <>
                  Add all required <strong>"User Profiles"</strong>.
                </>,
              ]}
            />
            <ImageSlot />
            <Ordered
              start={2}
              items={["Complete the Lightning App setup process."]}
            />
          </StepCard>

          <StepCard num="10" title="Launch the GoContact CTI Plugin">
            <Ordered
              items={[
                <>
                  Click the <strong>App Launcher</strong> (nine dots).
                </>,
                <>
                  Select <strong>"View All"</strong>.
                </>,
                <>
                  Open <strong>"GoContact – CTI Plugin"</strong>.
                </>,
              ]}
            />
            <ImageSlot />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 8 – Steps 11 & 12 ===== */}
      <div className="page">
        <PageHeader eyebrow="Steps 11 – 12 · Login & Campaign" />
        <PageBody>
          <div style={{ height: 30 }} />

          <StepCard num="11" title="Log In to GoContact">
            <Ordered
              items={[
                <>
                  Click <strong>"Phone"</strong> in the bottom-left corner.
                </>,
              ]}
            />
            <ImageSlot height={120} />
            <Ordered
              start={2}
              items={[
                "Enter your platform credentials and extension information.",
                <>
                  Click <strong>"Login"</strong>.
                </>,
              ]}
            />
            <ImageSlot height={120} />
          </StepCard>

          <StepCard num="12" title="Select Your Campaign and Queue">
            <Ordered
              items={[
                <>
                  Select the desired <strong>Outbound Campaign</strong>.
                </>,
                <>
                  Select the desired <strong>Inbound Queue</strong>.
                </>,
                <>
                  Click <strong>"Submit"</strong>.
                </>,
              ]}
            />
            <ImageSlot height={130} />
            <Callout>
              The GoContact CTI Plugin is now configured and ready to use.
            </Callout>
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 9 – Troubleshooting ===== */}
      <div className="page">
        <PageHeader eyebrow="Troubleshooting · CSP & Trusted URLs" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle>Troubleshooting</SectionTitle>
          <SubHead>Content Security Policy / Trusted URLs</SubHead>
          <Body>
            If the GoContact plugin does not load and the following error appears, review
            the <strong>Content Security Policy (CSP)</strong> and{" "}
            <strong>Trusted URL</strong> settings in Salesforce.
          </Body>
          <ImageSlot height={120} />
          <Body>
            Navigate to <strong>Setup</strong> and use one of the following options.
          </Body>

          <StepCard num="A" title="Option 1 · Update Session Settings">
            <Ordered
              items={[
                <>
                  Search for <strong>"Session Settings"</strong>.
                </>,
                <>
                  Click <strong>"Session Settings"</strong>.
                </>,
                <>
                  Locate the{" "}
                  <strong>"Content Security Policy (CSP) Directive Rendering"</strong>{" "}
                  section.
                </>,
                <>
                  Disable <strong>"Adopt updated CSP directives"</strong>.
                </>,
                "Save your changes.",
              ]}
            />
            <ImageSlot height={120} />
          </StepCard>

        </PageBody>
        <PageFooter />
      </div>


      {/* ===== PAGE 10 – Troubleshooting Option 2 ===== */}
      <div className="page">
        <PageHeader eyebrow="Troubleshooting · Trusted URLs" />
        <PageBody>
          <div style={{ height: 30 }} />
          <StepCard num="B" title="Option 2 · Add a Trusted URL">
            <Ordered
              items={[
                <>
                  Search for <strong>"Trusted URLs"</strong>.
                </>,
                <>
                  Click <strong>"Trusted URLs"</strong>.
                </>,
                <>
                  Click <strong>"New Trusted URL"</strong>.
                </>,
                "Add the cloud URL.",
                <>
                  Activate all <strong>CSP Directives (Content Security Policy)</strong>{" "}
                  options.
                </>,
                "Save your changes.",
              ]}
            />
            <ImageSlot height={140} />
          </StepCard>
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default SalesforceConnectorGuide;
