import React from "react";
import { Target, Users, TrendingUp, Calendar, ClipboardList, Network, BookOpen, Briefcase, Compass, Brain, BarChart3, Trophy, GraduationCap, Clock, CheckCircle2, ExternalLink } from "lucide-react";
import "./GoEngageDatasheet.css";
import "./ImplementationTaskforce.css";

const PageHeader = () => (
  <div className="tf-page-header">
    <span className="tf-header-left">BROADVOICE | Channel Manager Success Guide</span>
    <span className="tf-header-right">REV. MAY 2026</span>
  </div>
);

const PageFooterText = ({ pageNum }: { pageNum: number }) => (
  <div className="tf-page-footer-text">
    <span>Confidential – Internal Use Only</span>
    <span>Page {pageNum}</span>
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const SectionLabel = ({ number, label }: { number: number; label?: string }) => (
  <div className="tf-section-label">{label ? `SECTION ${number} · ${label}` : `SECTION ${number}`}</div>
);

// Reusable pillar card
type PillarProps = { Icon: React.ComponentType<any>; title: string; items: React.ReactNode[] };
const PillarCard: React.FC<PillarProps> = ({ Icon, title, items }) => (
  <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px", background: "#FFFFFF" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
      <Icon size={16} style={{ stroke: "url(#cm-icon-grad)" }} />
      <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 700, color: "#1A1A2E" }}>{title}</div>
    </div>
    <ul style={{ margin: 0, paddingLeft: 16, listStyle: "disc" }}>
      {items.map((it, i) => (
        <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 4, fontFamily: "'Inter', sans-serif" }}>{it}</li>
      ))}
    </ul>
  </div>
);

const IconDefs = () => (
  <svg width="0" height="0" style={{ position: "absolute" }}>
    <defs>
      <linearGradient id="cm-icon-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#43B5BF" />
        <stop offset="100%" stopColor="#27698F" />
      </linearGradient>
    </defs>
  </svg>
);

const ChannelManagerPlaybook: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper tf-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>
      <IconDefs />

      {/* ===== PAGE 1: Cover + Purpose ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="tf-cover-content">
          <h1 className="hero-headline">
            Channel Manager<br /><em>Success Guide</em>
          </h1>
          <div className="tf-cover-subtitle">The standard for activating partners<br />and driving CCaaS-led growth</div>
        </div>

        <div className="outcomes-container" style={{ marginTop: 24 }}>
          <table className="outcomes-table tf-cover-table">
            <tbody>
              <tr><td className="tf-meta-label">Document</td><td>Channel Manager Success Guide</td></tr>
              <tr><td className="tf-meta-label">Revision</td><td>May 2026</td></tr>
              <tr><td className="tf-meta-label">Audience</td><td>Channel Managers</td></tr>
              <tr><td className="tf-meta-label">Classification</td><td>Confidential – Internal Use Only</td></tr>
              <tr><td className="tf-meta-label">Owner</td><td>Broadvoice Channel Sales Leadership</td></tr>
            </tbody>
          </table>
        </div>

        <hr />

        <SectionLabel number={1} label="PURPOSE" />
        <h2 className="section-title">Purpose & <em>Standard of Excellence</em></h2>

        <p className="section-body tf-body-wide">
          This Success Guide serves as the standard for Channel Manager success at Broadvoice. It outlines the mindset, behaviors, and execution required to activate the right partners, build predictable funnels, and drive strategic, CCaaS-led revenue growth. This playbook is not a checklist — it's a standard of excellence.
        </p>

        <p className="section-body tf-body-wide">
          A successful Channel Manager operates like a business owner and trusted business consultant, not a transactional seller. Success is driven by focus, disciplined execution, strong enablement, co-selling rigor, and measurable outcomes. The role requires balancing strategy, partner relationships, and daily revenue generating activity, while continuously developing expertise in UCaaS / CCaaS / CX and market trends.
        </p>

        <div className="closing-line" style={{ marginTop: 18 }}>
          Operate like an owner. Lead with insight. Win through partners.
        </div>

        <PageFooterText pageNum={1} />
        <PageFooter />
      </div>

      {/* ===== PAGE 2: Foundation & Mindset ===== */}
      <div className="page page-2">
        <PageHeader />
        <SectionLabel number={2} label="FOUNDATION" />
        <h2 className="section-title">Foundation & <em>Mindset</em></h2>
        <p className="section-body tf-body-wide">
          The four anchors that separate transactional sellers from trusted business consultants.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 8 }}>
          <PillarCard
            Icon={Briefcase}
            title="Own Your Business"
            items={[
              "Treat your territory like your own Broadvoice franchise.",
              "Build and execute a clear plan for growth, coverage and revenue.",
              "Be accountable for partner success and outcomes.",
            ]}
          />
          <PillarCard
            Icon={Brain}
            title="Operate with a Consultative Mindset"
            items={[
              "Shift from product pitching to solution positioning.",
              "Lead with discovery & business outcomes — uncover challenges, workflows & goals.",
              "Position yourself as a Trusted Business Consultant/Coach, not just another Channel Manager.",
            ]}
          />
          <PillarCard
            Icon={Compass}
            title="Understand the UCaaS / CCaaS / CX Landscape"
            items={[
              "Know key competitors, trends, and differentiators in your region.",
              "Stay current on evolving expectations: omnichannel, AI, integrations.",
              "Understand buyer personas: IT leaders, Contact Center leaders, CX execs.",
            ]}
          />
          <PillarCard
            Icon={Target}
            title="Be a Solutions Expert"
            items={[
              "Know your UCaaS / CCaaS / CX capabilities end-to-end.",
              "Stay current on roadmap and product releases.",
              "Communicate value in business terms.",
              "Know when to bring in technical or specialist support.",
            ]}
          />
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={3} label="PARTNER ENGAGEMENT" />
          <h2 className="section-title">Partner Engagement & <em>Enablement</em></h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 6 }}>
          <PillarCard
            Icon={Users}
            title="Segment & Prioritize"
            items={[
              "Identify Top 25 high-potential partners within your IPP.",
              "Apply a tiered engagement model to all IPP partners.",
              "Align time and cadence to partner tiers.",
            ]}
          />
          <PillarCard
            Icon={GraduationCap}
            title="Educate & Empower"
            items={[
              "Deliver tailored enablement: webinars, playbooks, cheat sheets, demos.",
              "Train partners on qualification, positioning and value messaging.",
              "Leverage CX Strategist for onboarding and enablement.",
              "Share wins, use cases, and success stories.",
            ]}
          />
          <PillarCard
            Icon={Network}
            title="Co-Sell & Co-Market"
            items={[
              "Join Top 25 partner calls to support discovery and solutioning.",
              "Use MDF for targeted, measurable campaigns.",
              "Collaborate on events, webinars, and vertical initiatives.",
            ]}
          />
        </div>

        <PageFooterText pageNum={2} />
        <PageFooter />
      </div>

      {/* ===== PAGE 3: Sales Execution + Metrics ===== */}
      <div className="page page-3">
        <PageHeader />
        <SectionLabel number={4} label="EXECUTION" />
        <h2 className="section-title">Sales Execution & <em>Funnel Management</em></h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 8 }}>
          <PillarCard
            Icon={TrendingUp}
            title="Build & Manage a Healthy Funnel"
            items={[
              "Focus IPP Partners on Ideal Customer Profile opportunities.",
              "Track partner activity, funnel, and conversion in Salesforce.",
              "Maintain accurate forecast by validating deal quality and timelines.",
              "Conduct account mapping for existing and target customers.",
              "Celebrate wins and analyze losses for continuous improvement.",
            ]}
          />
          <PillarCard
            Icon={Target}
            title="Accelerate Deal Velocity"
            items={[
              "Provide fast access to sales engineers, demos, and pricing.",
              "Help partners navigate procurement, legal, and onboarding hurdles.",
              "Use SPIFFs and incentives to drive urgency and momentum.",
            ]}
          />
        </div>

        <div style={{ marginTop: 18 }}>
          <SectionLabel number={5} label="METRICS & CULTURE" />
          <h2 className="section-title">Metrics, Culture & <em>Growth</em></h2>
        </div>

        <div style={{ border: "1px solid #D0E8EA", borderRadius: 10, padding: "14px 16px", background: "rgba(67,181,191,0.04)", marginTop: 6 }}>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>KPIs That Matter</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
            {[
              { k: "ASP", v: "Active Selling IPP Partners" },
              { k: "Recruit & Onboard", v: "New IPP Partners added" },
              { k: "7×", v: "ICP funnel growth minimum vs. quota" },
              { k: "ICP", v: "Bookings & Revenue activated" },
              { k: "CCaaS Mix", v: "Higher MRC, strategic deals" },
              { k: "Deal Math", v: "Avg. deal size & sales cycle to quota" },
            ].map((s, i) => (
              <div key={i} style={{ background: "#FFFFFF", border: "1px solid #E2E2EC", borderRadius: 8, padding: "10px 12px" }}>
                <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 16, fontWeight: 500, background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", lineHeight: 1.1, marginBottom: 2 }}>{s.k}</div>
                <div style={{ fontSize: 10, color: "#555567", lineHeight: 1.4, fontFamily: "'Inter', sans-serif" }}>{s.v}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
          <PillarCard
            Icon={Trophy}
            title="Foster a Winning Culture"
            items={[
              "Celebrate partner and internal wins.",
              "Share best practices across the team.",
              "Be a culture carrier: positive, proactive, collaborative.",
            ]}
          />
          <PillarCard
            Icon={BookOpen}
            title="Commit to Continuous Learning"
            items={[
              "Attend industry events and webinars.",
              "Subscribe to thought leadership.",
              "Seek and provide mentorship.",
              "Block dedicated time for learning.",
            ]}
          />
        </div>

        <PageFooterText pageNum={3} />
        <PageFooter />
      </div>

      {/* ===== PAGE 4: Organization & Planning ===== */}
      <div className="page page-4">
        <PageHeader />
        <SectionLabel number={6} label="OPERATING RHYTHM" />
        <h2 className="section-title">Organization & <em>Planning for Success</em></h2>
        <p className="section-body tf-body-wide">
          Being organized and intentional with your time is critical. Run a deliberate daily, weekly, and monthly cadence to stay focused, proactive, and aligned to goals.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginTop: 6 }}>
          <PillarCard
            Icon={Clock}
            title="Daily Method of Operation"
            items={[
              "15-min planning session to start or end the day.",
              "Identify Top 3–5 revenue-impacting priorities.",
              "Prep meetings in advance — always have an agenda.",
              "Review Salesforce Dashboard each morning.",
              "24-hour SLA on partner requests.",
              "2+ strategy calls with partners per day.",
              "Attend industry webinars or networking events.",
              "Log activities and update deal stages in Salesforce — if it's not in Salesforce, it didn't happen.",
            ]}
          />
          <PillarCard
            Icon={Calendar}
            title="Weekly Planning"
            items={[
              "3–5 partner enablement sessions (recruit, onboard, win-back).",
              "Review funnel health and forecast accuracy.",
              "POD and internal cadence calls.",
              "10+ strategic partner check-ins per week.",
              "Share product updates or marketing assets.",
              "Analyze deal progress and remove blockers.",
            ]}
          />
          <PillarCard
            Icon={ClipboardList}
            title="Monthly Planning"
            items={[
              "Recruit & onboard IPP partners.",
              "5+ Quarterly Business Reviews (QBRs).",
              "Evaluate partner performance, engagement, tiering.",
              "Plan joint marketing / co-sell campaigns & events.",
              "TSD: 3+ cadence calls; Top Partners: 25+ monthly.",
              "Monthly newsletters on tech & incentives.",
              "Dedicate 1 week in-field — get out from behind your desk.",
            ]}
          />
        </div>

        <div style={{ border: "1px solid #43B5BF", padding: "12px 16px", background: "rgba(67,181,191,0.04)", borderRadius: 8, marginTop: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <CheckCircle2 size={14} style={{ stroke: "url(#cm-icon-grad)" }} />
            <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Time Management & Salesforce Hygiene</div>
          </div>
          <ul style={{ margin: 0, paddingLeft: 18, listStyle: "disc" }}>
            {[
              "Time-block to protect focus time for strategic work — don't ignore it.",
              "Prioritize high-impact, money-making activities.",
              "Prioritize top IPP partners (A, B, C).",
              "Keep Salesforce updated with notes, next steps, accurate deal stages.",
              "Set reminders for follow-ups and partner check-ins.",
            ].map((t, i) => (
              <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>{t}</li>
            ))}
          </ul>
        </div>

        <PageFooterText pageNum={4} />
        <PageFooter />
      </div>

      {/* ===== PAGE 5: Preparation tasks ===== */}
      <div className="page page-5">
        <PageHeader />
        <SectionLabel number={7} label="SAMPLE PLAN" />
        <h2 className="section-title">Sample <em>Preparation Tasks</em></h2>

        <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 14, marginTop: 8 }}>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
            <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>Territory & Partner Setup</div>
            <ul style={{ margin: 0, paddingLeft: 18, listStyle: "disc" }}>
              {[
                "Review territory, partner base, and existing funnel.",
                "Identify Top 25 high-potential partners within your IPP.",
                "Map partner engagement cadence by tier — weekly, bi-weekly, monthly touchpoints.",
                "Calendar-block daily DMO activities and weekly partner enablement slots.",
                "Calendar-block monthly QBR windows and monthly partner visits.",
                "Calendar-block recruiting & onboarding partner time and funnel creation.",
                "Calendar-block strategy planning with your CX Strategist, Sales Leader, and TSD contacts.",
              ].map((t, i) => <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 4, fontFamily: "'Inter', sans-serif" }}>{t}</li>)}
            </ul>

            <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
              {[
                { tier: "Tier A", desc: "Strong expertise, established CCaaS practice, strong deal velocity." },
                { tier: "Tier B", desc: "Growing expertise, expanding CCaaS business, moderate deal flow." },
                { tier: "Tier C", desc: "Developing CCaaS base, heavy sales support, light deal flow." },
              ].map((t, i) => (
                <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "8px 10px", background: "#FAFAFA" }}>
                  <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 14, fontWeight: 500, background: "linear-gradient(90deg, #43B5BF, #27698F)", WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent" }}>{t.tier}</div>
                  <div style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.45, fontFamily: "'Inter', sans-serif", marginTop: 2 }}>{t.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <PillarCard
              Icon={TrendingUp}
              title="Other Ideas for Success"
              items={[
                "Provide one piece of value to every partner touched (training invite, playbook, white paper, talk track, etc.).",
                "LinkedIn outreach and networking groups.",
                "Align with non-competing suppliers.",
                "Business planning with TSD Regionals.",
                "Leverage leadership intros for broader market support.",
              ]}
            />
            <div style={{ border: "1px solid #43B5BF", padding: "12px 14px", background: "rgba(67,181,191,0.04)", borderRadius: 8 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 6 }}>Reminders</div>
              <ul style={{ margin: 0, paddingLeft: 18, listStyle: "disc" }}>
                {[
                  "Be consultative, not transactional.",
                  "Lead with discovery questions.",
                  "Build trust through education and transparency.",
                  "Focus time and resources where ROI is highest.",
                ].map((t, i) => <li key={i} style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>{t}</li>)}
              </ul>
            </div>
          </div>
        </div>

        <PageFooterText pageNum={5} />
        <PageFooter />
      </div>

      {/* ===== PAGE 6: Time Prioritization tables ===== */}
      <div className="page page-6">
        <PageHeader />
        <SectionLabel number={8} label="TIME PRIORITIZATION" />
        <h2 className="section-title">Sample <em>Time Prioritization</em></h2>

        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginTop: 8, marginBottom: 6 }}>Daily</div>
        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr><th>Type</th><th>Goal</th><th>Purpose</th></tr>
            </thead>
            <tbody>
              <tr><td>Phone Calls / Text</td><td>5+ per day (mix of new & existing partners)</td><td>Relationship building, business planning</td></tr>
              <tr><td>Emails / LinkedIn</td><td>5–10 per day</td><td>Templates + personalization</td></tr>
              <tr><td>Partner Meetings</td><td>1–2 per day</td><td>Onboarding, training, co-success</td></tr>
              <tr><td>Follow-Up Sequences</td><td>Keep momentum on action items & deliverables</td><td>Fortune is in the follow-up.</td></tr>
            </tbody>
          </table>
        </div>

        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginTop: 16, marginBottom: 6 }}>Weekly</div>
        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr><th>Day</th><th>Focus Area</th></tr>
            </thead>
            <tbody>
              <tr><td>Monday</td><td>Prioritize key partners, review pipeline, plan trainings or events.</td></tr>
              <tr><td>Tuesday</td><td>Prospecting-focused day (new agents, new outreach via LinkedIn).</td></tr>
              <tr><td>Wednesday</td><td>Partner enablement (webinars, content drops, toolkits).</td></tr>
              <tr><td>Thursday</td><td>Revenue-focused day (QBRs, proposals, pipeline calls).</td></tr>
              <tr><td>Friday</td><td>Follow-up, reporting, deal registration, team syncs, TSD cadence meetings.</td></tr>
            </tbody>
          </table>
        </div>

        <PageFooterText pageNum={6} />
        <PageFooter />
      </div>

      {/* ===== PAGE 7: Cross-Functional Collaboration ===== */}
      <div className="page page-7">
        <PageHeader />
        <SectionLabel number={9} label="COLLABORATION" />
        <h2 className="section-title">Cross-Functional <em>Collaboration</em></h2>
        <p className="section-body tf-body-wide">
          Channel Managers win as part of a system. Here's how each function shows up to drive partner-led growth.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 6 }}>
          <PillarCard
            Icon={Users}
            title="Partner Sales Manager (PSM)"
            items={[
              "Primary execution arm for Channel Manager support.",
              "Owns administrative enablement: quoting, discounts, follow-ups, agreements.",
              "Develops and manages strong subagent relationships.",
              "Manages all partners outside the IPP.",
            ]}
          />
          <PillarCard
            Icon={Target}
            title="Sales Engineering (SE)"
            items={[
              "Enables CM success through onboarding, product expertise, and technical support.",
              "Drives customer meetings and demos to advance opportunities.",
              "Independently progresses $500+ MRR subagent opportunities.",
              "Maintains active cadence with regional TSD Sales Engineers.",
              "Contributes to regional alignment via team meetings and updates.",
            ]}
          />
          <PillarCard
            Icon={BarChart3}
            title="Sales Operations"
            items={[
              "Provides clear, actionable reporting tied to quota attainment.",
              "Optimizes subagent onboarding to scale productivity: updated checklists, enhanced training, refreshed marketing assets.",
              "Ensures timely execution of reporting and discount requests.",
            ]}
          />
          <PillarCard
            Icon={Network}
            title="Strategic Relationships"
            items={[
              "Partners with Director of TSDs to define and execute TSD engagement strategy.",
              "Facilitates two-way communication with TSD product and SE leadership.",
              "Delivers structured post-event insights (feedback, follow-up, CX vs. UC outcomes).",
              "Actively manages underperforming TSD regions with consistent cadence.",
            ]}
          />
        </div>

        <PageFooterText pageNum={7} />
        <PageFooter />
      </div>

      {/* ===== PAGE 8: Resources ===== */}
      <div className="page page-8">
        <PageHeader />
        <SectionLabel number={10} label="RESOURCES" />
        <h2 className="section-title">Resources & <em>Quick Links</em></h2>
        <p className="section-body tf-body-wide">
          Everything you need to operate at the standard — checklists, enablement, playbooks, and platforms.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 8 }}>
          {[
            {
              title: "Channel Manager Launch Readiness Checklist",
              desc: "The onboarding standard for every new Channel Manager.",
              href: "https://broadvoice-my.sharepoint.com/:w:/r/personal/mollyl_broadvoice_com/_layouts/15/Doc.aspx?sourcedoc=%7BD5713EF4-ADE3-434B-8DF3-0F293BAEEF0A%7D&file=Channel%20Manager%20-%20Launch%20Readiness%20Checklist%20rev%201-2-26.docx&action=default&mobileredirect=true",
            },
            {
              title: "Broadvoice Sales Intranet",
              desc: "Sales toolbox, quick links to important forms, and TSD maps for recruiting.",
              href: "https://broadvoice.sharepoint.com/sites/Broadvoice-Intranet/SitePages/US-Sales.aspx",
            },
            {
              title: "Global Sales Operating Playbook (Confluence)",
              desc: "Process and policy documentation across the full Sales → Customer Success journey.",
              href: "https://broadvoice-jira.atlassian.net/wiki/spaces/HOME/pages/5966627330/Global+Sales+Operating+Playbook",
            },
            {
              title: "Seismic – Sales Enablement",
              desc: "Sales decks, datasheets, rate cards, competitive battlecards, and more.",
              href: "https://broadvoice.seismic.com/apps/home",
            },
            {
              title: "CX Partner Onboarding – Email Template",
              desc: "Standardized first-touch outreach for new CX partners.",
              href: "https://broadvoice-my.sharepoint.com/:w:/r/personal/evam_broadvoice_com/_layouts/15/Doc.aspx?sourcedoc=%7B3587EF57-1E5C-4E73-9C59-49FE002B4C9F%7D&file=CX%20Partner%20Onboarding-%20Email%20Template.docx&action=default&mobileredirect=true",
            },
            {
              title: "Partner Onboarding Checklist",
              desc: "Reference partner onboarding sales guide.",
              href: "https://broadvoice-jira.atlassian.net/wiki/spaces/HOME/pages/5947916401/REF+Partner+Onboarding+Sales+Guide",
            },
            {
              title: "Marketing Hub",
              desc: "Co-branded assets, campaign templates, and partner marketing resources.",
              href: "https://marketinghub.broadvoice.com",
            },
          ].map((r, i) => (
            <a key={i} href={r.href} target="_blank" rel="noreferrer" style={{
              display: "flex", alignItems: "center", gap: 12,
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              background: "#FFFFFF", textDecoration: "none",
            }}>
              <div style={{ width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <ExternalLink size={18} style={{ stroke: "url(#cm-icon-grad)" }} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>{r.title}</div>
                <div style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif", marginTop: 1 }}>{r.desc}</div>
              </div>
            </a>
          ))}
        </div>

        <div style={{ marginTop: 18, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {[
            "It's not the will to win, but the will to prepare to win that makes the difference.",
            "The ones that win are the ones who keep going after everyone else has quit.",
            "Success is the sum of small efforts, repeated day in and day out.",
            "Don't be busy. Be productive.",
          ].map((q, i) => (
            <div key={i} style={{ borderLeft: "3px solid", borderImage: "linear-gradient(180deg, #43B5BF, #27698F) 1", padding: "8px 12px", background: "rgba(67,181,191,0.04)", borderRadius: 4 }}>
              <div style={{ fontFamily: "'Instrument Sans', sans-serif", fontSize: 12, fontStyle: "italic", color: "#1A1A2E", lineHeight: 1.45 }}>"{q}"</div>
            </div>
          ))}
        </div>

        <div className="closing-line" style={{ marginTop: 16 }}>
          The standard isn't a checklist — it's how we show up every day.
        </div>

        <PageFooterText pageNum={8} />
        <PageFooter />
      </div>
    </div>
  );
};

export default ChannelManagerPlaybook;
