import React from "react";
import "./GoEngageDatasheet.css";

interface Section {
  num: string;
  title: string;
  intro?: string;
  bullets: string[];
}

const sections: Section[] = [
  {
    num: "1",
    title: "Demuestra el cumplimiento con datos",
    intro: "La Ley SAC exige evidencias.",
    bullets: [
      "Controla KPIs en tiempo real.",
      "Genera informes y auditorías fácilmente.",
      "Mide tiempos de respuesta, reclamaciones y satisfacción.",
    ],
  },
  {
    num: "2",
    title: "Trazabilidad completa de cada interacción",
    intro: "Centraliza todos tus canales de atención.",
    bullets: [
      "Voz, email, chat, WhatsApp y redes sociales.",
      "Historial unificado de cada cliente.",
      "Seguimiento completo de solicitudes e incidencias.",
    ],
  },
  {
    num: "3",
    title: "Control de SLA y tiempos de respuesta",
    intro: "Gestiona compromisos de servicio de forma automática.",
    bullets: [
      "Ticketing integrado.",
      "Alertas y escalados automáticos.",
      "Supervisión en tiempo real del cumplimiento.",
    ],
  },
  {
    num: "4",
    title: "Integración con tu ecosistema",
    intro: "GoContact se adapta a tu organización.",
    bullets: [
      "Integración con los principales CRM.",
      "API abierta para sistemas corporativos y aplicaciones de terceros.",
      "Visión única del cliente sin sustituir tus herramientas actuales.",
    ],
  },
  {
    num: "5",
    title: "IA para una atención más eficiente",
    intro: "Mejora el servicio con Engage.",
    bullets: [
      "Automatiza consultas frecuentes.",
      "Asiste a los agentes en tiempo real.",
      "Atención disponible también en lenguas cooficiales.",
    ],
  },
  {
    num: "6",
    title: "Calidad medible y mejora continua",
    intro: "Convierte la calidad en un indicador de negocio.",
    bullets: [
      "Encuestas de satisfacción.",
      "Evaluación de interacciones.",
      "Identificación de oportunidades de mejora.",
    ],
  },
];

const renderSection = (s: Section) => (
  <div
    key={s.num}
    className="faq-item"
    style={{
      display: "grid",
      gridTemplateColumns: "180px 1fr",
      gap: 18,
      marginBottom: 0,
      paddingBottom: 10,
      borderBottom: "1px solid #E5E7EB",
      alignItems: "start",
    }}
  >
    <div className="faq-question" style={{ fontSize: 13, marginBottom: 0, lineHeight: 1.25 }}>
      {s.num}. {s.title}
    </div>
    <div>
      {s.intro && (
        <div className="faq-answer" style={{ fontStyle: "italic", marginBottom: 4, fontSize: 11, lineHeight: 1.4 }}>
          {s.intro}
        </div>
      )}
      <ul className="faq-answer" style={{ paddingLeft: 16, margin: 0, fontSize: 11, lineHeight: 1.5 }}>
        {s.bullets.map((b) => (
          <li key={b} style={{ marginBottom: 1 }}>{b}</li>
        ))}
      </ul>
    </div>
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const LeySAC: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo" style={{ marginBottom: 18 }}>
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="partner-hero">
          <h1 className="hero-headline" style={{ fontSize: 30, lineHeight: 1.1, marginBottom: 4 }}>
            ¿Está tu organización preparada para la <em>Ley SAC</em>?
          </h1>
          <div className="faq-title-sub" style={{ fontSize: 13, marginTop: 4 }}>
            Cumple la normativa y mejora la experiencia de cliente con GoContact.
          </div>
        </div>

        <hr style={{ margin: "12px 0" }} />

        <div className="faq-section">
          <div className="faq-answer" style={{ marginBottom: 14, fontSize: 11.5, lineHeight: 1.5 }}>
            La Ley SAC exige nuevos estándares de atención, trazabilidad, seguimiento y calidad del servicio. GoContact te ayuda a cumplir, medir y demostrar el cumplimiento desde una única plataforma omnicanal.
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {sections.map(renderSection)}
          </div>

          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#27698F", lineHeight: 1.2 }}>
              GoContact
            </div>
            <div style={{ fontSize: 11, lineHeight: 1.5, color: "#1A1A2E", marginTop: 2 }}>
              La plataforma tecnológica para cumplir, medir y demostrar el cumplimiento de la Ley SAC.
            </div>
            <div style={{ fontSize: 11, lineHeight: 1.5, color: "#555", marginTop: 4, fontStyle: "italic" }}>
              Más control. Más trazabilidad. Más eficiencia. Menos riesgo.
            </div>
          </div>
        </div>

        <PageFooter />
      </div>
    </div>
  );
};

export default LeySAC;
