import React from "react";
import { Link } from "react-router-dom";

const groups: { title: string; docs: [string, string][] }[] = [
  { title: "Datasheets", docs: [
    ["Analyst Datasheet", "/aianalyst"], ["Analyst Datasheet (Editable)", "/aianalyst-edit"],
    ["Post-Call AI", "/post-call-ai"], ["Communicator", "/communicator"],
    ["Communicator Partner", "/communicator-partner"], ["b-hive", "/bhive"],
    ["GoContact", "/gocontact"], ["Zoho Integration", "/zoho-integration"],
    ["AI Security Sheet", "/ai-security"], ["Poly Rate Card", "/poly-rate-card"],
    ["International Calling", "/international-calling"],
  ]},
  { title: "FAQs", docs: [
    ["GoContact Analyst FAQ", "/faq"], ["Engage Inbound FAQ", "/inbound-faq"],
    ["Partner Certification FAQ", "/partner-certification-faq"],
  ]},
  { title: "Overviews", docs: [
    ["Company Overview", "/company-overview"], ["Executive Overview", "/executive-overview"],
    ["Executive Overview (General)", "/executive-overview-general"],
    ["Executive Overview (Portuguese)", "/executive-overview-general-pt"],
    ["Executive Overview (Spanish)", "/executive-overview-general-es"],
  ]},
  { title: "Technical Guides", docs: [
    ["Partner Tech Guide", "/partner-tech-guide"], ["Partner Tech Guide (ES)", "/partner-tech-guide-es"],
    ["Partner Tech Guide (ES Madrid)", "/partner-tech-guide-es-madrid"],
    ["Dynamics Connector Guide", "/dynamics-connector-guide"],
    ["Salesforce Connector Guide", "/salesforce-connector-guide"],
    ["GoContact Homepage Guide", "/gocontact-homepage-guide"], ["b-hive User Guide", "/user-guide"],
  ]},
  { title: "Partner & Internal", docs: [
    ["Partner Intro Kit", "/partner-intro-kit"], ["Partner Success Plan", "/partner"],
    ["Global Partner Program", "/global-partner-program"], ["Channel Manager Playbook", "/channel-playbook"],
    ["Sales Engineer Playbook", "/sales-engineer-playbook"], ["Implementation Taskforce", "/taskforce"],
    ["May Demo Incentive", "/may-incentive"], ["Performance & Goal Guide", "/performance-goal-guide"],
    ["Interview Ownership Guide", "/interview-ownership-guide"],
  ]},
  { title: "Flyers", docs: [
    ["Healthcare", "/healthcare"], ["Finance", "/finance"], ["Insurance", "/insurance"],
    ["Real Estate", "/real-estate"], ["Logistics", "/logistics"],
    ["Catholic Churches", "/catholic-churches"], ["Ley SAC", "/ley-sac"], ["Feliz Verano", "/feliz-verano"],
  ]},
];

const DocumentIndex: React.FC = () => (
  <div style={{ minHeight: "100vh", background: "#F8FAFB", fontFamily: "'Instrument Sans', sans-serif", padding: "48px 24px" }}>
    <div style={{ maxWidth: 960, margin: "0 auto" }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" style={{ height: 32, marginBottom: 24 }} />
      <h1 style={{ fontSize: 36, fontWeight: 600, color: "#1A1A2E", margin: "0 0 32px" }}>Document Library</h1>
      {groups.map((g) => (
        <section key={g.title} style={{ marginBottom: 32 }}>
          <h2 style={{ fontSize: 13, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#27698F", margin: "0 0 12px" }}>{g.title}</h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 10 }}>
            {g.docs.map(([name, path]) => (
              <Link key={path} to={path} style={{ display: "block", background: "#FFFFFF", border: "1px solid #E2E2EC", borderLeft: "3px solid #43B5BF", borderRadius: 8, padding: "12px 14px", textDecoration: "none" }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#1A1A2E" }}>{name}</div>
                <div style={{ fontSize: 12, color: "#555567", marginTop: 2 }}>{path}</div>
              </Link>
            ))}
          </div>
        </section>
      ))}
    </div>
  </div>
);

export default DocumentIndex;
