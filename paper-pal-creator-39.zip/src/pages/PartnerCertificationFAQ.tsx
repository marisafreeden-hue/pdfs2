import React from "react";
import "./GoEngageDatasheet.css";
import lifecycleAsset from "@/assets/partner-onboarding-lifecycle.png.asset.json";

type Block = string | { bullets: string[] } | { image: string; caption?: string };

interface FAQItem {
  q: string;
  a: Block[];
}

const renderText = (t: string) =>
  t.split(/(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g).map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={i} style={{ fontWeight: 700, color: "#1A1A2E" }}>
          {part.slice(2, -2)}
        </strong>
      );
    }
    const link = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) {
      return (
        <a
          key={i}
          href={link[2]}
          target="_blank"
          rel="noreferrer"
          style={{ color: "#27698F", fontWeight: 600, textDecoration: "underline", wordBreak: "break-word" }}
        >
          {link[1]}
        </a>
      );
    }
    return <React.Fragment key={i}>{part}</React.Fragment>;
  });

const Section: React.FC<{ items: FAQItem[]; startIndex: number }> = ({
  items,
  startIndex,
}) => (
  <div className="faq-section">
    {items.map((item, i) => (
      <div key={i} className="faq-item">
        <div className="faq-question">
          <span className="faq-question-number">
            {String(startIndex + i + 1).padStart(2, "0")}
          </span>
          <span>{item.q}</span>
        </div>
        {item.a.map((p, j) => {
          if (typeof p === "string") {
            return (
              <div key={j} className="faq-answer">
                {renderText(p)}
              </div>
            );
          }
          if ("image" in p) {
            return (
              <div key={j} style={{ paddingLeft: 34, margin: "6px 0 8px" }}>
                <img
                  src={p.image}
                  alt={p.caption || "Reference screenshot"}
                  style={{
                    width: "100%",
                    maxWidth: 520,
                    border: "1px solid #E2E2EC",
                    borderRadius: 8,
                    display: "block",
                  }}
                />
                {p.caption && (
                  <div
                    style={{
                      fontSize: 10.5,
                      color: "#6B7280",
                      fontStyle: "italic",
                      marginTop: 5,
                    }}
                  >
                    {p.caption}
                  </div>
                )}
              </div>
            );
          }
          return (
            <ul key={j} className="faq-bullets">
              {p.bullets.map((b, k) => (
                <li key={k} className="faq-answer">
                  {renderText(b)}
                </li>
              ))}
            </ul>
          );
        })}
      </div>
    ))}
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-blur" />
    <div
      style={{
        position: "absolute",
        bottom: 18,
        left: 48,
        right: 48,
        display: "flex",
        justifyContent: "space-between",
        fontSize: 8.5,
        letterSpacing: 0.4,
        color: "#6B7280",
        textTransform: "uppercase",
        zIndex: 6,
      }}
    >
      <span>Partner Certification FAQ · Confidential – Internal Use Only</span>
      <span>© Broadvoice 2026</span>
    </div>
  </>
);

const PageHeader: React.FC = () => (
  <>
    <div className="logo">
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    <div
      style={{
        position: "absolute",
        top: 44,
        right: 48,
        fontSize: 9,
        fontWeight: 700,
        letterSpacing: 1.2,
        color: "#27698F",
        textTransform: "uppercase",
        zIndex: 6,
      }}
    >
      Internal Use Only
    </div>
  </>
);

const whyItems: FAQItem[] = [
  {
    q: "Why is Partner Certification being introduced, and what problem is it intended to solve?",
    a: [
      "The goal is to make sure every partner has a strong foundation, increase confidence in identifying and positioning CX opportunities, and then use the resulting engagement and pipeline data to continually improve the partner experience.",
    ],
  },
  {
    q: "Is certification mandatory for all partners, or are there optional paths?",
    a: [
      "Certification is required for a partner to be considered fully onboarded, but partners have flexibility in how they complete it. They can attend the live weekly Thursday training, request a custom training time, or complete the asynchronous path once it launches with the new Partner Portal at the end of September.",
      "Certification is not a prerequisite for doing business with Broadvoice. A partner can still bring us an opportunity, request a quote, and engage our team before completing certification. The problem we are solving is activation, not access to transact.",
    ],
  },
  {
    q: "Who does the certification requirement apply to: IPP partners only, or all new partners?",
    a: [
      "Any partner is welcome to participate. Our launch focus is new and recently onboarded partners, because completing either the live certification training or the asynchronous path will be part of our onboarding standard for new partners.",
      "The program is not limited to IPP partners. Existing partners can also participate, and CMs are encouraged to invite any partner who would benefit from additional product education or stronger CX positioning.",
    ],
  },
];

const valueItems: FAQItem[] = [
  {
    q: "What tangible value does certification provide beyond a badge or certificate?",
    a: [
      "We are launching an incentive path with small rewards that increase in value as partners progress through the partner journey, but the bigger value is improved product understanding, confidence, and engagement.",
      "If a partner is already bringing us CX opportunities but does not want to attend the training, that should not create a barrier to doing business. If a partner is not bringing opportunities and is also unwilling to participate, that becomes an important engagement signal and may indicate the partner is not the best place for the CM to focus significant time and resources.",
      "Conversely, when a new partner is willing to invest time in certification, that signals engagement and helps CMs prioritize their bench, build smarter business plans, and focus resources on partners most likely to activate.",
    ],
  },
  {
    q: "How will certification help partners identify opportunities, position Broadvoice, and close business?",
    a: [
      "Certification gives partners a clearer, more repeatable way to recognize where Broadvoice fits and how to start the right customer conversation. Partners gain a stronger understanding of our ideal customer profile, common CX use cases, where we win, how to position our products, and the business problems our solutions solve.",
      "The goal is not to turn every partner into a technical expert or have them own the full sales cycle. It is to help them recognize a CX opportunity, ask the right initial questions, and know when to bring in the Broadvoice team. The CM, SE, and CX Strategist still need to take a consultative approach and help move the partner toward their first opportunities.",
    ],
  },
  {
    q: "How are we accounting for partners who prefer to bring Broadvoice in as the product expert?",
    a: [
      "Certification is not intended to force every partner to become deeply technical. Some partners will own more of the product conversation; others will identify opportunities, open the door, and bring Broadvoice in as the technical expert. Both models are valid.",
      "Regardless of partner type, every partner should have a general understanding of who Broadvoice is, what we do, the problems we solve, and where we win.",
    ],
  },
  {
    q: "How will we avoid certification becoming a barrier for new partners still evaluating the relationship?",
    a: [
      "The training is required for a new partner to be considered fully onboarded, but it is not intended to prevent a partner from bringing us business. If a partner is already bringing opportunities, the lack of certification should not become a barrier to supporting that business.",
      "If a partner is not bringing opportunities and is unwilling to participate in training, the CM and CX Strategist should work together to determine whether that partner is worth continued investment and what strategy is most likely to activate them.",
    ],
  },
];

const levelItems: FAQItem[] = [
  {
    q: "What certification levels are available, and who are they for?",
    a: [
      "The program has three levels. Level 1: Foundations is the required onboarding entry point, designed to give partners a baseline understanding of Broadvoice products, positioning, ICP, and go-to-market strategy.",
      "Level 2: Developing is an optional deeper track for partners who want to demo Broadvoice products independently. Level 3: Integrator is an optional advanced track for partners who want to own more of the integration, configuration, and support experience for customers.",
    ],
  },
  {
    q: "What does Level 1: Foundations cover?",
    a: [
      "Foundations covers product introduction, go-to-market strategy, ICP, positioning, and demos of b-hive, GoContact, Engage, and Analyst. It also includes marketing guidance, next steps, live Q&A, and certification.",
    ],
  },
  {
    q: "What does Level 2: Developing cover?",
    a: [
      "Developing goes deeper into the product suite and demo best practices, including user groups, profile manager, campaigns, queues, IVRs, callback managers, ticketing, SLA management, webchat, social networks, dashboards, CRM, reporting, scripting, GoAI, IVR campaigns, quality management, customer pain-point mapping, RFPs, statements of work, and proposals. It concludes with knowledge checks and certification.",
    ],
  },
  {
    q: "What does Level 3: Integrator cover?",
    a: [
      "Integrator is designed for partners who want deeper technical ownership. It covers configuration, scripting, APIs and integrations, Engage configuration and APIs, Analyst best practices, partner CSM and support onboarding, case management, self-help resources, partner administration, and IT/network essentials. It concludes with knowledge checks and certification.",
    ],
  },
];

const roleItems: FAQItem[] = [
  {
    q: "Will Sales Engineers continue to support partner and customer demos as they do today?",
    a: [
      "Yes. This training does not change the current customer sales process or the role of the SE, CM, or CX Strategist. SEs, CMs, and CX Strategists should continue working directly with partners and customers to demonstrate the specific use cases, workflows, and features most relevant to that opportunity.",
      "The certification provides a broader foundation of product knowledge, but it is not intended to replace consultative discovery or tailored demos.",
    ],
  },
  {
    q: "How does the new training differ from what CMs, CX Strategists, and SEs already cover?",
    a: [
      "The Partner Overview deck should continue to be presented as the first step in onboarding. Today, we often see the Partner Overview, co-success plan, and product demos completed within a single call. If that approach is working and translating into CX opportunities, we do not want to disrupt it.",
      "Based on the data, we believe there is value in a more focused training experience beyond the initial overview. The certification provides greater consistency in messaging, more depth around products and positioning, and additional touchpoints after that first onboarding conversation.",
    ],
  },
  {
    q: "Will CMs and CX Strategists receive an updated deck or revised onboarding process?",
    a: [
      "Yes. The updated onboarding process and new steps will be included as part of training for the new Partner Portal. The Partner Overview deck will also be updated to support the new process, launching formally with the new Portal in September.",
    ],
  },
  {
    q: "What are the specific responsibilities of the CM, CX Strategist, SE, and Training team?",
    a: [
      "CMs own the partner relationship and help drive partners into the training as part of onboarding. The CM, CX Strategist, and SE continue to work together consultatively based on the partner's business model, customer opportunities, and level of involvement.",
      "Training owns delivery of the certification curriculum, assessments, certification records, and the structured education experience.",
    ],
  },
];

const timingItems: FAQItem[] = [
  {
    q: "When does certification launch, and when does the new Partner Portal launch?",
    a: [
      "Live Level 1: Foundations training launches September 3, 2026 and runs every Thursday at 9:00 a.m. PT. The new Partner Portal and asynchronous training path are planned to launch mid to end of September.",
    ],
  },
  {
    q: "How will partners register before the new Partner Portal is available?",
    a: [
      "Partners can register using the current Microsoft Forms registration link: [Registration for Broadvoice's Partner Foundations Certification](https://forms.cloud.microsoft/r/Fwyb65wjqa). Once the new Partner Portal launches, registration and the asynchronous training experience will be incorporated into the portal.",
    ],
  },
  {
    q: "At what point in onboarding should the partner be registered for certification?",
    a: [
      "Partners should be registered after the CM has presented the initial Broadvoice Partner Overview deck. The training is intended to be the next structured step in the onboarding journey.",
    ],
  },
  {
    q: "Is the CM responsible for registering the partner or walking them through registration?",
    a: [
      "Either approach is fine. The CM can register the partner directly or walk the partner through registration, depending on what works best for the relationship. The important point is that the CM owns driving the partner toward the training as part of onboarding.",
    ],
  },
  {
    q: "How will CMs and CX Strategists know when partners have registered, attended, and completed certification?",
    a: [
      "Completion is tracked as a milestone in Salesforce. The Training team updates the Partner Onboarding Lifecycle section after certification is completed.",
    ],
  },
  {
    q: "Where will certification status be tracked and visible?",
    a: [
      "Certification status is tracked in Salesforce within the Partner Onboarding Lifecycle section, including the training and Product Certified fields. After each level is completed, the Revenue Enablement / Training team updates those fields on the partner record.",
      { image: lifecycleAsset.url, caption: "Partner Onboarding Lifecycle fields in Salesforce" },
    ],
  },
  {
    q: "Who owns follow-up when a partner registers but does not attend or complete certification?",
    a: [
      "The CM owns follow-up with the partner. Training manages the training experience and reminders, but the CM remains responsible for the overall partner relationship and onboarding progress.",
    ],
  },
];

const accessItems: FAQItem[] = [
  {
    q: "Can internal team members attend certification sessions?",
    a: [
      "Yes. Internal team members are welcome to attend so they understand the curriculum and can better align their own partner conversations with the training.",
    ],
  },
  {
    q: "Can a newly recruited partner submit an opportunity and receive a quote before completing certification?",
    a: [
      "Yes. Certification does not prevent a new partner from submitting an opportunity, requesting a quote, or engaging Broadvoice resources.",
    ],
  },
  {
    q: "Can we still create the partner's b-hive account and support simple UC opportunities?",
    a: [
      "Yes. We can continue supporting simple UC opportunities and creating the partner's b-hive account before certification is complete. GoContact access may have additional requirements depending on the specific enablement path.",
    ],
  },
  {
    q: "What, specifically, is restricted until certification is completed?",
    a: [
      "Nothing is restricted from a selling or quoting standpoint. Certification is primarily a measurement of whether the partner has completed our defined onboarding process and baseline product education.",
    ],
  },
  {
    q: "How will we ensure the certification process does not delay an immediate revenue opportunity?",
    a: [
      "There is no barrier to bringing us a deal. If a partner has an opportunity, the CM, SE, CX Strategist, and broader Broadvoice team should support that opportunity immediately, regardless of certification status.",
    ],
  },
];

const messagingItems: FAQItem[] = [
  {
    q: "How should CMs position the certification requirement to partners?",
    a: [
      "CMs should position certification as the next step in Broadvoice onboarding and as an investment in helping the partner better understand how to identify, position, and sell our core platforms. The message should be simple: we offer multiple training tracks, and the next step in onboarding is a focused deep-dive on how to sell, position, and understand Broadvoice's core platforms.",
    ],
  },
  {
    q: "What standardized messaging or collateral will be available?",
    a: [
      "CMs will receive updated slides in the Partner Overview deck that explain the certification program and next steps. The messaging should remain straightforward and focused on the value of giving partners a consistent foundation in Broadvoice products, positioning, and use cases.",
    ],
  },
  {
    q: "Will Broadvoice send automated communications, or is the CM driving the process?",
    a: [
      "Once a partner is registered, they receive calendar invitations and reminder communications. The CM is still responsible for introducing the training, explaining its role in onboarding, and driving the partner toward completion.",
    ],
  },
  {
    q: "What does a partner receive after completing a certification level?",
    a: [
      "Partners receive a PDF certificate for the level completed, instructions for adding the certification badge to LinkedIn, and an updated training record in Salesforce. Partners are also eligible for incentives associated with progression through the partner journey.",
    ],
  },
];

const measureItems: FAQItem[] = [
  {
    q: "How will we measure whether certification is improving partner activation?",
    a: [
      "The primary goal is to improve activation from onboarding to first CX opportunity and first closed CX business. Today, 101 partners have been onboarded this year and 2 have generated a GoContact/CX opportunity to date. We will use certification completion alongside pipeline and sales performance to determine whether partners are activating more quickly and consistently.",
    ],
  },
  {
    q: "Will we track participation, completion, time to first quote, pipeline, and win rate?",
    a: [
      "Yes. We already track these types of metrics today. Updated dashboards will give CMs greater visibility into individual partner performance, including onboarding, activation, pipeline, and sales outcomes.",
    ],
  },
  {
    q: "Will partners be surveyed after completing certification and onboarding?",
    a: [
      "Yes. We will continue gathering partner feedback so we can understand what is working, where friction exists, and how the onboarding and certification experience can be improved.",
    ],
  },
  {
    q: "Will the requirement be adjusted if data shows it is creating friction?",
    a: [
      "Not completing certification does not stop a partner from working with Broadvoice. If a partner does not want to complete the training but is actively bringing us opportunities, generating pipeline, and closing business, that is still a win and ultimately the end goal.",
      "They may not be considered certified or fully onboarded under our defined onboarding standards, but certification should never become a barrier to supporting revenue.",
    ],
  },
];

const talkTracks: { label: string; quote: string }[] = [
  {
    label: "Simple / straightforward",
    quote:
      "We've added a certification step to onboarding so every partner gets a consistent foundation on who Broadvoice is, where we win, and how to identify CX opportunities. The next step is a 90-minute Foundations session. You can join the live Thursday session, request another time, or use the on-demand path once the new portal launches.",
  },
  {
    label: "For a busy partner",
    quote:
      "I know time is tight, so we've tried to make this flexible. The goal isn't to turn you into a technical expert. It's to make sure you know the core use cases, where Broadvoice fits, and when to bring us into an opportunity. You can do the live session or complete it on demand.",
  },
  {
    label: "For a partner who mainly refers opportunities",
    quote:
      "You don't need to become the product expert or run demos yourself. We still want you to bring us in for the technical conversation. The certification is really about helping you recognize the right opportunities, understand our positioning, and know enough to start the conversation confidently.",
  },
  {
    label: "For a partner who asks, \u201cDo I have to do this before I can sell?\u201d",
    quote:
      "No. If you have an opportunity today, bring it to us today. We're not going to hold up a quote or a deal because you haven't completed certification. Certification is part of what we use to define a completed onboarding process, but it is not a barrier to doing business with us.",
  },
  {
    label: "For a partner who is interested in going deeper",
    quote:
      "We've built this in levels, so you can choose how deep you want to go. Foundations gives you the core sales and positioning knowledge. If you want to become more self-sufficient with demos, there's a Developing track, and there's an Integrator track for partners who want deeper technical and support capabilities.",
  },
  {
    label: "More consultative",
    quote:
      "Before I point you to the right training path, I want to understand how you want to work with us. Some partners want to identify opportunities and bring us in as the experts. Others want to own more of the product conversation. Foundations gives everyone the same baseline, and then we can tailor the rest of the relationship and enablement around how you actually want to sell.",
  },
];

const PartnerCertificationFAQ: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper pcf-scope">
      <style>{`
        .pcf-scope .page { padding-top: 0.5in; padding-bottom: 0.62in; }
        .pcf-scope .logo { margin-bottom: 22px; }
        .pcf-scope .hero-headline { font-size: 30px; line-height: 1.15; }
        .pcf-scope .faq-section { margin-bottom: 14px; }
        .pcf-scope .faq-section-header {
          border-bottom: 2px solid #43B5BF;
          margin-bottom: 8px;
          padding-bottom: 7px;
        }
        .pcf-scope .faq-section-title {
          font-size: 19px;
          font-weight: 600;
          line-height: 1.25;
          margin-bottom: 0;
        }
        .pcf-scope .faq-item {
          padding: 12px 4px 16px;
          border-bottom: 1px solid #E2E2EC;
        }
        .pcf-scope .faq-item:last-child { border-bottom: none; }
        .pcf-scope .faq-question {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          color: #1A1A2E;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.42;
          margin-bottom: 7px;
        }
        .pcf-scope .faq-question-number {
          flex: 0 0 24px;
          color: #27698F;
          font-size: 10px;
          line-height: 20px;
          letter-spacing: 0.04em;
        }
        .pcf-scope .faq-answer { margin-bottom: 8px;
          color: #4B5563;
          font-size: 12.5px;
          line-height: 1.65;
          padding-left: 34px;
        }
        .pcf-scope .faq-bullets {
          margin: 5px 0 8px 0;
          padding-left: 50px;
          list-style: disc;
        }
        .pcf-scope .faq-bullets li {
          margin-bottom: 4px;
          padding-left: 2px;
        }
        .pcf-scope .faq-bullets .faq-answer { padding-left: 0; }
        @media print {
          .pcf-scope .faq-section-header { border-bottom-color: #43B5BF !important; }
          .pcf-scope .faq-question-number { color: #27698F !important; }
        }
      `}</style>
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>


      {(() => {
        const all: FAQItem[] = [
          ...whyItems,
          ...valueItems,
          ...levelItems,
          ...accessItems,
          ...roleItems,
          ...messagingItems,
          ...timingItems,
          ...measureItems,
        ];
        const sizes = [4, 4, 5, 5, 5, 5, 5, 5, 5];
        const chunks: FAQItem[][] = [];
        let idx = 0;
        for (const s of sizes) {
          if (idx >= all.length) break;
          chunks.push(all.slice(idx, idx + s));
          idx += s;
        }
        if (idx < all.length) chunks.push(all.slice(idx));
        let counter = 0;
        return chunks.map((items, pi) => {
          const start = counter;
          counter += items.length;
          return (
            <div className={pi === 0 ? "page page-1" : "page page-2"} key={pi}>
              <PageHeader />
              {pi === 0 && (
                <div className="partner-hero">
                  <h1 className="hero-headline">Partner Certification</h1>
                  <div className="faq-title-sub">
                    Program FAQs · Internal Enablement Reference
                  </div>
                </div>
              )}
              <Section items={items} startIndex={start} />
              <PageFooter />
            </div>
          );
        });
      })()}

      {/* ===== PAGE 11: Talk tracks ===== */}
      <div className="page page-2">
        <PageHeader />
        <div className="faq-section">
          <div className="faq-section-header">
            <h3 className="faq-section-title">CM Talk Tracks</h3>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {talkTracks.map((t) => (
              <div
                key={t.label}
                style={{
                  border: "1px solid #E5E7EB",
                  borderLeft: "3px solid #43B5BF",
                  borderRadius: 10,
                  padding: "10px 14px",
                  background: "#FBFDFE",
                  WebkitPrintColorAdjust: "exact",
                  printColorAdjust: "exact",
                }}
              >
                <div
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    letterSpacing: 0.6,
                    textTransform: "uppercase",
                    color: "#27698F",
                    marginBottom: 4,
                  }}
                >
                  {t.label}
                </div>
                <div className="faq-answer" style={{ fontStyle: "italic", marginBottom: 0 }}>
                  &ldquo;{t.quote}&rdquo;
                </div>
              </div>
            ))}
          </div>
        </div>
        <PageFooter />
      </div>
    </div>
  );
};

export default PartnerCertificationFAQ;
