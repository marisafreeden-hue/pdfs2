import beachBg from "@/assets/summer-beach.jpg";
import broadvoiceLogo from "@/assets/broadvoice-logo.svg";

export default function FelizVerano() {
  return (
    <div className="vcard-wrapper" style={{ padding: "40px 0", background: "#f5f5f7", minHeight: "100vh" }}>
      <button className="export-pdf-btn no-print" onClick={() => window.print()} style={{ position: "fixed", top: 16, right: 16, zIndex: 10, padding: "8px 14px", background: "#27698F", color: "#fff", border: 0, borderRadius: 6, cursor: "pointer" }}>
        Export PDF
      </button>


      <style>{`
        .vcard {
          width: 6in;
          height: 4in;
          margin: 0 auto 24px;
          background: #FFFFFF;
          box-shadow: 0 4px 40px rgba(0,0,0,.14);
          position: relative;
          overflow: hidden;
          font-family: 'Inter', -apple-system, sans-serif;
          color: #1A1A2E;
          box-sizing: border-box;
        }
        .vcard-logo {
          background: url('/assets/teal-blur-card.svg') center/cover no-repeat, #FFFFFF;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .vcard-logo img { width: 70%; height: auto; }
        .vcard-msg {
          background: url('${beachBg}') center/cover no-repeat;
          padding: 0.42in 0.5in;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
        .vcard-msg::before {
          content: "";
          position: absolute;
          inset: 0;
          background:
            linear-gradient(120deg, rgba(255,255,255,0.78) 0%, rgba(255,255,255,0.55) 45%, rgba(255,255,255,0.25) 100%),
            linear-gradient(135deg, rgba(67,181,191,0.35), rgba(198,134,248,0.28));
          pointer-events: none;
        }
        .vcard-msg::after {
          content: "";
          position: absolute;
          inset: 12px;
          border: 1px solid rgba(255,255,255,0.35);
          pointer-events: none;
          z-index: 2;
        }
        .vcard-msg > * { position: relative; z-index: 1; }

        .vcard-mark img { height: 22px; width: auto; display: block; filter: brightness(0); }

        .vcard-headline {
          font-family: 'Instrument Sans', -apple-system, sans-serif;
          font-size: 46px;
          line-height: 1;
          font-weight: 500;
          letter-spacing: -0.025em;
          margin: 0 0 14px;
          color: #27698F;
          display: flex;
          flex-wrap: wrap;
          align-items: baseline;
          gap: 0 10px;
        }
        .vcard-headline em {
          font-family: 'Besley', serif;
          font-style: italic;
          font-weight: 400;
          background: linear-gradient(90deg, #43B5BF, #27698F, #C686F8);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .vcard-body {
          font-size: 12px;
          line-height: 1.55;
          color: #1a3a4a;
          max-width: 4in;
        }
        .vcard-body p { margin: 0 0 8px; font-weight: 500; }
        .vcard-body p + p { opacity: 0.78; font-weight: 400; }
        .vcard-sign {
          font-family: 'Besley', Georgia, serif;
          font-style: italic;
          font-size: 12px;
          color: #27698F;
          border-top: 1px solid rgba(39,105,143,0.15);
          padding-top: 10px;
          padding-right: 40px;
          align-self: flex-start;
        }
        .vcard, .vcard * {
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
          color-adjust: exact !important;
        }
        .vcard img { image-rendering: -webkit-optimize-contrast; image-rendering: crisp-edges; }
        @media print {
          @page { size: 6in 4in; margin: 0; }
          html, body { margin: 0; padding: 0; background: white; }
          .no-print { display: none !important; }
          .vcard-wrapper { background: white !important; padding: 0 !important; min-height: 0 !important; }
          .vcard {
            margin: 0 !important;
            box-shadow: none !important;
            page-break-after: always;
            break-after: page;
          }
          .vcard:last-of-type { page-break-after: auto; break-after: auto; }
        }
      `}</style>

      {/* Side A — Logo */}
      <div className="vcard vcard-logo">
        <img src={broadvoiceLogo} alt="Broadvoice" />
      </div>

      {/* Side B — Message */}
      <div className="vcard vcard-msg">
        <div className="vcard-mark">
          <img src="/assets/broadvoice-logo-gradient.png" alt="Broadvoice" />
        </div>


        <div>
          <h1 className="vcard-headline">
            <span>¡Feliz</span>
            <em>Verano!</em>
          </h1>
          <div className="vcard-body">
            <p>Esperamos que disfrutes de unos días de descanso, buen tiempo y momentos inolvidables.</p>
            <p>Nosotros te estaremos esperando a la vuelta para seguir construyendo grandes proyectos juntos.</p>
          </div>
        </div>

        <div className="vcard-sign">— El equipo de Broadvoice</div>
      </div>
    </div>
  );
}
