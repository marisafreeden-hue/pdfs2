import React from "react";
import { ShieldCheck, Lock, Headphones, Sparkles, TrendingUp, Server } from "lucide-react";
import "./GoEngageDatasheet.css";

import logoPfizer from "@/assets/logo-pfizer.png.asset.json";
import logoLoreal from "@/assets/logo-loreal.png.asset.json";
import logoUps from "@/assets/logo-ups.png.asset.json";
import logoToyota from "@/assets/logo-toyota.png.asset.json";
import logoHertz from "@/assets/logo-hertz.png.asset.json";
import logoSiemens from "@/assets/logo-siemens.png.asset.json";

import jeffPritle from "@/assets/jeff-pritle.jpeg.asset.json";
import mollyLozano from "@/assets/molly-lozano.png.asset.json";
import ricardoCosta from "@/assets/ricardo-costa.png.asset.json";
import rodrigoJaramillo from "@/assets/rodrigo-jaramillo.jpeg.asset.json";
import jimMurphy from "@/assets/jim-murphy.jpeg.asset.json";
import samGhahremanpour from "@/assets/sam-ghahremanpour.jpeg.asset.json";
import georgeMitsopoulos from "@/assets/george-mitsopoulos.jpeg.asset.json";
import gurdipJande from "@/assets/gurdip-jande.jpeg.asset.json";
import marisaFreeden from "@/assets/marisa-freeden.jpeg.asset.json";
import worldMap from "@/assets/world-dot-map.png.asset.json";

const SECTION_LABEL: React.CSSProperties = {
  fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase",
  color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10,
};

const PersonCard: React.FC<{ name: string; title: string; photo?: string }> = ({ name, title, photo }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
    {photo ? (
      <img src={photo} alt={name} style={{ width: 44, height: 44, borderRadius: "50%", objectFit: "cover", border: "1px solid #E2E2EC", flexShrink: 0 }} />
    ) : (
      <div style={{
        width: 44, height: 44, borderRadius: "50%",
        background: "linear-gradient(135deg, #43B5BF 0%, #27698F 100%)",
        border: "1px solid #E2E2EC", flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "'Inter', sans-serif",
      }}>
        {name.split(" ").map(n => n[0]).slice(0, 2).join("")}
      </div>
    )}
    <div style={{ minWidth: 0 }}>
      <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.2 }}>{name}</div>
      <div style={{ fontSize: 9, color: "#555567", fontFamily: "'Inter', sans-serif", lineHeight: 1.3, marginTop: 1 }}>{title}</div>
    </div>
  </div>
);

const Footer: React.FC = () => (
  <>
    <div className="page-bottom-cta" style={{ bottom: "0.3in" }}>
      <img src="/assets/learn-more-cta.png" alt="Saiba mais em broadvoice.com" style={{ height: 53 }} />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
    </div>
  </>
);

const Logo: React.FC = () => (
  <div className="logo" style={{ marginBottom: 24 }}>
    <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
  </div>
);

const ExecutiveOverviewGeneralPT: React.FC = () => {
  const handleExportPDF = () => window.print();

  const executives = [
    { name: "Jim Murphy", title: "CEO & Cofundador", photo: jimMurphy.url },
    { name: "Sam Ghahremanpour", title: "Presidente", photo: samGhahremanpour.url },
    { name: "George Mitsopoulos", title: "COO", photo: georgeMitsopoulos.url },
    { name: "Gurdip Jande", title: "Chief Product Officer", photo: gurdipJande.url },
    { name: "Marisa Freeden", title: "Chief Marketing Officer", photo: marisaFreeden.url },
    { name: "Jeff Pritle", title: "Chief Financial Officer", photo: jeffPritle.url },
  ];

  const salesLeaders = [
    { name: "Molly Lozano", title: "Channel Chief, EUA", photo: mollyLozano.url },
    { name: "Ricardo Costa", title: "VP de Vendas, EMEA", photo: ricardoCosta.url },
    { name: "Rodrigo Jaramillo", title: "Head of Sales, LATAM", photo: rodrigoJaramillo.url },
  ];

  const facts = [
    { label: "Fundada", value: "2005" },
    { label: "Sede", value: "Northridge, Califórnia" },
    { label: "Estrutura", value: "Capital privado, com investimento de Private Equity" },
    { label: "Atividade", value: "CCaaS e Experiência do Cliente com IA" },
    { label: "Clientes", value: "Milhares na América do Norte, EMEA e LATAM" },
    { label: "Perfil", value: "Operacionalmente rentável, com crescimento sustentado" },
  ];

  const customerLogos = [
    { src: logoPfizer.url, alt: "Pfizer" },
    { src: logoLoreal.url, alt: "L'Oréal" },
    { src: logoUps.url, alt: "UPS" },
    { src: logoToyota.url, alt: "Toyota" },
    { src: logoHertz.url, alt: "Hertz" },
    { src: logoSiemens.url, alt: "Siemens" },
  ];

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn no-print" onClick={handleExportPDF}>
        Exportar como PDF
      </button>

      {/* ============ PÁGINA 1: Visão Executiva + Liderança ============ */}
      <div className="page page-1" style={{ position: "relative", overflow: "hidden" }}>
        <Logo />

        <h1 className="hero-headline" style={{ fontSize: 40, marginBottom: 6, lineHeight: 1.1 }}>
          Visão <em>Executiva</em>
        </h1>
        <p className="hero-desc" style={{ maxWidth: "100%", fontSize: 12, lineHeight: 1.6, marginBottom: 14 }}>
          A Broadvoice é uma empresa de capital privado, operacionalmente rentável, que disponibiliza soluções de contact center na cloud (CCaaS) e de experiência do cliente potenciadas por Inteligência Artificial na América do Norte, EMEA e LATAM.
        </p>

        {/* Faixa de factos */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 0,
          background: "#F8FAFB",
          border: "1px solid #E2E2EC",
          borderRadius: 10,
          padding: "14px 18px",
          marginBottom: 14,
        }}>
          {facts.map((f, i) => (
            <div key={i} style={{
              padding: "6px 14px",
              borderRight: (i % 3 !== 2) ? "1px solid #E2E2EC" : "none",
              borderBottom: i < 3 ? "1px solid #E2E2EC" : "none",
            }}>
              <div style={{ fontSize: 7.5, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#888899", fontFamily: "'Inter', sans-serif", marginBottom: 3 }}>{f.label}</div>
              <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.3 }}>{f.value}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 18, marginBottom: 18 }}>
          <div>
            <div style={SECTION_LABEL}>Sobre a Empresa</div>
            <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
              <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, marginBottom: 12, fontFamily: "'Inter', sans-serif" }}>
                Há mais de duas décadas que a Broadvoice ajuda as empresas a modernizar a comunicação, a melhorar a relação com o cliente e a apoiar equipas distribuídas, através de tecnologia cloud fiável e escalável.
              </p>
              <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                Com o suporte de investimento de Private Equity e uma sólida base financeira, a Broadvoice alia a agilidade de uma tecnológica focada na inovação à estabilidade e à governação que se esperam de um parceiro de confiança em comunicações empresariais.
              </p>
            </div>

            {/* Missão */}
            <div style={{ marginTop: 14 }}>
              <div style={SECTION_LABEL}>Missão</div>
              <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
                <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                  Dotar as organizações de soluções de comunicação inteligentes que proporcionam experiências de cliente excecionais, reforçam a colaboração das equipas e geram resultados mensuráveis — integrando contact center e Inteligência Artificial numa só plataforma.
                </p>
              </div>
            </div>

            {/* Mapa de presença global */}
            <div style={{ marginTop: 16 }}>
              <div style={SECTION_LABEL}>Presença Global</div>
              <div style={{ padding: 0, marginTop: -32 }}>
                <div style={{
                  position: "relative",
                  width: "100%",
                  aspectRatio: "2 / 1",
                  overflow: "visible",
                }}>
                  <img
                    src={worldMap.url}
                    alt="Presença global"
                    style={{
                      position: "absolute", inset: 0, width: "100%", height: "100%",
                      objectFit: "contain", objectPosition: "center top", opacity: 0.18,
                    }}
                  />
                  {[
                    { name: "Estados Unidos", x: 22, y: 42, labelPos: "bottom" as const },
                    { name: "Colômbia", x: 30, y: 60, labelPos: "bottom" as const },
                    { name: "Portugal", x: 45.2, y: 39, labelPos: "left" as const },
                    { name: "Espanha", x: 48.2, y: 39, labelPos: "right" as const },
                  ].map((loc) => {
                    const labelStyle: React.CSSProperties = {
                      position: "absolute",
                      fontSize: 8, fontWeight: 700, color: "#1A1A2E",
                      fontFamily: "'Inter', sans-serif", whiteSpace: "nowrap",
                      letterSpacing: "0.04em", textTransform: "uppercase",
                    };
                    if (loc.labelPos === "left") {
                      Object.assign(labelStyle, { right: "calc(100% + 6px)", top: "50%", transform: "translateY(-50%)" });
                    } else if (loc.labelPos === "right") {
                      Object.assign(labelStyle, { left: "calc(100% + 6px)", top: "50%", transform: "translateY(-50%)" });
                    } else {
                      Object.assign(labelStyle, { left: "50%", top: "calc(100% + 4px)", transform: "translateX(-50%)" });
                    }
                    return (
                      <div key={loc.name} style={{
                        position: "absolute", left: `${loc.x}%`, top: `${loc.y}%`,
                        transform: "translate(-50%, -50%)",
                      }}>
                        <span style={{
                          display: "block", width: 6, height: 6, borderRadius: "50%",
                          background: "#43B5BF",
                          boxShadow: "0 0 0 2px rgba(67,181,191,0.22), 0 0 0 4px rgba(67,181,191,0.10)",
                        }} />
                        <span style={labelStyle}>{loc.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          <div>
            <div style={SECTION_LABEL}>Liderança Executiva</div>
            <div style={{
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              {executives.map((p, i) => <PersonCard key={i} {...p} />)}
            </div>
            <div style={{ ...SECTION_LABEL, marginTop: 14 }}>Liderança Comercial</div>
            <div style={{
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              {salesLeaders.map((p, i) => <PersonCard key={i} {...p} />)}
            </div>
          </div>
        </div>

        <Footer />
      </div>

      {/* ============ PÁGINA 2: Plataforma, Confiança, Clientes ============ */}
      <div className="page page-2" style={{ position: "relative", overflow: "hidden" }}>
        <Logo />

        <svg width="0" height="0" style={{ position: "absolute" }}>
          <defs>
            <linearGradient id="exec-icon-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#43B5BF" />
              <stop offset="100%" stopColor="#27698F" />
            </linearGradient>
          </defs>
        </svg>

        {/* 1. Portefólio de Soluções */}
        <div style={SECTION_LABEL}>Portefólio de Soluções</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14, marginBottom: 18 }}>
          {[
            {
              Icon: Headphones, title: "Contact Center", sub: "CCaaS",
              items: [
                "Atendimento omnicanal",
                "Encaminhamento e gestão de filas inteligente",
                "Otimização da força de trabalho e analítica",
                "Ferramentas de supervisão e performance",
              ],
            },
            {
              Icon: Sparkles, title: "Experiência do Cliente com IA", sub: "GoAI Suite",
              items: [
                "IA conversacional e automação",
                "Apoio ao agente com IA",
                "Resumos e insights automáticos",
                "Inteligência aplicada à experiência do cliente",
              ],
            },
          ].map((c, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <c.Icon size={20} style={{ stroke: "url(#exec-icon-grad)", flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>{c.title}</div>
                  <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.12em", color: "#43B5BF", fontFamily: "'Inter', sans-serif" }}>{c.sub}</div>
                </div>
              </div>
              {c.items.map((b, j) => (
                <div key={j} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                  <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.55 }}>•</span>
                  <span style={{ fontSize: 11, color: "#555567", lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{b}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* 2 + 3. Segurança, Conformidade e Fiabilidade */}
        <div style={SECTION_LABEL}>Segurança, Conformidade e Fiabilidade</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 18 }}>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Lock size={16} style={{ color: "#43B5BF" }} />
              <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Segurança e Conformidade</div>
            </div>
            {[
              "Ambiente auditado SOC 2 Tipo 1, alinhado com os controlos reconhecidos pela indústria",
              "Fluxos em conformidade com HIPAA para dados clínicos protegidos",
              "Práticas de privacidade e tratamento de dados alinhadas com o RGPD",
            ].map((b, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.6 }}>•</span>
                <span style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
              </div>
            ))}
          </div>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Server size={16} style={{ color: "#43B5BF" }} />
              <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Fiabilidade da Plataforma</div>
            </div>
            {[
              "Arquitetura cloud de nível empresarial, concebida para resiliência",
              "Infraestrutura de alta disponibilidade, com redundância geográfica",
              "Monitorização proativa e excelência operacional",
              "Planos robustos de recuperação de desastres e continuidade do negócio",
            ].map((b, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.6 }}>•</span>
                <span style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Solidez Financeira */}
        <div style={SECTION_LABEL}>Solidez e Estabilidade Financeira</div>
        <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px", background: "#F8FAFB", marginBottom: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
            <TrendingUp size={16} style={{ color: "#43B5BF" }} />
            <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Operacionalmente rentável. Suportada por Private Equity.</div>
          </div>
          <p style={{ fontSize: 12, color: "#555567", lineHeight: 1.65, margin: 0, fontFamily: "'Inter', sans-serif" }}>
            Operacionalmente rentável, com um longo historial de crescimento sustentado e gestão financeira disciplinada. O apoio de Private Equity assegura capital estratégico e os recursos necessários para o investimento contínuo em produto, infraestrutura, segurança e sucesso do cliente.
          </p>
        </div>

        {/* 5. Porquê Broadvoice */}
        <div style={SECTION_LABEL}>Porque é que as Organizações Escolhem a Broadvoice</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginBottom: 18 }}>
          {[
            { t: "Solidez Financeira", d: "Operacionalmente rentável e suportada por Private Equity" },
            { t: "Confiança e Segurança", d: "Controlos e governação alinhados com SOC 2" },
            { t: "Fiabilidade", d: "Infraestrutura de nível empresarial" },
            { t: "Foco no Cliente", d: "Equipas dedicadas de implementação e sucesso" },
            { t: "Inovação", d: "Investimento contínuo em IA e CX" },
          ].map((w, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "12px 13px" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 4 }}>{w.t}</div>
              <div style={{ fontSize: 10, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{w.d}</div>
            </div>
          ))}
        </div>

        {/* 6. Logos */}
        <div style={SECTION_LABEL}>Marcas de Referência que Confiam na Broadvoice</div>
        <div style={{
          border: "1px solid #E2E2EC", borderRadius: 10, padding: "4px 16px",
          display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12,
          alignItems: "center", justifyItems: "center",
          background: "#FFFFFF",
          marginTop: -2,
        }}>
          {customerLogos.map((l, i) => {
            const isSiemens = l.alt === "Siemens";
            return (
              <img key={i} src={l.src} alt={l.alt}
                style={{
                  maxHeight: isSiemens ? 50 : 34,
                  maxWidth: "100%",
                  objectFit: "contain",
                  filter: "grayscale(100%)",
                }} />
            );
          })}
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default ExecutiveOverviewGeneralPT;
