import React from "react";
import "./GoEngageDatasheet.css";

const DOC_NAME = "How To: Navigate Interview Ownership & Focus Areas";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>{DOC_NAME}</div>
    <div>© Broadvoice 2026 · Internal</div>
  </div>
);

const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2
    className="section-title"
    style={{
      fontSize: 22,
      marginBottom: 8,
      marginTop: 2,
      display: "block",
      lineHeight: 1.2,
      background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)",
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      WebkitTextFillColor: "transparent",
    }}
  >
    {children}
  </h2>
);

const Eyebrow: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "#43B5BF",
      marginBottom: 6,
      marginTop: 12,
    }}
  >
    {children}
  </div>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Ordered: React.FC<{ items: React.ReactNode[] }> = ({ items }) => (
  <ol
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.65,
      paddingLeft: 22,
      margin: "6px 0 10px",
      listStyleType: "decimal",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 4 }}>
        {it}
      </li>
    ))}
  </ol>
);

const Bullets: React.FC<{ items: React.ReactNode[] }> = ({ items }) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      paddingLeft: 20,
      margin: "6px 0 10px",
      listStyleType: "disc",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 4 }}>
        {it}
      </li>
    ))}
  </ul>
);

const Callout: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#1A1A2E",
      background: "#EEF7F8",
      borderLeft: "3px solid #43B5BF",
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const ImageSlot: React.FC<{ height?: number }> = ({ height = 150 }) => (
  <div style={{ width: "100%", height, background: "#FFFFFF", margin: "8px 0 12px" }} />
);

// Branded table
const DataTable: React.FC<{
  headers: string[];
  rows: React.ReactNode[][];
  colWidths?: (string | number)[];
}> = ({ headers, rows, colWidths }) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      overflow: "hidden",
      margin: "10px 0 14px",
    }}
  >
    <table
      style={{
        width: "100%",
        borderCollapse: "collapse",
        fontFamily: "'Inter', sans-serif",
        fontSize: 10.5,
      }}
    >
      <thead>
        <tr style={{ background: "linear-gradient(90deg, #27698F, #43B5BF)" }}>
          {headers.map((h, i) => (
            <th
              key={i}
              style={{
                textAlign: "left",
                color: "#FFFFFF",
                padding: "10px 12px",
                fontWeight: 700,
                fontSize: 10.5,
                letterSpacing: "0.03em",
                width: colWidths?.[i],
              }}
            >
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, ri) => (
          <tr
            key={ri}
            style={{
              background: ri % 2 === 0 ? "#FFFFFF" : "#F7F9FB",
              borderTop: ri === 0 ? "none" : "1px solid #E2E2EC",
            }}
          >
            {r.map((c, ci) => (
              <td
                key={ci}
                style={{
                  padding: "10px 12px",
                  color: "#1A1A2E",
                  verticalAlign: "top",
                  lineHeight: 1.5,
                }}
              >
                {c}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

const Card: React.FC<{ title?: string; children: React.ReactNode }> = ({ title, children }) => (
  <div
    style={{
      border: "1px solid #E2E2EC",
      borderRadius: 8,
      padding: "14px 18px 12px",
      marginBottom: 14,
      background: "#FFFFFF",
    }}
  >
    {title && (
      <h3
        style={{
          fontFamily: "'Instrument Sans', sans-serif",
          fontSize: 15,
          fontWeight: 700,
          color: "#27698F",
          margin: "0 0 8px",
        }}
      >
        {title}
      </h3>
    )}
    {children}
  </div>
);

// Appendix helper — team block with heading + table
const TeamBlock: React.FC<{
  department?: string;
  team: string;
  region?: string;
  rows: [string, string, string, string][];
}> = ({ department, team, region, rows }) => (
  <div style={{ marginBottom: 16 }}>
    {department && <Eyebrow>{department}</Eyebrow>}
    <h3
      style={{
        fontFamily: "'Instrument Sans', sans-serif",
        fontSize: 16,
        fontWeight: 700,
        color: "#1A1A2E",
        margin: "4px 0 2px",
      }}
    >
      {team}
      {region && (
        <span style={{ fontSize: 11, fontWeight: 500, color: "#888899", marginLeft: 8 }}>
          {region}
        </span>
      )}
    </h3>
    <DataTable
      headers={["Interview", "Primary Interviewer", "Backup Interviewer", "Team Technical Focus"]}
      colWidths={["10%", "22%", "22%", "46%"]}
      rows={rows.map((r) => [
        <strong style={{ color: "#27698F" }}>{r[0]}</strong>,
        r[1],
        r[2],
        r[3],
      ])}
    />
  </div>
);

const InterviewOwnershipGuide: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 8.5in;
          padding: 0.55in 0.7in;
        }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 — Cover + Overview + How to Use ===== */}
      <div className="page">
        <PageHeader eyebrow="Internal Guide" />

        <div className="partner-hero" style={{ marginTop: 30, marginBottom: 10 }}>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "#43B5BF",
              marginBottom: 10,
            }}
          >
            How To
          </div>
          <h1 className="hero-headline" style={{ fontSize: 34, lineHeight: 1.05, marginBottom: 6 }}>
            Navigate Interview <em>Ownership</em> & Focus Areas
          </h1>
          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Standardizing how Broadvoice assesses every candidate — consistently, fairly, and against
            the competencies that matter most for each role.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />

        <PageBody>
          <Body>
            This guide standardizes the interview process across the organization to ensure every
            candidate is assessed <strong>consistently, fairly, and against the competencies that
            matter most</strong> for each role. It defines <strong>interview ownership, focus areas,
            responsibilities, and evaluation criteria</strong>, strengthening collaboration between
            Talent Acquisition, Hiring Managers, and Leadership, reducing interview overlap and
            bias, and enabling faster, higher-quality hiring decisions.
          </Body>

          <SectionTitle>Interview Process Overview</SectionTitle>
          <Bullets
            items={[
              <><strong>TA Interview:</strong> Initial screening, motivation, and cultural fit.</>,
              <><strong>1st HM Interview:</strong> Technical or functional assessment + team fit.</>,
              <><strong>2nd HM Interview</strong> (if needed): Deep dive into expertise, strategy, or leadership.</>,
              <><strong>3rd HM Interview</strong> (if needed): Advanced evaluation of leadership and impact.</>,
              <><strong>Offer:</strong> Final approval.</>,
            ]}
          />

          <SectionTitle>How to Use This Document</SectionTitle>
          <Ordered
            items={[
              <><strong>Find your team</strong> — Go to the Department / Team column in the Appendices.</>,
              <><strong>Understand the steps</strong> — Review the interview flow and what each step is designed to assess.</>,
              <><strong>Check focus areas</strong> — Each Hiring Manager has focus areas to avoid question repetition.</>,
              <><strong>Identify the Backup if needed</strong> — Use the backup interviewer if the primary is unavailable.</>,
              <><strong>Document feedback</strong> — Record feedback in the ATS or internal system within 24H using standard fields.</>,
            ]}
          />

          <Callout>
            Use <strong>filters</strong> or <strong>CTRL+F</strong> to find info fast. Check{" "}
            <strong>Focus Areas</strong> when preparing questions or exercises. Organized by team →
            interview step → focus → backup.
          </Callout>
        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 — Process by Seniority Level ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 01" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>Interview Process by Seniority Level</SectionTitle>
          <Body>
            This page defines <strong>how many interviews</strong> are needed depending on role
            seniority and the overall objective of the process.
          </Body>

          <DataTable
            headers={["Level", "Process Steps", "HM Interviews", "Main Objective"]}
            colWidths={["22%", "26%", "14%", "38%"]}
            rows={[
              [
                <><strong>Junior</strong><br /><span style={{ color: "#888899" }}>S1–S3 · P1–P2</span></>,
                "TA → HM → Offer",
                "1",
                "Assess foundations, potential, and cultural fit",
              ],
              [
                <><strong>Mid-level</strong><br /><span style={{ color: "#888899" }}>P3–P4</span></>,
                "TA → HM → HM → Offer",
                "2",
                "Assess autonomy, technical depth, and team integration",
              ],
              [
                <><strong>Senior</strong><br /><span style={{ color: "#888899" }}>P5–P6</span></>,
                "TA → HM → HM → HM → Offer",
                "3",
                "Assess ownership, strategy, and cross-functional impact",
              ],
              [
                <><strong>Leadership / Management</strong><br /><span style={{ color: "#888899" }}>M2–M6 · E7–E8</span></>,
                "TA → HM → HM → HM → HM → Offer",
                "4",
                "Assess vision, leadership style, and organizational alignment",
              ],
            ]}
          />

          <Card title="Notes">
            <Bullets
              items={[
                "Practical challenges may be added for technical/creative roles.",
                "Additional interviews can be added if needed, but each must have a different focus area.",
                "Talent Acquisition owns coordination and candidate experience throughout the process.",
              ]}
            />
          </Card>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 3 — What Each Interview Must Assess ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 02" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>What Each Interview Must Assess</SectionTitle>
          <Body>
            The focus areas below define <strong>what each interview stage is responsible for
            evaluating</strong>. These apply to <strong>all teams</strong>.
          </Body>

          <DataTable
            headers={["Interview Step", "Owner", "Focus Areas"]}
            colWidths={["22%", "24%", "54%"]}
            rows={[
              [
                <strong>TA Interview</strong>,
                "Talent Acquisition",
                "Motivation · Communication · Cultural alignment · Understanding of the role",
              ],
              [
                <strong>1st Hiring Manager</strong>,
                "Direct Manager / Tech Lead",
                "Core technical or functional skills · Problem solving · Communication clarity · Team fit, role fundamentals",
              ],
              [
                <strong>2nd Hiring Manager</strong>,
                "Senior Peer / Cross-functional",
                "System thinking · Architectural trade-offs, failure handling · Scalability & performance mindset · Collaboration style, product thinking",
              ],
              [
                <strong>3rd Hiring Manager</strong>,
                "Head of Department",
                "Ownership · Strategic alignment · Decision-making approach · Cross-team impact, leadership behaviors",
              ],
              [
                <strong>4th Hiring Manager</strong>,
                "Director / VP / Board",
                "Vision · Organizational impact · Executive presence · Leadership style, long-term thinking",
              ],
            ]}
          />

          <Card title="Best Practices">
            <Bullets
              items={[
                <>Use <strong>structured interview guides</strong> and competency-based questions.</>,
                <>All feedback should be submitted in the ATS within <strong>24 hours</strong>.</>,
                <><strong>Avoid repetition</strong> between interviews — each step has a clear purpose.</>,
                "Ensure bias-free and fair evaluation.",
                "Communicate clearly with candidates at all stages.",
              ]}
            />
          </Card>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 4 — Evidence Behind Best Practices ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 03" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>Why These Best Practices Matter</SectionTitle>
          <Body>
            The research below supports the three highest-leverage disciplines Broadvoice expects
            every interviewer to follow.
          </Body>

          <Card title="01 · Use Structured Interview Guides and Competency-Based Questions">
            <Bullets
              items={[
                <>Structured interviews are <strong>significantly better</strong> at predicting on-the-job performance than unstructured interviews.</>,
                <>The <strong>UK Government</strong> recommends structured interviews for fairer, more consistent candidate comparisons.</>,
                "Structured interviews reduce bias and discrimination, improving fairness and consistency in hiring.",
              ]}
            />
          </Card>

          <Card title="02 · Submit All Feedback Within 24 Hours">
            <Bullets
              items={[
                "60% of candidates withdraw from recruitment processes they perceive as too long.",
                "Delayed feedback can add ~8 days per candidate, increasing the risk of losing them to other offers.",
                "Delayed feedback increases time-to-hire and the loss of qualified candidates.",
              ]}
            />
          </Card>

          <Card title="03 · Avoid Repetition Between Interviews">
            <Bullets
              items={[
                <>Different interview stages should assess <strong>distinct competencies</strong> to maximize the validity of the selection process.</>,
                <>Recruitment experts recommend that each interview should have <strong>clear criteria</strong> to improve decision quality and candidate experience.</>,
              ]}
            />
          </Card>

          <Body>
            See the <strong>Evidence and References</strong> appendix at the end of this guide for
            source studies.
          </Body>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 — Interview Feedback Principles / SBI ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 04" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>Interview Feedback Principles</SectionTitle>
          <Callout>
            Every interviewer should provide feedback based on <strong>evidence</strong>, not
            impressions.
          </Callout>

          <SubHead>Good feedback is:</SubHead>
          <Ordered
            items={[
              <><strong>Specific</strong> — Describe what the candidate actually said or did.</>,
              <><strong>Competency-based</strong> — Evaluate only the competencies assigned to your interview stage.</>,
              <><strong>Objective</strong> — Avoid subjective opinions or personal preferences.</>,
              <><strong>Balanced</strong> — Include both strengths and concerns.</>,
              <><strong>Actionable</strong> — Help the hiring team understand why you recommend Hire or No Hire.</>,
            ]}
          />

          <SectionTitle>The SBI Model</SectionTitle>
          <Body>
            A useful way to structure feedback is the <strong>Situation · Behavior · Impact</strong>{" "}
            (SBI) model. Instead of writing an opinion, explain:
          </Body>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <Card title="1 · Situation">
              <Body>When did it happen?</Body>
            </Card>
            <Card title="2 · Behavior">
              <Body>What did the candidate actually do or say?</Body>
            </Card>
            <Card title="3 · Impact">
              <Body>Why is this relevant for the role?</Body>
            </Card>
          </div>

          <Card title="Example">
            <Body>
              "During the discussion about handling priorities <em>(Situation)</em>, the candidate
              described several tasks they were managing but struggled to explain how they
              prioritized them <em>(Behavior)</em>. This made it difficult to assess their ability
              to manage competing priorities effectively in a fast-paced environment{" "}
              <em>(Impact)</em>."
            </Body>
          </Card>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 — Rippling Interview Guide + Good vs Poor Feedback ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 05" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>Use the Interview Guide in Rippling</SectionTitle>
          <Body>
            Each interview in Rippling already contains <strong>structured competencies</strong> and{" "}
            <strong>evaluation criteria</strong>. When completing feedback:
          </Body>
          <Bullets
            items={[
              "Rate each competency.",
              "Add evidence for your rating.",
              "Summarize the overall recommendation.",
            ]}
          />

          <ImageSlot height={130} />

          <Callout>
            Avoid introducing new evaluation criteria that were not part of the interview guide.
          </Callout>

          <SectionTitle>Good vs. Poor Feedback</SectionTitle>
          <DataTable
            headers={["✗ Poor Feedback", "✓ Better Feedback"]}
            colWidths={["30%", "70%"]}
            rows={[
              [
                "Strong candidate.",
                <>Clearly <strong>explained</strong> API versioning strategy, discussed <strong>trade-offs</strong> between REST and GraphQL, and answered follow-up questions with <strong>confidence</strong>.</>,
              ],
              [
                "Good communication.",
                <>Structured answers logically, <strong>clarified assumptions</strong> before solving the problem, and adapted explanations to the audience.</>,
              ],
              [
                "Didn't like the candidate.",
                <>Frequently avoided answering behavioral questions directly and provided <strong>limited examples</strong> demonstrating <strong>ownership</strong>.</>,
              ],
              [
                "Good cultural fit.",
                <>Demonstrated <strong>collaborative behavior</strong> by describing cross-functional projects, giving concrete examples of conflict resolution and knowledge sharing.</>,
              ],
              [
                "The candidate is arrogant.",
                <>The candidate interrupted the interviewer several times while discussing previous projects <em>(interpretation vs observation)</em>.</>,
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 — Use Evidence + Stay Within Scope ===== */}
      <div className="page">
        <PageHeader eyebrow="Section 06" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>Use Evidence</SectionTitle>
          <Body>
            Base your feedback on what the candidate <strong>said or did</strong>, not on
            impressions or opinions.
          </Body>

          <Card>
            <SubHead>Instead of writing: "Excellent technical skills"</SubHead>
            <Body>
              Write: "Designed a <strong>scalable event-driven architecture</strong>, explained why
              Kafka was preferred over synchronous communication, and discussed{" "}
              <strong>monitoring</strong> and <strong>failure recovery</strong>."
            </Body>
          </Card>

          <Card>
            <SubHead>Instead of writing: "Leadership was weak"</SubHead>
            <Body>
              Write: "Could describe day-to-day management activities but struggled to explain{" "}
              <strong>strategic decision-making, prioritization</strong>, and{" "}
              <strong>influencing stakeholders</strong>."
            </Body>
          </Card>

          <SectionTitle>Stay Within Your Scope</SectionTitle>
          <Body>Evaluate only the focus areas assigned to your interview stage.</Body>

          <DataTable
            headers={["Interview", "Evaluate", "Don't Evaluate"]}
            colWidths={["18%", "44%", "38%"]}
            rows={[
              [<strong>TA</strong>, "Motivation, communication, culture", "Technical depth"],
              [<strong>1st HM</strong>, "Technical fundamentals", "Executive leadership"],
              [<strong>2nd HM</strong>, "Architecture, system thinking", "Motivation already assessed"],
              [<strong>Leadership</strong>, "Strategy, impact, organizational alignment", "Re-testing technical fundamentals"],
            ]}
          />

          <Callout>
            The Interview Guide drives the interview. The written feedback explains the decision.{" "}
            <strong>Ratings alone are not sufficient</strong> — every scope should be supported by
            concise evidence and stay within your assigned interview ownership.
          </Callout>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 8 — Appendices Cover ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendices" />
        <PageBody>
          <div style={{ height: 20 }} />
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "#43B5BF",
              marginBottom: 8,
            }}
          >
            Appendices
          </div>
          <h1 className="hero-headline" style={{ fontSize: 30, lineHeight: 1.05, marginBottom: 10 }}>
            Interview <em>Ownership</em> by Team
          </h1>
          <Body>
            This section defines <strong>who interviews at each stage</strong> and the{" "}
            <strong>technical focus areas</strong> specific to each team. Locate your department in
            the index below and navigate to the corresponding table.
          </Body>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            {[
              "Software Engineering",
              "Site Reliability Engineering",
              "Quality Assurance",
              "Employee Experience",
              "Product Management",
              "Customer Success Management",
              "Service Delivery",
              "Business Technical Support",
              "Business Systems",
              "Finance",
              "Sales",
              "Marketing",
            ].map((d) => (
              <div
                key={d}
                style={{
                  border: "1px solid #E2E2EC",
                  borderRadius: 6,
                  padding: "10px 14px",
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  fontWeight: 600,
                  color: "#1A1A2E",
                  background: "#F7F9FB",
                }}
              >
                {d}
              </div>
            ))}
          </div>

          <Card title="How to Read This Section">
            <Bullets
              items={[
                "Find your team.",
                "Review who conducts each interview step.",
                "Check the technical focus areas.",
                "Use the backup if the primary interviewer is unavailable.",
              ]}
            />
          </Card>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 9 — Software Engineering: Team V&T + Team D,F&I ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Engineering" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Software Engineering Department</SectionTitle>
          <TeamBlock
            team="Team V & T"
            rows={[
              [
                "1st HM",
                "Software Engineer, Team Leader",
                "Software Engineer, Director",
                "NodeJS / NestJS · Kafka · Scalability · ReactJS · Distributed systems · REST / API design · Problem-solving · Redis · PostgreSQL",
              ],
              [
                "2nd HM",
                "Software Engineer, Director",
                "Software Engineer, Manager",
                "System design · Product mindset · Architectural trade-offs · Failure handling · Production-level decision making",
              ],
            ]}
          />
          <TeamBlock
            team="Team D, F & I"
            rows={[
              [
                "1st HM",
                "Software Engineer, Manager",
                "Software Engineer, Director",
                "NestJS · Kafka · Data pipelines · ReactJS · Scalability · REST / API design · LLM integrations · Redis · AI-driven architectures · PostgreSQL · Analytics workflow",
              ],
              [
                "2nd HM",
                "Software Engineer, Director",
                "Software Engineer, Team Leader",
                "System design · Failure handling · Architectural trade-offs · Production-level decision making",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 10 — SW Eng: Team U, Communicator, UC ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Engineering" />
        <PageBody>
          <div style={{ height: 16 }} />
          <TeamBlock
            team="Team U"
            rows={[
              [
                "1st HM",
                "Software Engineer, Manager",
                "Senior Software Engineer",
                "Ruby on Rails · Scalability · REST / API design · Problem-solving · Distributed systems",
              ],
              [
                "2nd HM",
                "Software Engineer, VP",
                "Software Engineer, Manager",
                "System design · Failure handling · Architectural trade-offs · Production-level decision making",
              ],
            ]}
          />
          <TeamBlock
            team="Communicator Team"
            rows={[
              [
                "1st HM",
                "Software Engineer, Manager",
                "Software Engineer, Team Leader",
                "ReactJS · NodeJS · Problem-solving · Technical understanding · Stakeholder collaboration",
              ],
              [
                "2nd HM",
                "Software Engineer, VP",
                "Software Engineer, Manager",
                "System thinking · Failure handling · Architectural trade-offs · Production-level decision making",
              ],
            ]}
          />
          <TeamBlock
            team="UC Team"
            rows={[
              [
                "1st HM",
                "Core Telephony Engineer, Manager",
                "Senior Core Telephony Engineer",
                "SIP · Networking (TCP/IP, firewalls) · Linux · Kamailio · FreeSWITCH · Incident handling · VoIP troubleshooting · Teamwork",
              ],
              [
                "2nd HM",
                "Software Engineer / SRE, VP",
                "Core Telephony Engineer, Manager",
                "Voice platform architecture · SIP trunks · Ansible · SBCs · High availability · CI/CD · Docker · Monitoring (Grafana, Prometheus, ELK) · Reliability & observability · Production trade-offs",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 11 — SRE: SRE, NOC, IT ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · SRE" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Site Reliability Engineering Department</SectionTitle>
          <TeamBlock
            team="SRE Team"
            rows={[
              [
                "1st HM",
                "SRE, Manager",
                "SRE Principal",
                "SRE Practices · Backups, patching · Linux Administration · Virtualization · Configuration management · Storage · Documentation, troubleshooting · AWS, Terraform, Ansible · Communication",
              ],
              [
                "2nd HM",
                "SRE Principal",
                "Infrastructure, Director",
                "TCP/IP, routing, firewalls · Operational playbooks · Automation · Tooling improvement · Multi-datacenter / multi-region scalability",
              ],
            ]}
          />
          <TeamBlock
            team="NOC Team"
            rows={[
              [
                "1st HM",
                "Infrastructure, Director",
                "SRE Principal",
                "Linux Administration · Escalation · Bash/Python scripting · On-call collaboration · Networking · Process adherence · Monitoring, alarms, tickets",
              ],
              [
                "2nd HM",
                "SRE Principal",
                "SRE, Manager",
                "Operational excellence · Playbooks execution · AWS & VoIP/SIP concepts · Automation & scripting for operations",
              ],
            ]}
          />
          <TeamBlock
            team="IT Team"
            rows={[
              [
                "1st HM",
                "IT Global Director",
                "Senior IT Specialist",
                "IT Support · Organization · Windows/macOS · Time Management · Hardware/software troubleshooting · Onboarding/offboarding",
              ],
              [
                "2nd HM",
                "Senior IT Specialist",
                "SRE, VP",
                "Entra · Intune · M365 · Exchange · Teams · Jamf · MDM/EDR · Ticketing & SLA · Asset inventory · Process improvement · Remote access · Global support adaptability",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 12 — Security + QA Analyst + QA Engineering ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Security & QA" />
        <PageBody>
          <div style={{ height: 16 }} />
          <TeamBlock
            team="Security Team"
            rows={[
              [
                "1st HM",
                "Information Security Officer",
                "SRE, VP",
                "Information & cybersecurity · Business continuity & resilience · Service management · Risk identification & mitigation",
              ],
              [
                "2nd HM",
                "SRE, VP",
                "Global IT, Director",
                "Culture & leadership fit · Security architecture · Compliance & regulatory awareness · Technical problem-solving · Cross-functional collaboration",
              ],
            ]}
          />
          <SectionTitle>Quality Assurance Department</SectionTitle>
          <TeamBlock
            team="QA Analyst Team"
            rows={[
              [
                "1st HM",
                "QA Analyst, Team Leader & QA Director",
                "QA Team Leader",
                "QA methodologies · Analytical thinking · Test planning & test cases · Stakeholder communication",
              ],
              [
                "2nd HM",
                "QA Director",
                "Senior QA Engineer",
                "Manual testing in complex systems · Test strategies · QA KPIs · Scalable QA processes · Cross-functional testing",
              ],
            ]}
          />
          <TeamBlock
            team="QA Engineering Team"
            rows={[
              [
                "1st HM",
                "QA Engineer, Team Leader",
                "QA Director",
                "Automation testing · Analytical thinking · Testing methodologies · Teamwork · JavaScript",
              ],
              [
                "2nd HM",
                "QA Director",
                "Senior QA Engineer",
                "Cypress · Playwright · K6 · Mobile testing · CI/CD (Jenkins, Codefresh) · Git/Bitbucket · Framework optimization",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 13 — Employee Experience + Talent Acquisition + Product + Design ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · People & Product" />
        <PageBody>
          <div style={{ height: 8 }} />
          <SectionTitle>Employee Experience Department</SectionTitle>
          <TeamBlock
            team="Employee Experience Team"
            rows={[
              [
                "1st HM",
                "EX, Director",
                "HRBP",
                "Global People Ops · Communication · Benefits & compensation · HRIS optimization",
              ],
              [
                "2nd HM",
                "EX, VP",
                "EX, Director",
                "Org change · Stakeholder education · HR metrics & compliance · Strategic policy thinking",
              ],
            ]}
          />
          <TeamBlock
            team="Talent Acquisition Team"
            rows={[
              [
                "1st HM",
                "Senior Talent Acquisition Specialist",
                "HRBP",
                "Global Recruiting · Sourcing · ATS/Greenhouse · EN/PT Communication · Relationship building · Technical knowledge",
              ],
              [
                "2nd HM",
                "Talent Acquisition Director",
                "EX, VP",
                "TA process optimization · Scalability mindset · Onboarding & compliance · Job leveling · Collaboration with EX/DEI",
              ],
            ]}
          />
          <SectionTitle>Product Management Department</SectionTitle>
          <TeamBlock
            team="Product Team"
            rows={[
              [
                "1st HM",
                "VP, Product",
                "Senior Product Manager",
                "CCaaS/SaaS · Stakeholder management · Roadmap, discovery, usability, scalability · Monitoring & reliability",
              ],
              [
                "2nd HM",
                "Chief Product Officer",
                "VP, Product",
                "Platform strategy · KPIs · AI workflows · Multi-tenant scale · Cross-team leadership",
              ],
            ]}
          />
          <TeamBlock
            team="Design Team"
            rows={[
              [
                "1st HM",
                "UX/UI Designer, Team Leader",
                "Senior UX/UI Designer",
                "UX research · Problem-solving · Interviews, personas, journeys",
              ],
              [
                "2nd HM",
                "Chief Product Officer",
                "UX/UI Designer, Team Leader",
                "UX/UI · Figma, prototypes · Data-driven design · Business alignment",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>


      {/* ===== PAGE 15 — CSM + Account Management ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Customer Success" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Customer Success Management Department</SectionTitle>
          <TeamBlock
            team="Customer Success Global Team"
            region="U.S., LATAM, EMEA"
            rows={[
              [
                "1st HM",
                "CSM, Team Leader / CSM, Manager",
                "Senior CSM",
                "Customer relationship management · Trust building · Operational workflows · Prioritization · Problem solving · Risk identification & mitigation · CRM usage · Case management · Customer adoption · Communication",
              ],
              [
                "2nd HM",
                "CSM, Director",
                "Senior Director, CSM",
                "Customer success strategy · Business acumen · Retention & renewals · Executive communication · Handling escalations · Stakeholder management · Cross-functional collaboration · Customer lifecycle management · Data-driven decision making",
              ],
            ]}
          />
          <TeamBlock
            team="Account Management Team"
            rows={[
              [
                "1st HM",
                "Account Management, Director",
                "Senior Account Manager",
                "Account planning · Opportunity identification · Upsell & cross-sell · Forecasting accuracy · Pipeline management · CRM discipline · Negotiation · Executive communication · Revenue growth mindset",
              ],
              [
                "2nd HM",
                "Customer Success, VP",
                "Account Management, Director",
                "Strategic account management · Retention & renewals · Customer value realization · Stakeholder management · Business acumen · Executive relationships · Risk management · Cross-functional collaboration · Long-term account growth",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 16 — Service Delivery + GoAI ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Service Delivery" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Service Delivery Department</SectionTitle>
          <TeamBlock
            team="Service Delivery Team"
            region="U.S., LATAM, EMEA"
            rows={[
              [
                "1st HM",
                "Service Delivery, Manager",
                "Director, Service Delivery",
                "Project lifecycle · Scheduling & coordinating calls · Telecom/B2B SaaS familiarity · Customer & partner communication · Installation · Order review, verification and documentation accuracy",
              ],
              [
                "2nd HM",
                "Director, Service Delivery",
                "Senior VP, CSM",
                "Implementation lifecycle ownership · Integrations · Internal collaboration · KPIs · Technical proficiency · Problem-solving · Escalation management",
              ],
            ]}
          />
          <TeamBlock
            team="GoAI Team"
            rows={[
              [
                "1st HM",
                "GoAI Manager",
                "GoAI Team Leader",
                "End-to-end project lifecycle · Customer & service delivery · Communication · Automation, AI & Voice solutions · Documentation & workshop facilitation · Cross-functional collaboration",
              ],
              [
                "2nd HM",
                "GoAI Team Leader",
                "Service Delivery, Director",
                "CCaaS/Telecom/B2B SaaS project experience · Technical knowledge · Integrations · Customer readiness & post-go-live support · KPI tracking · Continuous improvement",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 17 — Business Technical Support ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Support" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Business Technical Support Department</SectionTitle>
          <TeamBlock
            team="Technical Support I & Residential Team"
            region="U.S., LATAM, EMEA"
            rows={[
              [
                "1st HM",
                "Technical Support Coordinator (UCaaS) / Customer Service Manager (CCaaS)",
                "Technical Support Director (CCaaS & UCaaS)",
                "Telecom & CCaaS troubleshooting · Prioritization · Customer focus",
              ],
              [
                "2nd HM",
                "Technical Support Director (CCaaS & UCaaS)",
                "Chief Operations Officer",
                "Technical escalation · Documentation · Collaboration",
              ],
            ]}
          />
          <TeamBlock
            team="Technical Support II & Technical Support Specialist II Team"
            rows={[
              [
                "1st HM",
                "Technical Support II, Team Leader (CCaaS)",
                "Technical Support, Director (CCaaS & UCaaS)",
                "SIP/RTP troubleshooting · VoIP call flow analysis · SIP trunking environments · NAT traversal & networking fundamentals · Log analysis (call traces, SIP ladders) · Incident handling & escalation · Customer communication in troubleshooting scenarios · Ticketing accuracy & prioritization",
              ],
              [
                "2nd HM",
                "Technical Support Manager / Director (CCaaS)",
                "Chief Operations Officer",
                "Advanced VoIP diagnostics · Root cause analysis · Operational ownership of support processes · SLA management · Escalation governance · Cross-functional collaboration · Tooling · Support strategy & continuous improvement · Knowledge base & documentation",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 18 — Business Systems: Reporting + Salesforce ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Business Systems" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Business Systems Department</SectionTitle>
          <TeamBlock
            team="Reporting Services Team"
            rows={[
              [
                "1st HM",
                "Reporting Services Manager",
                "BI Developer",
                "SQL & data analysis · Data modeling & ETL · Reporting & Dashboards BI tools · Problem solving · Reporting project experience",
              ],
              [
                "2nd HM",
                "Business Systems Manager",
                "Chief Operations Officer",
                "Stakeholder management · Communication · Cross-functional collaboration · Ownership & accountability · Prioritization & decision making · Team fit & growth mindset",
              ],
            ]}
          />
          <TeamBlock
            team="Salesforce Team"
            rows={[
              [
                "1st HM",
                "Business Systems Manager",
                "Salesforce Developer",
                "Salesforce Administrator · Business analysis · Aligning business needs to Salesforce solutions · Communication & documentation · Operations process improvement · Change management · User adoption",
              ],
              [
                "2nd HM",
                "Chief Operations Officer",
                "Business Systems Manager",
                "Salesforce roadmap · Backlog management · Configuration & development · Compliance, security & audit requirements · Partnering with developers · Project delivery",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 19 — Finance: Accountant + Controller + Carrier Relations ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Finance" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Finance Department</SectionTitle>
          <TeamBlock
            team="Accountant Team"
            rows={[
              [
                "1st HM",
                "Accountant, Team Leader",
                "Management Controller, Director",
                "Daily accounting · AP/AR · Payroll · Journals · Vendor management",
              ],
              [
                "2nd HM",
                "Management Controller, Director",
                "Financial Planning, Director",
                "Month-end close · Reconciliations · Audits · Cross-team communication",
              ],
            ]}
          />
          <TeamBlock
            team="Controller Team"
            rows={[
              [
                "1st HM",
                "Controller, Team Leader",
                "Management Controller",
                "Financial analysis and reporting · KPI tracking · Excel & financial modeling · Accounting principles (US GAAP) · Budgeting, forecasting",
              ],
              [
                "2nd HM",
                "Financial Planning, Director",
                "Chief Finance Officer",
                "Strategic financial support · Process improvement · Capital expenditure analysis · Presentation to management · Cross-functional collaboration",
              ],
            ]}
          />
          <TeamBlock
            team="Carrier Relations Team"
            rows={[
              [
                "1st HM",
                "Credit Collections Manager",
                "Global Revenue Finance & Operations, VP",
                "Collections experience · Customer communication · Negotiation · EN/ES skills · Billing operations",
              ],
              [
                "2nd HM",
                "Global Revenue Finance & Operations, VP",
                "Financial Planning, Director",
                "Risk & credit management · Process improvement · Cross-team collaboration · Reporting & KPIs · Dispute resolution",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 20 — Sales: Channel + Sales Ops + International ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Sales" />
        <PageBody>
          <div style={{ height: 16 }} />
          <SectionTitle>Sales Department</SectionTitle>
          <TeamBlock
            team="Channel Sales Team"
            rows={[
              [
                "1st HM",
                "VP, Sales",
                "Senior Partner Sales Manager",
                "CCaaS/UCaaS · CRM · Partner recruitment · Relationship management · Channel sales",
              ],
              [
                "2nd HM",
                "Channel Chief Officer",
                "VP, Sales",
                "Partner strategy · Forecasting · Negotiation · Escalation management",
              ],
            ]}
          />
          <TeamBlock
            team="Sales Operations Team"
            rows={[
              [
                "1st HM",
                "Sales Enablement Manager",
                "Global Sales Operations, Director",
                "Communication · Relationship building · Customer focus · Process monitoring",
              ],
              [
                "2nd HM",
                "Global Sales Operations, Director",
                "Chief Operating Officer",
                "Strategic thinking · Mentorship · Collaboration · Reporting & performance analysis",
              ],
            ]}
          />
          <TeamBlock
            team="International Sales Team"
            rows={[
              [
                "1st HM",
                "Sales Director",
                "Senior Partner Developer",
                "CCaaS knowledge · Market knowledge · CRM integrations · Security basics · Cloud migration · Soft skills",
              ],
              [
                "2nd HM",
                "Sales, VP",
                "To be defined",
                "Strategic accounts · Processes & metrics · Roleplay, solution pitch, discovery call · Long cycles & strategy alignment",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 21 — Sales Engineering + Product Marketing ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Sales & Marketing" />
        <PageBody>
          <div style={{ height: 16 }} />
          <TeamBlock
            team="Sales Engineering Team"
            rows={[
              [
                "1st HM",
                "Sales Engineer Manager",
                "Sales Engineer Director",
                "UCaaS or CCaaS solutions knowledge · Ability to assess customer network & infrastructure · Customer-facing communication · Supporting sales cycles",
              ],
              [
                "2nd HM",
                "Sales Engineer Director",
                "Sales Engineer, VP",
                "Advanced solution design · Product demos · Solution-to-business mapping · Escalation handling · Collaboration with sales & product · Roadmap prioritization scenarios",
              ],
            ]}
          />
          <SectionTitle>Marketing Department</SectionTitle>
          <TeamBlock
            team="Product Marketing Team"
            rows={[
              [
                "1st HM",
                "Head of Product Marketing",
                "Product Marketing, Director",
                "Market research & competitive analysis · Sales enablement & training · Communication · Presentation skills",
              ],
              [
                "2nd HM",
                "Product Marketing, Director",
                "Chief Marketing Officer",
                "Product launch planning & execution · Marketing plan ROI tracking · Customer acquisition & retention · CRM & Marketing tools · Domain/technical knowledge",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 22 — Marketing: Growth + Channel + Comm/Design + Training ===== */}
      <div className="page">
        <PageHeader eyebrow="Appendix · Marketing" />
        <PageBody>
          <div style={{ height: 8 }} />
          <TeamBlock
            team="Growth Marketing Team"
            rows={[
              [
                "1st HM",
                "Head of Growth Marketing",
                "Growth Marketing Manager",
                "Iberian market strategy · Demand generation & lead acquisition · Multi-channel campaign execution · Content & brand consistency · Cross-functional collaboration",
              ],
              [
                "2nd HM",
                "Growth Marketing Manager",
                "Chief Marketing Officer",
                "Performance tracking · ROI optimization · Digital marketing tools · Creativity & adaptability · Brand awareness & positioning · Data-driven decision making",
              ],
            ]}
          />
          <TeamBlock
            team="Channel Marketing Team"
            rows={[
              [
                "1st HM",
                "Channel Marketing, Director",
                "Senior Channel Marketing Manager",
                "Channel marketing strategy & planning · Partner enablement & campaign support · Communication · Presentation skills · Relationship building with partners and internal teams",
              ],
              [
                "2nd HM",
                "To be defined",
                "Chief Marketing Officer",
                "Campaign execution & demand generation · Event planning & coordination · Tracking, reporting & ROI analysis · CRM / Marketing automation tools · Project / Program management",
              ],
            ]}
          />
          <TeamBlock
            team="Communication / Design Team"
            rows={[
              [
                "1st HM",
                "Designer, Team Leader",
                "Senior Designer",
                "On-brand visual design & brand guidelines · Design quality fundamentals · Critical thinking · Creativity · Problem-solving",
              ],
              [
                "2nd HM",
                "Content Marketing & Creative, Director",
                "Chief Marketing Officer",
                "Digital design execution · Adobe Creative Suite · Vendor collaboration · Marketing-driven design · Design trends & best practices · Agile workflow experience",
              ],
            ]}
          />
          <TeamBlock
            team="Training & Development"
            rows={[
              [
                "1st HM",
                "Product Trainer Manager",
                "Senior Product Trainer",
                "Product training · Communication (EN + ES/PT) · Explaining technical concepts · Adult learning mindset",
              ],
              [
                "2nd HM",
                "Product Training, Director",
                "VP, Revenue Enablement",
                "SaaS knowledge · Training materials · Delivery structure · LMS, Zoom, Salesforce · Cross-team collaboration",
              ],
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>


      {/* ===== PAGE 24 — Evidence & References ===== */}
      <div className="page">
        <PageHeader eyebrow="References" />
        <PageBody>
          <div style={{ height: 20 }} />
          <SectionTitle>Evidence and References</SectionTitle>
          <Body>
            The research that informs the practices in this guide.
          </Body>

          <Card title="Use Structured Interview Guides & Competency-Based Questions">
            <Bullets
              items={[
                "McDaniel, M. A., Whetzel, D. L., Schmidt, F. L., & Maurer, S. D. (1994). The validity of employment interviews: A comprehensive review and meta-analysis. Journal of Applied Psychology, 79(4), 599–616.",
                "Huffcutt, A. I., & Arthur, W. (1994). Hunter and Hunter (1984) revisited: Interview validity for entry-level jobs. Journal of Applied Psychology.",
                "Campion, M. A., Palmer, D. K., & Campion, J. E. (1997). A Review of Structure in the Selection Interview. Personnel Psychology, 50(3), 655–702.",
              ]}
            />
          </Card>

          <Card title="Submit All Feedback Within 24 Hours">
            <Bullets
              items={[
                "Society for Human Resource Management. (2017). Interview is a critical part of the hiring process, candidates say.",
                "Society for Human Resource Management. (2023). Hiring is taking longer — and HR can help.",
                "Chapman, D. S., Uggerslev, K. L., Carroll, S. A., Piasentin, K. A., & Jones, D. A. (2005). Applicant attraction to organizations and job choice: A meta-analytic review of the correlates of recruiting outcomes. Personnel Psychology, 58(4), 929–973.",
              ]}
            />
          </Card>

          <Card title="Avoid Repetition Between Interviews">
            <Bullets
              items={[
                "Campion, M. A., Palmer, D. K., & Campion, J. E. (1997). A Review of Structure in the Selection Interview. Personnel Psychology, 50(3), 655–702.",
                "Levashina, J., Hartwell, C. J., Morgeson, F. P., & Campion, M. A. (2014). The Structured Employment Interview: Narrative and Quantitative Review of the Research Literature. Personnel Psychology, 67(1), 241–293.",
              ]}
            />
          </Card>
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default InterviewOwnershipGuide;
