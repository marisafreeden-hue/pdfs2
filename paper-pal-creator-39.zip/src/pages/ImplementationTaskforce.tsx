import React from "react";
import "./GoEngageDatasheet.css";
import "./ImplementationTaskforce.css";

const PageHeader = () => (
  <div className="tf-page-header">
    <span className="tf-header-left">BROADVOICE | GoContact Implementation Taskforce</span>
    <span className="tf-header-right">CHARTER BRIEF – MARCH 2026</span>
  </div>
);

const PageFooterText = ({ pageNum }: { pageNum: number }) => (
  <div className="tf-page-footer-text">
    <span>Confidential – Internal Use Only</span>
    <span>Page {pageNum}</span>
  </div>
);

const PageFooter = () => (
  <>
    <div className="page-bottom-cta">
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
    </div>
  </>
);

const SectionLabel = ({ number }: { number: number }) => (
  <div className="tf-section-label">SECTION {number}</div>
);

const ImplementationTaskforce: React.FC = () => {
  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="datasheet-wrapper tf-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1: Cover + Executive Summary ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="tf-cover-content">
          <h1 className="hero-headline">
            Implementation <em>Task Force</em>
          </h1>
          <div className="tf-cover-subtitle">Charter Brief</div>
        </div>

        <div className="outcomes-container" style={{ marginTop: '24px' }}>
          <table className="outcomes-table tf-cover-table">
            <tbody>
              <tr><td className="tf-meta-label">Date</td><td>March 2026</td></tr>
              <tr><td className="tf-meta-label">Version</td><td>1.0 – Initial Release</td></tr>
              <tr><td className="tf-meta-label">Classification</td><td>Confidential – Internal Use Only</td></tr>
              <tr><td className="tf-meta-label">Executive Sponsor</td><td>George Mitsopoulos, Chief Operating Officer</td></tr>
              <tr><td className="tf-meta-label">Task Force Lead</td><td>George Mitsopoulos, Chief Operating Officer</td></tr>
              <tr><td className="tf-meta-label">Status</td><td>Active</td></tr>
            </tbody>
          </table>
        </div>

        <hr />

        <SectionLabel number={1} />
        <h2 className="section-title">Executive <em>Summary</em></h2>

        <p className="section-body tf-body-wide">
          Broadvoice is accelerating its growth as a CCaaS leader in the mid-market, and the speed and quality of customer implementations are central to that ambition. Today, a significant friction point exists at the handoff between Sales/Sales Engineering and Service Delivery: incomplete or insufficiently detailed Statements of Work (SOWs) are causing orders to be returned to Sales, creating delays, eroding customer confidence, and pushing time-to-go-live in the wrong direction.
        </p>

        <p className="section-body tf-body-wide">
          The GoContact Implementation Task Force is a cross-functional, COO-led initiative established to eliminate this friction. Its mandate is to review every instance of an order Returned to Sales (RTS), identify root causes, close the information gaps that drive returns, and ultimately establish a standard that allows Service Delivery to execute implementations without interruption. This work directly supports two of Broadvoice's most critical 2026 OKRs and reinforces the consultative, outcome-driven experience defined in the Broadvoice CX Framework.
        </p>

        <PageFooterText pageNum={1} />
        <PageFooter />
      </div>

      {/* ===== PAGE 3: Background & Problem Statement ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={2} />
        <h2 className="section-title">Background & Problem <em>Statement</em></h2>

        <h3 className="tf-subsection-title">The Business Context</h3>
        <p className="section-body tf-body-wide">
          Broadvoice has made a strategic commitment to growing its CCaaS footprint in the mid-market through a consultative, outcomes-driven approach. The GoContact platform is central to that strategy, and the experience a customer has during implementation – from signed agreement through go-live – directly shapes their perception of Broadvoice as a partner and their likelihood to expand or refer.
        </p>

        <h3 className="tf-subsection-title">The Current Challenge</h3>
        <p className="section-body tf-body-wide">
          Feedback from the Sales team and field leadership has surfaced a consistent and serious concern: the current service delivery and implementation process for GoContact is creating friction that undermines both customer experience and revenue velocity. The specific issues identified include:
        </p>

        <ul className="tf-bullet-list">
          <li>Incomplete SOWs causing orders to be Returned to Sales (RTS), creating rework loops and delays</li>
          <li>A disconnect between what Sales and Sales Engineering believe constitutes a sufficient SOW and what Service Delivery needs to execute without interruption</li>
          <li>Customer outcomes and operational insights gathered during the sales discovery process are not consistently being captured and transferred to Service Delivery</li>
          <li>Implementations lacking sufficient context result in Service Delivery having to go back to the customer or to Sales for information that should have been captured upfront</li>
          <li>Sales reps report a lack of confidence in the company's ability to deliver reliably, which is affecting their willingness to position GoContact aggressively with partners and customers</li>
        </ul>

        <h3 className="tf-subsection-title">Why This Must Be Solved Now</h3>
        <p className="section-body tf-body-wide">
          The company's revenue targets for 2026 depend on a significant increase in new ICP logo acquisition and a material improvement in implementation efficiency. Every day an order sits in an RTS loop is a day of revenue delayed. Every partner who loses confidence in service delivery is a potential deal that never gets quoted. These are not theoretical risks – they are active constraints on growth that this task force is chartered to remove.
        </p>

        <PageFooterText pageNum={3} />
        <PageFooter />
      </div>

      {/* ===== PAGE 4: CX Framework Alignment ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={3} />
        <h2 className="section-title">CX Framework <em>Alignment</em></h2>

        <p className="section-body tf-body-wide">
          Broadvoice's CX Framework defines a five-step consultative model – Assess, Envision, Design, Implement, Optimize – that is intended to govern every interaction across the full customer lifecycle. This framework explicitly applies to all teams: Sales, Sales Engineering, Service Delivery, Customer Success, and Support.
        </p>

        <p className="section-body tf-body-wide">
          The framework's intent is that the outcomes a customer articulates during the Assess and Envision stages, and the solution designed in partnership with the customer during the Design stage, should carry forward seamlessly into execution by Service Delivery and beyond into Customer Success. The CX Framework documents this directly: Sales Engineering is responsible for sharing "operational insights from the discovery phase with Service Delivery and discuss the proposed solution to ensure a smooth transition."
        </p>

        <p className="section-body tf-body-wide">
          The root cause of the current implementation friction is a failure of this hand-off. The customer's desired outcomes and operational context are not being fully codified in the SOW in a way that Service Delivery can act on. As a result, Service Delivery is being asked to implement solutions without the foundational context the CX Framework requires them to have.
        </p>

        <h3 className="tf-subsection-title">The Task Force as Framework Enforcement</h3>
        <p className="section-body tf-body-wide">
          This task force is not a corrective measure for any one team. It is a mechanism to make the CX Framework operational end-to-end – ensuring that what is discovered and designed in the front of the customer journey is faithfully carried through into implementation. The standard SOW that emerges from this task force's work will be the instrument through which CX Framework principles are embedded into daily execution.
        </p>

        <PageFooterText pageNum={4} />
        <PageFooter />
      </div>

      {/* ===== PAGE 5: Strategic OKR Alignment ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={4} />
        <h2 className="section-title">Strategic OKR <em>Alignment</em></h2>

        <p className="section-body tf-body-wide">
          The task force is anchored to two primary 2026 Annual OKRs, with a supporting connection to a third:
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table tf-okr-table">
            <thead>
              <tr>
                <th>OKR</th>
                <th>Key Result</th>
                <th>Current</th>
                <th>Target</th>
                <th>Link to Task Force</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>CX Made Easy</td>
                <td>Reduce CCaaS time to go live from 60 to 45 days (25% improvement)</td>
                <td>52 days</td>
                <td>45 days</td>
                <td>Eliminating RTS loops and standardizing SOWs directly reduces implementation cycle time.</td>
              </tr>
              <tr>
                <td>Healthy Growth in ICP</td>
                <td>$2.4M in New ARR from ICP or Near-ICP Customers</td>
                <td>Off Track</td>
                <td>$2.4M billed</td>
                <td>Faster, frictionless implementations mean customers reach billable go-live sooner.</td>
              </tr>
              <tr>
                <td>CX Leader (Supporting)</td>
                <td>More than 300 partners quoting a CCaaS deal globally</td>
                <td>17 US / 7 Intl</td>
                <td>250 US / 50 Intl</td>
                <td>Partners who trust Broadvoice's delivery capability quote more aggressively.</td>
              </tr>
            </tbody>
          </table>
        </div>

        <PageFooterText pageNum={5} />
        <PageFooter />
      </div>

      {/* ===== PAGE 6: Task Force Charter ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={5} />
        <h2 className="section-title">Task Force <em>Charter</em></h2>

        <h3 className="tf-subsection-title">Mission Statement</h3>
        <p className="section-body tf-body-wide">
          To eliminate order return loops between Sales and Service Delivery by establishing a standardized, outcome-driven SOW framework that enables Service Delivery to implement GoContact solutions without interruption – reducing time to go-live, accelerating revenue recognition, and building partner confidence in Broadvoice's delivery capability.
        </p>

        <h3 className="tf-subsection-title">Scope</h3>
        <p className="section-body tf-body-wide">
          The task force has authority and accountability across the following areas:
        </p>
        <ul className="tf-bullet-list">
          <li>Review and triage of all orders Returned to Sales (RTS) to determine root cause and validity of return</li>
          <li>Development and ratification of a standardized SOW framework that captures the customer outcomes and implementation details Service Delivery requires</li>
          <li>Definition of the minimum information requirements that Sales and Sales Engineering must provide at point of handoff, aligned to the Assess and Envision phases of the CX Framework</li>
          <li>Identification of systemic patterns in RTS incidents and recommendation of process, tooling, or training changes to prevent recurrence</li>
          <li>Collaboration with Sales, Sales Engineering, and Service Delivery leadership to align on standards and ensure adoption</li>
          <li>Tracking and reporting of key implementation and delivery metrics against OKR targets</li>
        </ul>

        <h3 className="tf-subsection-title">Out of Scope</h3>
        <ul className="tf-bullet-list">
          <li>Customer-facing pricing or commercial terms</li>
          <li>Post-go-live customer success activities (owned by the CSM organization)</li>
        </ul>

        <PageFooterText pageNum={6} />
        <PageFooter />
      </div>

      {/* ===== PAGE 7: Task Force Composition ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={6} />
        <h2 className="section-title">Task Force <em>Composition</em></h2>

        <p className="section-body tf-body-wide">
          The task force is led by the Chief Operating Officer and includes cross-functional representation from the teams most directly involved in the implementation lifecycle.
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Role / Title</th>
                <th>Function</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>George Mitsopoulos</td><td>Chief Operating Officer</td><td>Executive Sponsor & Lead</td></tr>
              <tr><td>Molly Lozano</td><td>Channel Chief</td><td>Sales / Channel</td></tr>
              <tr><td>Jason Smith</td><td>VP, Sales Engineering</td><td>Sales Engineering</td></tr>
              <tr><td>Liz Guzzo</td><td>Director, Service Delivery</td><td>Service Delivery</td></tr>
              <tr><td>Andre Santos</td><td>SVP, Customer Enablement and Success</td><td>Service Delivery</td></tr>
              <tr><td>Erick Nava</td><td>Sales Engineer</td><td>Sales Engineering</td></tr>
            </tbody>
          </table>
        </div>

        <PageFooterText pageNum={7} />
        <PageFooter />
      </div>

      {/* ===== PAGE 8: Operating Model ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={7} />
        <h2 className="section-title">Operating <em>Model</em></h2>

        <h3 className="tf-subsection-title">Invocation Trigger</h3>
        <p className="section-body tf-body-wide">
          The task force is invoked automatically whenever a GoContact CCaaS order for the US is flagged as Returned to Sales (RTS). No manual escalation or judgment is required to trigger task force review – every RTS event enters the review queue.
        </p>

        <h3 className="tf-subsection-title">RTS Review Process</h3>
        <ul className="tf-bullet-list">
          <li>When an order is returned to Sales, it is routed to the task force for review</li>
          <li>The task force convenes – in an ad hoc review – to assess each RTS incident against a structured set of criteria</li>
          <li>For each RTS, the task force determines: (a) whether the return was valid, (b) what information was missing or insufficient in the SOW, and (c) which team or process step is responsible for the gap</li>
          <li>Findings are documented and tracked across all RTS incidents to identify systemic patterns</li>
          <li>Where a pattern of gaps is identified, the task force develops and recommends targeted interventions: updated SOW templates, training, process checkpoints, or tooling changes</li>
        </ul>

        <h3 className="tf-subsection-title">Standing Cadence</h3>
        <ul className="tf-bullet-list">
          <li>Ad-Hoc check-ins based on incoming RTS orders to review active RTS incidents and track resolution</li>
          <li>Monthly executive summary</li>
        </ul>

        <h3 className="tf-subsection-title">Decision Authority</h3>
        <p className="section-body tf-body-wide">
          The task force has the authority to review, triage, and recommend process changes based on RTS findings.
        </p>

        <PageFooterText pageNum={8} />
        <PageFooter />
      </div>

      {/* ===== PAGE 9: Success Metrics + Guiding Principles ===== */}
      <div className="page page-2">
        <PageHeader />

        <SectionLabel number={8} />
        <h2 className="section-title">Success <em>Metrics</em></h2>

        <p className="section-body tf-body-wide">
          The task force will track the following metrics to measure its impact and progress toward OKR targets:
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Metric</th>
                <th>Definition</th>
                <th>Baseline</th>
                <th>Target</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>RTS Rate</td>
                <td>Number of orders returned to Sales as a % of total orders submitted</td>
                <td>TBD (baseline to be set at launch)</td>
                <td>Reduce to 0% over task force lifecycle</td>
              </tr>
              <tr>
                <td>SOW Acceptance Rate</td>
                <td>% of SOWs accepted by Service Delivery on first submission (no return)</td>
                <td>TBD (baseline to be set at launch)</td>
                <td>&gt;95% acceptance on first submission</td>
              </tr>
            </tbody>
          </table>
        </div>

        <hr />

        <SectionLabel number={9} />
        <h2 className="section-title">Guiding <em>Principles</em></h2>

        <p className="section-body tf-body-wide">
          The following principles will govern how the task force operates and how its outputs are developed and applied:
        </p>

        <ul className="tf-bullet-list tf-principles-list">
          <li><strong>Shared accountability, not blame.</strong> This task force exists because the current process has gaps – not because any one team is failing. Every finding and recommendation will be framed around fixing the process, not assigning fault.</li>
          <li><strong>The customer outcome is the anchor.</strong> Every SOW standard, process change, and review decision will be evaluated against a single question: does this enable Broadvoice to deliver the outcome the customer was promised?</li>
          <li><strong>The CX Framework is the playbook.</strong> All task force work will be grounded in Broadvoice's CX Framework. The five-step model – Assess, Envision, Design, Implement, Optimize – defines the intent. This task force operationalizes it at the handoff point.</li>
          <li><strong>Data drives decisions.</strong> RTS incidents will be documented, categorized, and analyzed systematically. Decisions will be based on patterns in the data, not on individual cases or anecdotes.</li>
          <li><strong>Speed and quality are not in conflict.</strong> The goal is not to slow Sales down with more process. It is to front-load the right information so that Service Delivery can move faster and without interruption once a deal is closed.</li>
        </ul>

        <PageFooterText pageNum={9} />
        <PageFooter />
      </div>

      {/* ===== PAGE 10: Acknowledgment ===== */}
      <div className="page page-2">
        <PageHeader />

        <div className="tf-acknowledgment-label">ACKNOWLEDGMENT</div>
        <h2 className="section-title">Task Force <em>Acknowledgment</em></h2>

        <p className="section-body tf-body-wide">
          By participating in this task force, each member commits to attending standing sessions, contributing to RTS reviews, and supporting the development and adoption of the SOW standard and associated process improvements.
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table tf-sign-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>George Mitsopoulos</td><td className="tf-sign-line"></td><td className="tf-sign-line"></td></tr>
              <tr><td>Molly Lozano</td><td className="tf-sign-line"></td><td className="tf-sign-line"></td></tr>
              <tr><td>Jason Smith</td><td className="tf-sign-line"></td><td className="tf-sign-line"></td></tr>
              <tr><td>Liz Guzzo</td><td className="tf-sign-line"></td><td className="tf-sign-line"></td></tr>
              <tr><td>Andre Santos</td><td className="tf-sign-line"></td><td className="tf-sign-line"></td></tr>
              <tr><td>Erick Nava</td><td className="tf-sign-line"></td><td className="tf-sign-line"></td></tr>
            </tbody>
          </table>
        </div>

        <PageFooterText pageNum={10} />
        <PageFooter />
      </div>
    </div>
  );
};

export default ImplementationTaskforce;
