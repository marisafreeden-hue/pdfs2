import React from "react";
import "./GoEngageDatasheet.css";

const PageFooter = () => (
  <div
    style={{
      position: "absolute",
      bottom: "0.2in",
      left: "0.625in",
      right: "0.625in",
      borderTop: "1px solid #E2E2EC",
      paddingTop: 8,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontFamily: "'Inter', sans-serif",
      fontSize: 10,
      color: "#888899",
      letterSpacing: "0.02em",
    }}
  >
    <div>Guía Técnica del Partner · v1.0 · Junio 2026</div>
    <div>© Broadvoice 2026</div>
  </div>
);

const PageHeader = ({ eyebrow }: { eyebrow?: string }) => (
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14,
    }}
  >
    <div className="logo" style={{ marginBottom: 0 }}>
      <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
    </div>
    {eyebrow && (
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "#888899",
        }}
      >
        {eyebrow}
      </div>
    )}
  </div>
);

const PageBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ paddingBottom: 80, position: "relative", zIndex: 1 }}>{children}</div>
);

const SectionTitle: React.FC<{ num?: string; children: React.ReactNode }> = ({
  children,
}) => (
  <h2
    className="section-title"
    style={{ fontSize: 22, marginBottom: 8, marginTop: 2, display: "block", lineHeight: 1.2 }}
  >
    {children}
  </h2>
);

const SubHead: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      color: "#1A1A2E",
      margin: "12px 0 6px",
      lineHeight: 1.4,
    }}
  >
    {children}
  </h3>
);

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: 1.6,
      margin: "6px 0 10px",
    }}
  >
    {children}
  </p>
);

const Bullets: React.FC<{ items: React.ReactNode[]; tight?: boolean }> = ({
  items,
  tight,
}) => (
  <ul
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: "#555567",
      lineHeight: tight ? 1.5 : 1.65,
      paddingLeft: 20,
      margin: "6px 0 10px",
      listStyleType: "disc",
    }}
  >
    {items.map((it, i) => (
      <li key={i} style={{ marginBottom: 2 }}>
        {it}
      </li>
    ))}
  </ul>
);

const Callout: React.FC<{ children: React.ReactNode; tone?: "info" | "warn" }> = ({
  children,
  tone = "info",
}) => (
  <div
    style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 12,
      color: tone === "warn" ? "#8a4a00" : "#1A1A2E",
      background: tone === "warn" ? "#FFF6E5" : "#EEF7F8",
      borderLeft: `3px solid ${tone === "warn" ? "#D97706" : "#43B5BF"}`,
      padding: "12px 16px",
      margin: "12px 0",
      lineHeight: 1.5,
      borderRadius: 4,
    }}
  >
    {children}
  </div>
);

const SimpleTable: React.FC<{
  head: string[];
  rows: (string | React.ReactNode)[][];
  colWidths?: string[];
}> = ({ head, rows, colWidths }) => (
  <table
    style={{
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "'Inter', sans-serif",
      fontSize: 9.5,
      margin: "8px 0 12px",
      tableLayout: "fixed",
    }}
  >
    <colgroup>
      {(colWidths || head.map(() => "auto")).map((w, i) => (
        <col key={i} style={{ width: w }} />
      ))}
    </colgroup>
    <thead>
      <tr style={{ background: "#F3F3F8" }}>
        {head.map((h, i) => (
          <th
            key={i}
            style={{
              padding: "9px 12px",
              textAlign: "left",
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: "0.07em",
              textTransform: "uppercase",
              color: "#555567",
              borderBottom: "2px solid #E2E2EC",
            }}
          >
            {h}
          </th>
        ))}
      </tr>
    </thead>
    <tbody>
      {rows.map((r, ri) => (
        <tr key={ri} style={{ background: ri % 2 === 0 ? "#FFFFFF" : "#FAFAFA" }}>
          {r.map((c, ci) => (
            <td
              key={ci}
              style={{
                padding: "9px 12px",
                color: "#555567",
                borderBottom: "1px solid #E2E2EC",
                lineHeight: 1.45,
                verticalAlign: "top",
                fontWeight: ci === 0 ? 700 : 400,
                ...(ci === 0 ? { color: "#1A1A2E" } : {}),
              }}
            >
              {c}
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  </table>
);

const PartnerTechGuideES: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper narrow-guide">
      <style>{`
        .datasheet-wrapper.narrow-guide .page {
          width: 7.25in;
          padding: 0.4in 0.6in;
        }
        .rounded-table table { margin: 0 !important; }
        .rounded-table tbody tr:last-child td { border-bottom: none !important; }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Exportar como PDF
      </button>

      {/* ===== PAGE 1 – Portada e introducción ===== */}
      <div className="page">
        <PageHeader eyebrow="Guía Técnica del Partner" />

        <div className="partner-hero" style={{ marginTop: 60, marginBottom: 10 }}>
          <h1 className="hero-headline" style={{ fontSize: 36, lineHeight: 1.05, marginBottom: 4, whiteSpace: "nowrap" }}>
            Guía <em>Técnica</em> del Partner
          </h1>

          <div
            style={{
              fontFamily: "'Besley', Georgia, serif",
              fontSize: 13,
              fontStyle: "italic",
              color: "#555555",
              marginTop: 4,
            }}
          >
            Soporte, SLAs, entrega y requisitos de homologación para revendedores.
          </div>
        </div>

        <hr style={{ margin: "10px 0" }} />

        <PageBody>
          <div style={{ height: 22 }} />
          <SectionTitle num="1.">Introducción</SectionTitle>

          <Body>
            Esta guía proporciona a los partners de Broadvoice todo lo necesario para
            cualificar, dimensionar y entregar un despliegue de GoContact CCaaS con éxito.
            Consolida los compromisos de soporte, la metodología de entrega y los
            requisitos técnicos que cada sitio del cliente debe cumplir antes de la
            puesta en producción, de modo que los partners puedan fijar expectativas
            claras y proteger el time-to-value.
          </Body>
          <Body>
            <strong>Audiencia:</strong> Preventa, arquitectos de soluciones y jefes de
            proyecto del partner que revende Broadvoice / GoContact CCaaS.
          </Body>

          <Body>
            <strong>Alcance:</strong> Modelo de soporte, SLAs, metodología de proyecto y
            requisitos técnicos y de infraestructura que un sitio del cliente debe
            cumplir antes de la puesta en producción.
          </Body>
          <Body>
            Como revendedor, eres la primera línea de cualificación. Antes de firmar con
            un cliente debes ser capaz de:
          </Body>
          <ol
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 12,
              color: "#555567",
              lineHeight: 1.65,
              paddingLeft: 22,
              margin: "6px 0 10px",
              listStyleType: "decimal",
            }}
          >
            <li style={{ marginBottom: 2 }}>
              Fijar las expectativas correctas sobre <strong>soporte y SLAs</strong> (y
              las penalizaciones que Broadvoice asumirá).
            </li>
            <li style={{ marginBottom: 2 }}>
              Explicar la <strong>metodología de entrega</strong> y qué perfiles debe
              aportar el cliente.
            </li>
            <li style={{ marginBottom: 2 }}>
              Recoger la información de{" "}
              <strong>red, IP, telefonía y puestos</strong> que GoContact necesita para
              aprovisionar el tenant.
            </li>
          </ol>

          <Callout>
            Un sitio que no cumpla los requisitos de la sección 5 no pasará la
            homologación, con independencia del acuerdo comercial.
          </Callout>

          <hr style={{ margin: "16px 0" }} />

          <SectionTitle num="2.">Modelo de soporte y marco de SLA</SectionTitle>
          <Body>
            GoContact se entrega con un <strong>modelo de SLA de cuatro niveles</strong>,
            calculado anualmente sobre el año natural (1 de enero – 31 de diciembre). La
            asignación del nivel depende de (a) qué componente está afectado y (b) si el
            impacto es total o parcial.
          </Body>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["Clase", "Alcance", "Disp. Anual", "Tiempo máx. reposición"]}
              colWidths={["10%", "55%", "17%", "18%"]}
              rows={[
                [
                  "A",
                  "Indisponibilidad total de funciones Core o del acceso a la plataforma",
                  "99,9 %",
                  "4 horas",
                ],
                [
                  "B",
                  "Indisponibilidad parcial del Core, O pérdida total de funciones de soporte a la operación",
                  "99,5 %",
                  "8 horas",
                ],
                [
                  "C",
                  "Indisponibilidad total de funciones secundarias (Calidad, E-Learning, Calendario)",
                  "98,0 %",
                  "5 días hábiles",
                ],
                [
                  "D",
                  "Indisponibilidad parcial de funciones de soporte a la operación",
                  "98,0 %",
                  "10 días hábiles",
                ],
              ]}
            />
          </div>
        </PageBody>

        <PageFooter />
      </div>

      {/* ===== PAGE 2 – Detalle SLA ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 2 · Detalle del SLA" />
        <PageBody>
          <div style={{ height: 30 }} />
          {[
            {
              title: "SLA-A — Core / acceso a la plataforma (caída total)",
              intro: "Se activa cuando el cliente no puede:",
              items: [
                "Acceder a la plataforma",
                "Realizar o recibir llamadas",
                "Enviar o recibir correo electrónico",
                "Ver o gestionar tickets",
                "Recibir o gestionar webchats",
                "Usar el módulo de Scripts",
                "Usar cualquier canal de comunicación",
              ],
            },
            {
              title: "SLA-B — Core parcial, o soporte a la operación total",
              intro:
                "Fallos parciales / intermitentes de cualquier elemento del SLA-A, o pérdida total de:",
              items: [
                "Reporting",
                "Dashboards",
                "Gestión de Usuarios",
                "Acceso a grabaciones de llamadas",
                "Módulo CRM",
                "Módulo Database Management",
              ],
            },
            {
              title: "SLA-C — Funciones secundarias (caída total)",
              intro: "Fallo total de cualquiera de estos módulos:",
              items: ["Calidad", "E-Learning", "Calendario"],
            },
            {
              title: "SLA-D — Soporte a la operación (caída parcial)",
              intro: "Fallos parciales de:",
              items: [
                "Calidad",
                "E-Learning",
                "Calendario",
                "Grabaciones de llamadas",
                "CRM",
                "Database Management",
                "Reporting",
                "Dashboards",
                "Gestión de Usuarios",
              ],
            },
            {
              title: "Exclusiones comunes a todos los SLA",
              intro: "Los siguientes tiempos de indisponibilidad no computan contra ningún SLA:",
              items: [
                "Ventanas de mantenimiento programado, correctivo o evolutivo",
                "Eventos fuera del control razonable de GoContact (incidencias o latencia de Internet, configuración incorrecta del cliente o de terceros, fallos en la LAN del cliente, integraciones externas, servicios de operador contratados por el cliente)",
                "Incidencias cuya resolución requiera cambios de código fuente en cualquier componente del ecosistema GoContact",
              ],
            },
          ].map((sec, i) => (
            <div
              key={i}
              style={{
                border: "1px solid #E2E2EC",
                borderRadius: 8,
                padding: "12px 16px 10px",
                marginBottom: 10,
                background: "#FFFFFF",
              }}
            >
              <h2
                className="section-title"
                style={{
                  fontSize: 22,
                  margin: "0 0 6px",
                  lineHeight: 1.2,
                  display: "block",
                }}
              >
                {sec.title}
              </h2>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#555567",
                  margin: "0 0 6px",
                  lineHeight: 1.5,
                }}
              >
                {sec.intro}
              </p>
              <ul
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#555567",
                  lineHeight: 1.55,
                  paddingLeft: 20,
                  margin: 0,
                  listStyleType: "disc",
                  columnCount: 2,
                  columnGap: 28,
                }}
              >
                {sec.items.map((it, j) => (
                  <li key={j} style={{ marginBottom: 2, breakInside: "avoid" }}>
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 3 – Disponibilidad y penalizaciones ===== */}
      <div className="page">
        <PageHeader eyebrow="Secciones 2.6 – 2.7 · Disponibilidad y Penalizaciones" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="2.6">Compromiso de disponibilidad del servicio</SectionTitle>
          <Body>
            El servicio se presta 24×7. Los mantenimientos planificados se ejecutan en
            ventanas de bajo tráfico y con preaviso; si deben realizarse en horario
            productivo, requieren aprobación del cliente y un plan de continuidad
            acordado — esas ventanas también quedan excluidas del cálculo de SLA. El SLA
            se mide <strong>globalmente</strong> en todos los sitios donde corre la
            plataforma. Si la disponibilidad mensual cae por debajo del límite, el
            cliente puede solicitar un crédito{" "}
            <strong>dentro de los 30 días posteriores al cierre del mes</strong>.
          </Body>

          <div style={{ height: 28 }} />

          <SectionTitle num="2.7">Penalizaciones (crédito sobre la cuota mensual)</SectionTitle>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["SLA", "SLA mensual", "> 0 % – ≤ 0,5 %", "> 0,5 % – ≤ 1 %", "> 1 %"]}
              colWidths={["12%", "22%", "22%", "22%", "22%"]}
              rows={[
                ["A", "99,90 %", "2 %", "5 %", "10 %"],
                ["B", "99,50 %", "—", "2 %", "5 %"],
                ["C y D", "98,00 %", "—", "—", "—"],
              ]}
            />
          </div>
          <Callout>
            Los partners deben incorporar el coste de los créditos en sus modelos
            comerciales, especialmente para clientes con fuerte dependencia del Core
            (exposición a SLA-A).
          </Callout>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – Metodología y checklist preventa ===== */}
      <div className="page">
        <PageHeader eyebrow="Secciones 3 – 4 · Entrega y Descubrimiento" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="3.">Metodología de entrega</SectionTitle>
          <Body>
            Toda implantación de GoContact CCaaS se ejecuta sobre el mismo marco por
            fases, de manera que partners y clientes comparten un único playbook desde
            la firma del contrato hasta el régimen estable. La sección 3 describe las
            cuatro fases; la sección 4 enumera la información que debes recoger del
            cliente antes del kickoff.
          </Body>
          <Body>Las implantaciones de GoContact CCaaS se ejecutan como proyectos por fases:</Body>
          <Bullets
            items={[
              <>
                <strong>Planificación</strong> — descubrimiento, requisitos, diseño.
              </>,
              <>
                <strong>Ejecución / Implementación</strong> — aprovisionamiento,
                configuración, integración, pruebas.
              </>,
              <>
                <strong>Cierre</strong> — entrega, firma de aceptación, traspaso al
                Customer Success Manager (CSM).
              </>,
              <>
                <strong>Acompañamiento (Nurturing)</strong> — seguimiento post go-live
                por parte del CSM.
              </>,
            ]}
          />
          <Body>
            La metodología está basada en <strong>PRINCE2®</strong> y alineada con las
            buenas prácticas de PMI / PMBOK®. Se espera que el partner aporte una
            contraparte de PM, un responsable técnico y un contacto de red durante la
            ejecución.
          </Body>

          <hr style={{ margin: "16px 0" }} />

          <SectionTitle num="4.">Descubrimiento de preventa</SectionTitle>
          <Body>
            Utiliza estas preguntas para cualificar la oportunidad y dimensionar el
            despliegue antes de cotizar. Las respuestas alimentan directamente el
            dimensionamiento, el diseño de red, la integración de telefonía y el plan de
            proyecto — las lagunas aquí son la causa más habitual de retrasos en el
            go-live. Trabájalas con los responsables técnicos y de negocio del cliente.
          </Body>

          <SubHead>Dimensionamiento y operación</SubHead>
          <Bullets
            items={[
              "¿Cuántos agentes concurrentes deberá soportar la plataforma, y cuál es el crecimiento previsto a 12 meses?",
              "¿Cuál es el patrón de turnos del agente (24×7, horario laboral, picos) y el volumen de llamadas en hora pico?",
              "¿Cuántos sitios están en alcance, dónde están ubicados y se prevén agentes en remoto / teletrabajo?",
            ]}
          />

          <SubHead>Red y conectividad</SubHead>
          <Bullets
            items={[
              "¿Cuál es la topología WAN / Internet actual (Internet dedicada, MPLS, híbrida) y qué redundancia hay?",
              "¿Qué equipamiento LAN está desplegado (modelos de switch, gestionables, PoE) y de quién es la propiedad?",
              "¿Hay agentes trabajando hoy por Wi-Fi y se puede eliminar antes del go-live?",
            ]}
          />

          <SubHead>Telefonía y numeración</SubHead>
          <Bullets
            items={[
              "¿Qué IPs públicas se usarán para el SIP trunk y hay IP de respaldo para failover?",
              "¿Qué operador(es) prestarán el servicio SIP, qué extremo origina las llamadas y es necesaria portabilidad?",
              "¿Cuál es el plan de numeración entrante (DDIs, menús IVR, horarios y calendario de festivos)?",
            ]}
          />
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – Descubrimiento (cont.) ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 4 · Descubrimiento de preventa (cont.)" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="4.">Descubrimiento de preventa (continuación)</SectionTitle>

          <SubHead>Canales y emisión</SubHead>
          <Bullets
            items={[
              "¿Qué modos de marcación saliente se necesitan (preview, progresivo, predictivo) y qué normativa aplica (LOPD-GDD, RGPD, listas Robinson, opt-out)?",
              "¿Qué canales están en alcance además de voz (correo, webchat, WhatsApp, SMS, redes sociales) y a qué volumen?",
            ]}
          />

          <SubHead>Cumplimiento y grabación</SubHead>
          <Bullets
            items={[
              "¿Qué periodo de retención de grabaciones se necesita (por defecto 90 días) y qué normativa aplica (PCI, sanitaria, RGPD)?",
            ]}
          />

          <SubHead>Puestos e integraciones</SubHead>
          <Bullets
            items={[
              "¿Cuál es el inventario de puestos de agente (especificación del PC, auriculares, SO, navegador) y el ciclo de renovación del parque?",
              "¿Qué integraciones se requieren (CRM, ticketing, WFM, BI, APIs externas) y quién es el propietario de cada sistema?",
            ]}
          />

          <SubHead>Reporting e interlocutores</SubHead>
          <Bullets
            items={[
              "¿Quiénes son el patrocinador ejecutivo, el responsable técnico, el contacto de red y el referente de usuarios finales por parte del cliente?",
            ]}
          />

          <SubHead>Plazos y criterios de éxito</SubHead>
          <Bullets
            items={[
              "¿Cuál es la fecha objetivo de go-live y existen periodos vetados (campañas, auditorías, congelaciones de sistemas)?",
              "¿Cómo se define el éxito a 30, 60 y 90 días tras la puesta en producción?",
            ]}
          />

          <Callout>
            <strong>Cierra el círculo:</strong> antes de cotizar, consigue la conformidad
            por escrito sobre número de agentes, canales, integraciones y fecha de
            go-live. Cada hipótesis abierta se convierte en una solicitud de cambio, un
            retraso o un impacto en margen durante la entrega.
          </Callout>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 4 – Requisitos técnicos (IP, LAN, Acceso) ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 5 · Requisitos técnicos" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="5.1">Direccionamiento IP y puertos</SectionTitle>
          <Body>
            <strong>Rango IP de la plataforma GoContact (PT / ES):</strong>{" "}
            <code style={{ background: "#F3F3F8", padding: "1px 6px", borderRadius: 3 }}>
              185.133.136.0/22
            </code>
          </Body>
          <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 12px" }}>
            <SimpleTable
              head={["Propósito", "Protocolo", "Puertos"]}
              colWidths={["40%", "20%", "40%"]}
              rows={[
                ["Señalización SIP", "UDP", "5060, 5062, 5090"],
                ["Señalización SIP (TLS)", "TCP", "5061"],
                ["Audio RTP (bajo)", "UDP", "16384–32767"],
                ["Audio RTP (alto)", "UDP", "49152–65535"],
                ["Gestión IPBX local (solo on-prem)", "UDP", "10000–10050"],
                ["Gestión plataforma GoContact", "TCP", "50000–50010"],
              ]}
            />
          </div>
          <Callout>
            Todos los puertos deben permitirse de forma bidireccional en el firewall del
            cliente contra el rango IP anterior.
          </Callout>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 10,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.2">Requisitos de LAN</SectionTitle>
            <Body>
              VoIP es muy sensible a la estabilidad de la LAN. La plataforma{" "}
              <strong>no soporta Wi-Fi</strong> para agentes.
            </Body>
            <Bullets
              tight
              items={[
                "Cableado estructurado, Cat 5E o superior.",
                "Switches gestionables de nivel 2 con: LACP, 802.1Q, STP, PoE.",
                "Puertos 10/100/1000 Base-T.",
                "Capacidad: switch de 24 puertos > 40 Mbps · 48 puertos > 70 Mbps.",
                "Referencia: Huawei S5700 LI, S5710 LI (o equivalente).",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 10,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.3">Acceso IP a la plataforma</SectionTitle>
            <Body>
              Todo el tráfico con la plataforma GoContact — HTTP/HTTPS, SIP, RTP,
              puertos de gestión — debe tratarse como <strong>tiempo real</strong>.
            </Body>
            <SubHead>Ancho de banda por agente (regla práctica)</SubHead>
            <Bullets
              tight
              items={[
                "~100 kbps de voz",
                "~200 kbps para otros canales / funciones",
                "≈ 300 kbps totales por agente concurrente",
              ]}
            />
            <Body>
              El acceso puede prestarse vía Internet dedicada, VPN MPLS o circuito
              dedicado. El router CPE debe ser equivalente o superior a un{" "}
              <strong>Cisco 1921/K9</strong>.
            </Body>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 5 – Tipos de acceso, QoS, Puesto ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 5 · Acceso y Calidad" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.4">Acceso por Internet dedicada</SectionTitle>
            <Bullets
              tight
              items={[
                "NO garantiza QoS entre el sitio y el datacenter.",
                "Funciona en la práctica hasta ~50 agentes con Internet business estándar.",
                "Recomendado: un circuito dedicado, separado de la Internet general del cliente.",
                "Perfil de referencia en producción: 100 Mbps simétricos, IP fija.",
                "La latencia al datacenter GoContact debe ser < 100 ms.",
                "Todo el tráfico cruza Internet pública — revisar los requisitos de seguridad del cliente.",
                "> 50 y hasta 200 agentes: es obligatorio un circuito dedicado de GoContact O acceso MPLS / Nivel 2.",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.5">Acceso MPLS / VPN</SectionTitle>
            <Bullets
              tight
              items={[
                "Recomendado para cualquier operación; cumple requisitos de QoS y seguridad.",
                "Establecido entre el datacenter GoContact y el sitio del cliente.",
                "Debe dimensionarse según el ancho de banda por agente.",
                "El datacenter GoContact puede terminar VPNs MPLS redundantes.",
              ]}
            />
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.6">Configuración de calidad de voz (QoS)</SectionTitle>
            <Bullets
              tight
              items={[
                "VLAN dedicada de voz en cada sitio, separada de la de datos.",
                "Priorizar la voz en sentido saliente (uplink) en el router con ancho de banda garantizado por canal.",
                <>
                  Códec: <strong>G.711a</strong>, ~95 kbps por canal.
                </>,
                "Los teléfonos SIP marcan señalización DSCP=40 y audio DSCP=46.",
                "Aplicar QoS mediante segmentación por VLAN, DSCP (40/46) o IP Precedence 5.",
                "Cola de prioridad para audio: Expedited Forwarding (EF).",
              ]}
            />
          </div>

          <div style={{ marginBottom: 12 }}>
            <SectionTitle num="5.7">Puesto de agente (PC)</SectionTitle>
            <div className="rounded-table" style={{ border: "1px solid #E2E2EC", borderRadius: 8, overflow: "hidden", margin: "8px 0 4px" }}>
              <SimpleTable
                head={["Componente", "Mínimo"]}
                colWidths={["30%", "70%"]}
                rows={[
                  ["CPU", "Intel Core i3 / i5"],
                  ["Disco", "60 GB"],
                  ["RAM", "4 GB"],
                  ["SO", "Windows 7 o superior"],
                  ["Navegador", "Google Chrome (última versión)"],
                  ["Softphone", "X-Lite, MicroSIP o Zoiper"],
                  ["Periféricos", "Auriculares USB, monitor, teclado, ratón"],
                ]}
              />
            </div>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 6 – IPERF + Grabación y SIP Trunking ===== */}
      <div className="page">
        <PageHeader eyebrow="Secciones 5.8 – 6 · Pruebas, Grabación y SIP" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="5.8">Pruebas de conectividad con IPERF</SectionTitle>
            <Body>
              Antes del go-live se valida la conectividad con <strong>IPERF</strong>. El
              cliente debe <strong>abrir temporalmente TCP/UDP 32000</strong> durante
              las pruebas; puede cerrarse después.
            </Body>
          </div>

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="6.1">Grabación de llamadas y retención</SectionTitle>
            <Body>
              Broadvoice (GoTelecom — "A Broadvoice Company") incluye{" "}
              <strong>grabación y retención hasta 90 días sin coste adicional</strong>{" "}
              como parte del servicio CCaaS. El partner debe verificar si el sector o la
              jurisdicción del cliente exigen una retención mayor (p. ej. Deliberación
              CNPD nº 1039/2017 en Portugal). La retención ampliada está disponible,
              pero las condiciones técnicas y comerciales deben acordarse de antemano.
            </Body>
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE – SIP Trunking ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 6.2 · SIP Trunking" />
        <PageBody>
          <div style={{ height: 30 }} />

          <div
            style={{
              border: "1px solid #E2E2EC",
              borderRadius: 8,
              padding: "12px 16px 10px",
              marginBottom: 12,
              background: "#FFFFFF",
            }}
          >
            <SectionTitle num="6.2">SIP Trunk sobre Internet (autenticación por IP)</SectionTitle>
            <Body>
              La infraestructura SIP de GoContact se basa en <strong>FreeSWITCH</strong>{" "}
              con proxy-registrar. Cuando el cliente aporta su propio SIP trunk
              autenticado por IP pública, aplican las siguientes restricciones.
            </Body>

            <SubHead>Configuración del gateway</SubHead>
            <Bullets
              tight
              items={[
                "El gateway debe usar una IP pública fija y un puerto SIP específico (por defecto 5060).",
                <>
                  El tráfico SIP <strong>debe originarse exactamente desde ese puerto</strong>,
                  o las llamadas se rechazan con <code>403 Forbidden</code>.
                </>,
                "Gateways de entrada: NO se admiten nombres DNS — solo IP + puerto. DNS está permitido solo en gateways de salida.",
              ]}
            />

            <SubHead>Seguridad y autenticación</SubHead>
            <Bullets
              tight
              items={[
                "REGISTER no está permitido para gateways de entrada. La autenticación es por IP origen + puerto únicamente.",
                "TLS mutuo (mTLS) no está soportado — debe desactivarse en los SBCs del cliente.",
              ]}
            />

            <SubHead>Comportamiento esperado</SubHead>
            <Bullets
              tight
              items={[
                "La misma IP no puede usarse a la vez para SIP Trunk y para el registro de extensiones — provoca conflictos de autenticación.",
                "Una sola extensión mal configurada (REGISTERs fallidos repetidos) puede bloquear temporalmente toda la IP origen.",
              ]}
            />

            <SubHead>Failover</SubHead>
            <Bullets
              tight
              items={[
                "Se dispara automáticamente ante cualquier respuesta SIP no 2xx.",
                "No es posible crear listas blancas/negras de códigos SIP para el failover.",
                <>
                  Si el operador responde con <code>183 Session Progress</code> con
                  early media, FreeSWITCH considera la llamada establecida y a partir
                  de ese punto el failover ya no está disponible.
                </>,
              ]}
            />

            <SubHead>Códecs, media y no soportado</SubHead>
            <Bullets
              tight
              items={[
                "Códecs nativos: PCMA (G.711a), PCMU (G.711u), G.722, GSM.",
                "G.729 y Opus no están disponibles por defecto — requieren desarrollo y, en algunos casos, licenciamiento.",
                "G.729 disponible solo en datacenters específicos de EE. UU. usando el SBC Perimeta.",
                "DTMF: solo RFC 2833. No SRTP, no STIR/SHAKEN.",
                "No se admiten llamadas inter-dominio entre IPPBX y GoContact, ni entre dominios cloud de GoContact.",
                "FreeSWITCH no genera tonos de ringback por defecto.",
              ]}
            />
          </div>
        </PageBody>
        <PageFooter />
      </div>

      {/* ===== PAGE 7 – Checklist go / no-go ===== */}
      <div className="page">
        <PageHeader eyebrow="Sección 7 · Go / No-Go" />
        <PageBody>
          <div style={{ height: 30 }} />
          <SectionTitle num="7.">Checklist go / no-go del partner</SectionTitle>
          <Body>
            Este checklist es la última puerta entre una oportunidad prometedora y un
            despliegue exitoso. Trata cualquier casilla sin marcar como un riesgo
            abierto: resuélvelo por escrito con el cliente antes de la firma del
            contrato, no después. Los partners que aplican esta disciplina de forma
            consistente logran implantaciones más cortas, menos escalados post go-live y
            mejores resultados para el cliente — exactamente aquello para lo que está
            construida la alianza con Broadvoice.
          </Body>
          <Body>Usar antes de cotizar al cliente:</Body>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr",
              gap: 6,
              marginTop: 8,
            }}
          >
            {[
              "Número de agentes dimensionado; ancho de banda a 300 kbps/agente confirmado",
              "Tipo de acceso elegido (Internet / MPLS / Dedicado) y coherente con el número de agentes",
              "Latencia al DC GoContact medida < 100 ms",
              "Cat 5E + switches gestionables L2 instalados, sin Wi-Fi para agentes",
              "VLAN de voz y QoS (DSCP 40/46, cola EF) planificados",
              "Firewall abierto para el rango 185.133.136.0/22 y los puertos de §5.1",
              "Ventana de pruebas IPERF agendada, puerto 32000 abierto temporalmente",
              "Parque de PCs cumple §5.7",
              "Requisito de retención de grabaciones confirmado (por defecto 90 días)",
              "Plan de SIP trunk validado contra §6.2 (IP pública fija, sin REGISTER de entrada, sin mTLS, códec soportado)",
              "Exposición a clases de SLA y modelo de penalizaciones comunicado al cliente",
              "Contactos de PM, técnico y de red nombrados por parte del cliente",
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: "grid",
                  gridTemplateColumns: "20px 1fr",
                  gap: 10,
                  alignItems: "start",
                  padding: "8px 10px",
                  background: "#FAFAFA",
                  border: "1px solid #E2E2EC",
                  borderRadius: 4,
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 10,
                  color: "#1A1A2E",
                  lineHeight: 1.45,
                }}
              >
                <div
                  style={{
                    width: 14,
                    height: 14,
                    border: "1.5px solid #27698F",
                    borderRadius: 3,
                    marginTop: 1,
                  }}
                />
                <div>{item}</div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 18 }}>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 13,
                fontWeight: 700,
                color: "#27698F",
                marginBottom: 4,
              }}
            >
              Listo para homologación
            </div>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                color: "#1A1A2E",
                lineHeight: 1.5,
              }}
            >
              Una vez marcadas todas las casillas, el sitio está listo para
              homologación y kickoff del proyecto.
            </div>
            <div
              style={{
                fontFamily: "'Besley', Georgia, serif",
                fontSize: 11,
                fontStyle: "italic",
                color: "#555",
                marginTop: 4,
              }}
            >
              Más control. Más trazabilidad. Time-to-value más rápido para tus clientes.
            </div>
          </div>
        </PageBody>
        <PageFooter />
      </div>
    </div>
  );
};

export default PartnerTechGuideES;
