import React from "react";
import { Calendar, Trophy, DollarSign, CheckCircle2, Users, Flag } from "lucide-react";
import "./GoEngageDatasheet.css";

const MayDemoIncentive: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      <div className="page page-1" style={{ position: "relative", overflow: "hidden" }}>
        {/* Header */}
        <div className="logo" style={{ marginBottom: 12 }}>
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>
            Internal · Channel Team Incentive
          </div>
          <h1 className="hero-headline" style={{ fontSize: 40, marginBottom: 6, lineHeight: 1.1 }}>
            May <em>Demo-to-Proposal</em><br />Sales Incentive
          </h1>
          <p className="hero-desc" style={{ maxWidth: 560, fontSize: 13, lineHeight: 1.6 }}>
            A short-burst incentive rewarding the Channel Manager team that drives the most completed partner-sourced demos this May.
          </p>
        </div>

        {/* Stat bar */}
        <svg width="0" height="0" style={{ position: "absolute" }}>
          <defs>
            <linearGradient id="incentive-icon-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#43B5BF" />
              <stop offset="100%" stopColor="#27698F" />
            </linearGradient>
          </defs>
        </svg>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          background: "#F8FAFB",
          padding: "18px 0.625in",
          marginBottom: 18,
          marginLeft: "-0.625in",
          marginRight: "-0.625in",
          borderTop: "1px solid #E2E2EC",
          borderBottom: "1px solid #E2E2EC",
        }}>
          {[
            { num: "May 11–31", label: "Incentive period" },
            { num: "$300", label: "Max individual payout" },
            { num: "#1", label: "Only winning team paid" },
            { num: "3+", label: "Demos to max out" },
          ].map((s, i) => (
            <div key={i} style={{ paddingRight: 16, borderRight: i < 3 ? "1px solid #E2E2EC" : "none", paddingLeft: i > 0 ? 16 : 0, textAlign: "center" }}>
              <div style={{
                fontFamily: "'Instrument Sans', -apple-system, sans-serif",
                fontSize: 26,
                fontWeight: 500,
                marginBottom: 4,
                lineHeight: 1.1,
                background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}>{s.num}</div>
              <div style={{ fontSize: 9, color: "#555567", lineHeight: 1.4, fontFamily: "'Inter', sans-serif" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Two-column: How It Works + Payout Tiers */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 18 }}>
          {/* How It Works */}
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 8 }}>How It Works</div>
            <h2 className="hero-headline" style={{ fontSize: 22, marginBottom: 10, lineHeight: 1.2 }}>
              One winning team. <em>Top demos take it.</em>
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                { Icon: Users, title: "Channel Team Incentive", desc: "Open to Channel Manager teams (CM, PSM, Strategist aligned)." },
                { Icon: Trophy, title: "Top Team Wins", desc: "The team with the most completed partner-sourced demos wins." },
                { Icon: DollarSign, title: "#1 Only", desc: "Only the top-performing team is eligible for payout." },
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 12px", background: "rgba(67,181,191,0.06)", borderRadius: 8, border: "1px solid #E2E2EC" }}>
                  <item.Icon size={16} style={{ stroke: "url(#incentive-icon-grad)", flexShrink: 0, marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 2 }}>{item.title}</div>
                    <div style={{ fontSize: 9.5, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payout Tiers */}
          <div style={{ border: "1px solid #D0E8EA", borderRadius: 10, padding: "16px 18px", background: "rgba(67, 181, 191, 0.04)" }}>
            <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}>Incentive Structure · Individual Payout</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {[
                { count: "1", label: "Partner-Sourced Demo", amount: "$100" },
                { count: "2", label: "Partner-Sourced Demos", amount: "$200" },
                { count: "3+", label: "Partner-Sourced Demos", amount: "$300", max: true },
              ].map((tier, i) => (
                <div key={i} style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "12px 14px",
                  background: "#FFFFFF",
                  borderRadius: 8,
                  border: tier.max ? "1px solid #43B5BF" : "1px solid #E2E2EC",
                }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: 8,
                    background: "linear-gradient(135deg, #43B5BF, #27698F)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "#FFFFFF", fontWeight: 700, fontSize: 14,
                    fontFamily: "'Inter', sans-serif", flexShrink: 0,
                  }}>{tier.count}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>{tier.label}</div>
                    {tier.max && <div style={{ fontSize: 8.5, color: "#43B5BF", fontFamily: "'Inter', sans-serif", fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase", marginTop: 1 }}>Max Payout</div>}
                  </div>
                  <div style={{
                    fontFamily: "'Instrument Sans', -apple-system, sans-serif",
                    fontSize: 22, fontWeight: 500,
                    background: "linear-gradient(90deg, #43B5BF, #27698F, #C686F8)",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}>{tier.amount}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 12, border: "1px solid #43B5BF", padding: "10px 14px", background: "rgba(67, 181, 191, 0.04)", borderRadius: 8 }}>
              <p style={{ fontSize: 10, color: "#555567", lineHeight: 1.55, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                Payout is <strong style={{ color: "#1A1A2E" }}>per individual</strong> (CM, PSM, Strategist) on the winning team, based on total completed demos.
              </p>
            </div>
          </div>
        </div>

        {/* Rules + Tiebreaker */}
        <div style={{ fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}>Rules & Eligibility</div>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 10 }}>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "12px 14px" }}>
            {[
              { Icon: CheckCircle2, text: <><strong>NET NEW opportunities only</strong> — no existing pipeline qualifies.</> },
              { Icon: CheckCircle2, text: <>Demo must be <strong>sourced through a partner</strong>.</> },
              { Icon: Calendar, text: <>Scheduled <strong>and</strong> completed between <strong>May 11 – May 31</strong>.</> },
              { Icon: Users, text: <>The <strong>customer must attend</strong> the demo.</> },
            ].map((r, i) => (
              <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: i < 3 ? 8 : 0 }}>
                <r.Icon size={14} style={{ stroke: "url(#incentive-icon-grad)", flexShrink: 0, marginTop: 2 }} />
                <div style={{ fontSize: 10.5, color: "#555567", lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{r.text}</div>
              </div>
            ))}
          </div>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "12px 14px", background: "#F8FAFB" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <Flag size={14} style={{ stroke: "url(#incentive-icon-grad)" }} />
              <div style={{ fontSize: 11, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Tiebreaker</div>
            </div>
            <p style={{ fontSize: 10, color: "#555567", lineHeight: 1.6, margin: 0, fontFamily: "'Inter', sans-serif" }}>
              In the event of a tie, the team that reached the final demo count <strong style={{ color: "#1A1A2E" }}>first</strong> will be declared the winner.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="page-bottom-cta" style={{ bottom: "0.3in" }}>
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" style={{ height: 53 }} />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
        </div>
      </div>
    </div>
  );
};

export default MayDemoIncentive;
