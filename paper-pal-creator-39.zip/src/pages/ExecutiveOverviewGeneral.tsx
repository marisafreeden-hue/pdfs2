import React from "react";
import { ShieldCheck, Lock, Globe, Phone, Headphones, Sparkles, TrendingUp, Heart, Server, Users } from "lucide-react";
import "./GoEngageDatasheet.css";

import logoPfizer from "@/assets/logo-pfizer.png.asset.json";
import logoLoreal from "@/assets/logo-loreal.png.asset.json";
import logoUps from "@/assets/logo-ups.png.asset.json";
import logoToyota from "@/assets/logo-toyota.png.asset.json";
import logoHertz from "@/assets/logo-hertz.png.asset.json";
import logoSiemens from "@/assets/logo-siemens.png.asset.json";

import jeffPritle from "@/assets/jeff-pritle.jpeg.asset.json";
import mollyLozano from "@/assets/molly-lozano.png.asset.json";
import ricardoCosta from "@/assets/ricardo-costa.png.asset.json";
import rodrigoJaramillo from "@/assets/rodrigo-jaramillo.jpeg.asset.json";
import emmanuelMoreira from "@/assets/emmanuel-moreira.jpeg.asset.json";
import jasonSmith from "@/assets/jason-smith.jpeg.asset.json";
import jimMurphy from "@/assets/jim-murphy.jpeg.asset.json";
import samGhahremanpour from "@/assets/sam-ghahremanpour.jpeg.asset.json";
import georgeMitsopoulos from "@/assets/george-mitsopoulos.jpeg.asset.json";
import gurdipJande from "@/assets/gurdip-jande.jpeg.asset.json";
import marisaFreeden from "@/assets/marisa-freeden.jpeg.asset.json";
import worldMap from "@/assets/world-dot-map.png.asset.json";

const SECTION_LABEL: React.CSSProperties = {
  fontSize: 8, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase",
  color: "#338FAD", fontFamily: "'Inter', sans-serif", marginBottom: 10,
};

const PersonCard: React.FC<{ name: string; title: string; photo?: string }> = ({ name, title, photo }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
    {photo ? (
      <img src={photo} alt={name} style={{ width: 44, height: 44, borderRadius: "50%", objectFit: "cover", border: "1px solid #E2E2EC", flexShrink: 0 }} />
    ) : (
      <div style={{
        width: 44, height: 44, borderRadius: "50%",
        background: "linear-gradient(135deg, #43B5BF 0%, #27698F 100%)",
        border: "1px solid #E2E2EC", flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "'Inter', sans-serif",
      }}>
        {name.split(" ").map(n => n[0]).slice(0, 2).join("")}
      </div>
    )}
    <div style={{ minWidth: 0 }}>
      <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.2 }}>{name}</div>
      <div style={{ fontSize: 9, color: "#555567", fontFamily: "'Inter', sans-serif", lineHeight: 1.3, marginTop: 1 }}>{title}</div>
    </div>
  </div>
);

const ComplianceBadge: React.FC<{ label: string }> = ({ label }) => (
  <div style={{
    display: "inline-flex", alignItems: "center", gap: 6,
    border: "1px solid #43B5BF", borderRadius: 999, padding: "4px 10px",
    background: "rgba(67,181,191,0.06)",
  }}>
    <ShieldCheck size={11} style={{ color: "#27698F" }} />
    <span style={{ fontSize: 9, fontWeight: 700, color: "#1A1A2E", letterSpacing: "0.04em", fontFamily: "'Inter', sans-serif" }}>{label}</span>
  </div>
);

const Footer: React.FC = () => (
  <>
    <div className="page-bottom-cta" style={{ bottom: "0.3in" }}>
      <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" style={{ height: 53 }} />
    </div>
    <div className="page-bottom-blur" />
    <div className="page-bottom-wave">
      <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" style={{ width: "59%", marginLeft: "auto", display: "block" }} />
    </div>
  </>
);

const Logo: React.FC = () => (
  <div className="logo" style={{ marginBottom: 24 }}>
    <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
  </div>
);

const ExecutiveOverview: React.FC = () => {
  const handleExportPDF = () => window.print();

  const executives = [
    { name: "Jim Murphy", title: "CEO & Co-Founder", photo: jimMurphy.url },
    { name: "Sam Ghahremanpour", title: "President", photo: samGhahremanpour.url },
    { name: "George Mitsopoulos", title: "COO", photo: georgeMitsopoulos.url },
    { name: "Gurdip Jande", title: "Chief Product Officer", photo: gurdipJande.url },
    { name: "Marisa Freeden", title: "Chief Marketing Officer", photo: marisaFreeden.url },
    { name: "Jeff Pritle", title: "Chief Financial Officer", photo: jeffPritle.url },
  ];

  const salesLeaders = [
    { name: "Molly Lozano", title: "Channel Chief, U.S.", photo: mollyLozano.url },
    { name: "Ricardo Costa", title: "VP of Sales, EMEA", photo: ricardoCosta.url },
    { name: "Rodrigo Jaramillo", title: "Head of Sales, LATAM", photo: rodrigoJaramillo.url },
  ];

  const facts = [
    { label: "Founded", value: "2005" },
    { label: "Headquarters", value: "Northridge, CA" },
    { label: "Ownership", value: "Privately Held, PE-Backed" },
    { label: "Business", value: "UCaaS, CCaaS & AI-Powered CX" },
    { label: "Customers", value: "Thousands across North America, EMEA & LATAM" },
    { label: "Profile", value: "Operationally profitable with sustainable growth" },
  ];

  const customerLogos = [
    { src: logoPfizer.url, alt: "Pfizer" },
    { src: logoLoreal.url, alt: "L'Oréal" },
    { src: logoUps.url, alt: "UPS" },
    { src: logoToyota.url, alt: "Toyota" },
    { src: logoHertz.url, alt: "Hertz" },
    { src: logoSiemens.url, alt: "Siemens" },
  ];

  return (
    <div className="datasheet-wrapper">
      <button className="export-pdf-btn no-print" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ============ PAGE 1: Executive Overview + Leadership ============ */}
      <div className="page page-1" style={{ position: "relative", overflow: "hidden" }}>
        <Logo />

        <h1 className="hero-headline" style={{ fontSize: 40, marginBottom: 6, lineHeight: 1.1 }}>
          Executive <em>Overview</em>
        </h1>
        <p className="hero-desc" style={{ maxWidth: "100%", fontSize: 12, lineHeight: 1.6, marginBottom: 14 }}>
          Broadvoice is a privately held, operationally profitable cloud communications provider delivering UCaaS, CCaaS, and AI-powered customer experience solutions across North America, EMEA, and LATAM.
        </p>

        {/* Facts strip */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 0,
          background: "#F8FAFB",
          border: "1px solid #E2E2EC",
          borderRadius: 10,
          padding: "14px 18px",
          marginBottom: 14,
        }}>
          {facts.map((f, i) => (
            <div key={i} style={{
              padding: "6px 14px",
              borderRight: (i % 3 !== 2) ? "1px solid #E2E2EC" : "none",
              borderBottom: i < 3 ? "1px solid #E2E2EC" : "none",
            }}>
              <div style={{ fontSize: 7.5, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "#888899", fontFamily: "'Inter', sans-serif", marginBottom: 3 }}>{f.label}</div>
              <div style={{ fontSize: 10.5, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", lineHeight: 1.3 }}>{f.value}</div>
            </div>
          ))}
        </div>

        {/* Two-column: Company Overview (left) + Executive Leadership (right) */}
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 18, marginBottom: 18 }}>
          <div>
            <div style={SECTION_LABEL}>Company Overview</div>
            <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
              <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, marginBottom: 12, fontFamily: "'Inter', sans-serif" }}>
                For more than two decades, Broadvoice has helped businesses modernize communications, improve customer engagement, and support distributed workforces through reliable, scalable cloud technology.
              </p>
              <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                Backed by private equity investment and supported by a strong financial foundation, Broadvoice combines the agility of an innovation-focused technology company with the stability and governance expected of a trusted enterprise communications partner.
              </p>
            </div>

            {/* Mission */}
            <div style={{ marginTop: 14 }}>
              <div style={SECTION_LABEL}>Mission</div>
              <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "14px 16px" }}>
                <p style={{ fontSize: 13, color: "#555567", lineHeight: 1.7, margin: 0, fontFamily: "'Inter', sans-serif" }}>
                  Empower organizations with intelligent communication solutions that create exceptional customer experiences, strengthen workforce collaboration, and drive measurable business outcomes — unifying communications, contact center, and AI into a seamless platform.
                </p>
              </div>
            </div>

            {/* Global presence map */}
            <div style={{ marginTop: 16 }}>
              <div style={SECTION_LABEL}>Global Presence</div>
              <div style={{ padding: 0, marginTop: -32 }}>
                <div style={{
                  position: "relative",
                  width: "100%",
                  aspectRatio: "2 / 1",
                  overflow: "visible",
                }}>
                  <img
                    src={worldMap.url}
                    alt="Global presence"
                    style={{
                      position: "absolute", inset: 0, width: "100%", height: "100%",
                      objectFit: "contain", objectPosition: "center top", opacity: 0.18,
                    }}
                  />
                  {[
                    { name: "United States", x: 22, y: 42, labelPos: "bottom" as const },
                    { name: "Colombia", x: 30, y: 60, labelPos: "bottom" as const },
                    { name: "Portugal", x: 45.2, y: 39, labelPos: "left" as const },
                    { name: "Spain", x: 48.2, y: 39, labelPos: "right" as const },
                  ].map((loc) => {
                    const labelStyle: React.CSSProperties = {
                      position: "absolute",
                      fontSize: 8, fontWeight: 700, color: "#1A1A2E",
                      fontFamily: "'Inter', sans-serif", whiteSpace: "nowrap",
                      letterSpacing: "0.04em", textTransform: "uppercase",
                    };
                    if (loc.labelPos === "left") {
                      Object.assign(labelStyle, { right: "calc(100% + 6px)", top: "50%", transform: "translateY(-50%)" });
                    } else if (loc.labelPos === "right") {
                      Object.assign(labelStyle, { left: "calc(100% + 6px)", top: "50%", transform: "translateY(-50%)" });
                    } else {
                      Object.assign(labelStyle, { left: "50%", top: "calc(100% + 4px)", transform: "translateX(-50%)" });
                    }
                    return (
                      <div key={loc.name} style={{
                        position: "absolute", left: `${loc.x}%`, top: `${loc.y}%`,
                        transform: "translate(-50%, -50%)",
                      }}>
                        <span style={{
                          display: "block", width: 6, height: 6, borderRadius: "50%",
                          background: "#43B5BF",
                          boxShadow: "0 0 0 2px rgba(67,181,191,0.22), 0 0 0 4px rgba(67,181,191,0.10)",
                        }} />
                        <span style={labelStyle}>{loc.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          <div>
            <div style={SECTION_LABEL}>Executive Leadership</div>
            <div style={{
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              {executives.map((p, i) => <PersonCard key={i} {...p} />)}
            </div>
            <div style={{ ...SECTION_LABEL, marginTop: 14 }}>Sales Leadership</div>
            <div style={{
              border: "1px solid #E2E2EC", borderRadius: 10, padding: "12px 14px",
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              {salesLeaders.map((p, i) => <PersonCard key={i} {...p} />)}
            </div>
          </div>
        </div>

        <Footer />
      </div>

      {/* ============ PAGE 2: Platform, Trust, Customers ============ */}
      <div className="page page-2" style={{ position: "relative", overflow: "hidden" }}>
        <Logo />

        <svg width="0" height="0" style={{ position: "absolute" }}>
          <defs>
            <linearGradient id="exec-icon-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#43B5BF" />
              <stop offset="100%" stopColor="#27698F" />
            </linearGradient>
          </defs>
        </svg>

        {/* 1. Solutions Portfolio */}
        <div style={SECTION_LABEL}>Solutions Portfolio</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 18 }}>
          {[
            {
              Icon: Phone, title: "Unified Communications", sub: "UCaaS",
              items: ["Cloud voice & business telephony", "Messaging & collaboration", "Mobility & hybrid workforce", "Centralized administration"],
            },
            {
              Icon: Headphones, title: "Contact Center", sub: "CCaaS",
              items: ["Omnichannel engagement", "Intelligent routing & queueing", "Workforce optimization & analytics", "Supervisor & performance tools"],
            },
            {
              Icon: Sparkles, title: "AI-Powered CX", sub: "GoAI Suite",
              items: ["Conversational AI & automation", "AI-assisted agent workflows", "Automated summaries & insights", "CX intelligence"],
            },
          ].map((c, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <c.Icon size={20} style={{ stroke: "url(#exec-icon-grad)", flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>{c.title}</div>
                  <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: "0.12em", color: "#43B5BF", fontFamily: "'Inter', sans-serif" }}>{c.sub}</div>
                </div>
              </div>
              {c.items.map((b, j) => (
                <div key={j} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                  <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.55 }}>•</span>
                  <span style={{ fontSize: 11, color: "#555567", lineHeight: 1.55, fontFamily: "'Inter', sans-serif" }}>{b}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* 2 + 3. Compliance & Reliability */}
        <div style={SECTION_LABEL}>Security, Compliance & Reliability</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 18 }}>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Lock size={16} style={{ color: "#43B5BF" }} />
              <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Security & Compliance</div>
            </div>
            {[
              "SOC 2 Type 1 audited environment aligned to industry-recognized controls",
              "HIPAA-compliant workflows for protected health information",
              "GDPR-aligned data privacy and processing practices",
            ].map((b, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.6 }}>•</span>
                <span style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
              </div>
            ))}
          </div>
          <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <Server size={16} style={{ color: "#43B5BF" }} />
              <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Platform Reliability</div>
            </div>
            {[
              "Enterprise-grade cloud architecture built for resiliency",
              "High-availability infrastructure with geographic redundancy",
              "Proactive monitoring and operational excellence",
              "Robust disaster recovery and continuity planning",
            ].map((b, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 5 }}>
                <span style={{ color: "#43B5BF", fontSize: 11, lineHeight: 1.6 }}>•</span>
                <span style={{ fontSize: 11.5, color: "#555567", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Financial Stability */}
        <div style={SECTION_LABEL}>Financial Strength & Stability</div>
        <div style={{ border: "1px solid #E2E2EC", borderRadius: 10, padding: "16px 18px", background: "#F8FAFB", marginBottom: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
            <TrendingUp size={16} style={{ color: "#43B5BF" }} />
            <div style={{ fontSize: 14, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif" }}>Operationally Profitable. PE-Backed.</div>
          </div>
          <p style={{ fontSize: 12, color: "#555567", lineHeight: 1.65, margin: 0, fontFamily: "'Inter', sans-serif" }}>
            Operationally profitable with a long track record of sustainable growth and disciplined financial management. PE-backing provides strategic capital and resources for continued investment in product, infrastructure, security, and customer success.
          </p>
        </div>

        {/* 5. Why Broadvoice */}
        <div style={SECTION_LABEL}>Why Organizations Choose Broadvoice</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginBottom: 18 }}>
          {[
            { t: "Financially Stable", d: "Operationally profitable & PE-backed" },
            { t: "Trusted & Secure", d: "SOC 2-aligned controls & governance" },
            { t: "Reliable", d: "Enterprise-grade infrastructure" },
            { t: "Customer-Centric", d: "Dedicated implementation & success teams" },
            { t: "Innovative", d: "Ongoing AI & CX investment" },
          ].map((w, i) => (
            <div key={i} style={{ border: "1px solid #E2E2EC", borderRadius: 8, padding: "12px 13px" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1A1A2E", fontFamily: "'Inter', sans-serif", marginBottom: 4 }}>{w.t}</div>
              <div style={{ fontSize: 10, color: "#555567", lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>{w.d}</div>
            </div>
          ))}
        </div>

        {/* 6. Logos */}
        <div style={SECTION_LABEL}>Trusted by Leading Brands Across the Globe</div>
        <div style={{
          border: "1px solid #E2E2EC", borderRadius: 10, padding: "4px 16px",
          display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12,
          alignItems: "center", justifyItems: "center",
          background: "#FFFFFF",
          marginTop: -2,
        }}>
          {customerLogos.map((l, i) => {
            const isSiemens = l.alt === "Siemens";
            return (
              <img key={i} src={l.src} alt={l.alt}
                style={{
                  maxHeight: isSiemens ? 50 : 34,
                  maxWidth: "100%",
                  objectFit: "contain",
                  filter: "grayscale(100%)",
                }} />
            );
          })}
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default ExecutiveOverview;
