import React, { useState, useEffect, useCallback } from "react";
import "./GoEngageDatasheet.css";
import EditableText from "@/components/datasheet/EditableText";
import { loadContent, saveContent } from "@/lib/datasheet-content";
import { toast } from "@/hooks/use-toast";

const SHEET_ID = "goengage";

const DEFAULT_CONTENT: Record<string, string> = {
  hero_headline_1: "GoInsights",
  hero_headline_em: "AI Analyst",
  hero_body: "Stop building reports. Start getting answers.",
  hero_desc:
    "AI Analyst replaces dashboards and manual reporting with instant, plain-language answers. Midmarket contact center leaders spend 10–12 hours per week pulling reports across disconnected systems. AI Analyst cuts that by 70% — delivering answers on demand without adding IT burden.",
  stat_label: "Estimated Time Savings",
  stat_value_num: "70",
  stat_value_unit: "%",
  stat_desc: "Less time spent on reporting\nper operations manager",
  problem_title_1: "The",
  problem_title_em: "Problem",
  problem_body:
    "Contact center leaders are drowning in data but starving for insight. Reporting requires manual exports, spreadsheet reconciliation, and analyst time — slowing decisions and delaying action. By the time the numbers land, the moment has passed.",
  stat1_num: "10hrs",
  stat1_strong: "Per week on manual reporting",
  stat1_body: "Per operations manager, pulling reports across disconnected systems",
  stat2_num: "$33K",
  stat2_strong: "Saved annually per leader",
  stat2_body: "Redirect reporting time to improving performance and coaching",
  stat3_num: "50%",
  stat3_strong: "Of CC data stays siloed",
  stat3_body: "Only half of contact center data surfaces in a unified view today",
  features_title_1: "What GoInsights AI Analyst",
  features_title_em: "Does",
  features_body:
    "An AI-powered conversational analytics interface built natively into GoContact — not bolted on. It replaces the reporting your team shouldn't have to build, and makes every insight accessible.",
  f1_title: "Instant conversational answers grounded in your contact center's KPI data",
  f1_body:
    "Ask any operational question in plain language and get an immediate, data-backed answer. No reporting skills required.",
  f2_title: "One source of truth",
  f2_body:
    "Uses the same governed KPI dataset that powers GoInsights dashboards, ensuring consistent metrics across reports and AI answers.",
  f3_title: "Built for every role",
  f3_body:
    "Agents, supervisors, and executives each see the metrics that matter to them — without going through IT.",
  f4_title: "Proactive trend detection",
  f4_body:
    "Identify performance changes quickly through natural-language queries and KPI comparisons.",
  f5_title: "Native to GoContact",
  f5_body:
    "No integration overhead. Faster deployment, unified reporting, and one platform for your entire contact center.",
  f6_title: "Included at no extra cost",
  f6_body:
    "Built-in security, role-based access, and conversational AI — all part of your GoContact platform, not an add-on.",
  // Page 2
  results_title_1: "Proven Impact Across",
  results_title_em: "Roles",
  t1_industry: "Operations Manager",
  t1_usecase: "Real-time queue monitoring & KPI reviews",
  t1_outcome_num: "10 hrs",
  t1_outcome_text: "/week returned to operations",
  t2_industry: "Executive / VP",
  t2_usecase: "Board-ready summaries via natural language",
  t2_outcome_num: "Reduced",
  t2_outcome_text: "dependency on analyst-built reports",
  t3_industry: "Supervisor",
  t3_usecase: "Agent performance & coaching insights",
  t3_outcome_num: "Minutes",
  t3_outcome_text: "not days to spot coaching gaps",
  t4_industry: "All Roles",
  t4_usecase: "Self-service analytics & trend detection",
  t4_outcome_num: "70%",
  t4_outcome_text: "reduction in reporting time",
  table_footnote:
    "Time savings estimates based on industry benchmarks from HiveDesk, BrightMetrics, and internal Broadvoice analysis.",
  why_now_title_1: "Why",
  why_now_title_em: "Now",
  why_now_body:
    "Contact centers generate more data than ever, but most of it stays locked in siloed tools and manual exports. Gartner projects 40% of enterprise applications will embed AI agents by end of 2026. Organizations that unify their analytics data and put AI-powered insights into the hands of every role aren't just reporting faster — they're making better decisions. Those that wait aren't standing still. They're falling behind.",
  closing_line:
    "Your team's time isn't going up.\nYour reporting demands aren't going down.\nGoInsights AI Analyst is how you close the gap.",
  about_title: "About Broadvoice",
  about_body:
    "Broadvoice delivers intelligent CX solutions for midmarket organizations — empowering business teams to design modern, frictionless customer experiences with AI that's practical, easy to use, and purpose-built for how they work.",
  about_addon: "GoInsights AI Analyst is available as part of GoContact.",
};

const GoEngageDatasheetEditable: React.FC = () => {
  const [fields, setFields] = useState<Record<string, string>>(DEFAULT_CONTENT);
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    loadContent(SHEET_ID).then((saved) => {
      if (Object.keys(saved).length > 0) {
        setFields((prev) => ({ ...prev, ...saved }));
      }
      setLoaded(true);
    });
  }, []);

  const handleChange = useCallback((key: string, value: string) => {
    setFields((prev) => ({ ...prev, [key]: value }));
    setDirty(true);
  }, []);

  const handleSave = async () => {
    setSaving(true);
    const ok = await saveContent(SHEET_ID, fields);
    setSaving(false);
    setDirty(false);
    toast({
      title: ok ? "Saved!" : "Error saving",
      description: ok ? "All changes have been saved." : "Please try again.",
      variant: ok ? "default" : "destructive",
    });
  };

  const handleExportPDF = () => window.print();

  const E = useCallback(
    ({
      k,
      tag,
      className,
      style,
    }: {
      k: string;
      tag?: "h1" | "h2" | "h3" | "p" | "div" | "span" | "em" | "strong";
      className?: string;
      style?: React.CSSProperties;
    }) => (
      <EditableText
        value={fields[k] ?? ""}
        fieldKey={k}
        onChange={handleChange}
        tag={tag}
        className={className}
        style={style}
      />
    ),
    [fields, handleChange]
  );

  if (!loaded) {
    return (
      <div className="datasheet-wrapper">
        <div style={{ textAlign: "center", padding: 80, color: "#888" }}>Loading…</div>
      </div>
    );
  }

  return (
    <div className="datasheet-wrapper">
      <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 20 }}>
        <button className="export-pdf-btn" onClick={handleExportPDF} style={{ margin: 0 }}>
          Export as PDF
        </button>
        <button
          className="export-pdf-btn"
          onClick={handleSave}
          disabled={saving}
          style={{
            margin: 0,
            background: dirty
              ? "linear-gradient(90deg, #C686F8, #27698F)"
              : "linear-gradient(90deg, #43B5BF, #27698F)",
            opacity: saving ? 0.6 : 1,
          }}
        >
          {saving ? "Saving…" : dirty ? "Save Changes" : "Saved"}
        </button>
      </div>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="hero">
          <div>
            <h1 className="hero-headline">
              <E k="hero_headline_1" tag="span" /> <E k="hero_headline_em" tag="em" />
            </h1>
            <E k="hero_body" tag="p" className="hero-body" />
            <E k="hero_desc" tag="p" className="hero-desc" />
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <E k="stat_label" tag="div" className="stat-label-top" />
              <div className="stat-value">
                <E k="stat_value_num" tag="span" className="stat-value-sans" />
                <E k="stat_value_unit" tag="em" />
              </div>
              <E k="stat_desc" tag="div" className="stat-desc" />
            </div>
          </div>
        </div>

        <hr />

        <h2 className="section-title">
          <E k="problem_title_1" tag="span" /> <E k="problem_title_em" tag="em" />
        </h2>
        <E k="problem_body" tag="p" className="section-body" />

        <div className="stats-row">
          {[1, 2, 3].map((n) => (
            <div className="stat-item" key={n}>
              <E k={`stat${n}_num`} tag="div" className="num" />
              <div className="lbl">
                <E k={`stat${n}_strong`} tag="strong" />
                <E k={`stat${n}_body`} tag="span" />
              </div>
            </div>
          ))}
        </div>

        <hr className="section-divider" />

        <h2 className="section-title" style={{ marginTop: "12px" }}>
          <E k="features_title_1" tag="span" /> <E k="features_title_em" tag="em" />
        </h2>
        <E k="features_body" tag="p" className="section-body" />

        <div className="feature-grid">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div className="feature-item" key={n}>
              <E k={`f${n}_title`} tag="div" className="feature-title" />
              <E k={`f${n}_body`} tag="div" className="feature-body" />
            </div>
          ))}
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <h2 className="section-title">
          <E k="results_title_1" tag="span" /> <E k="results_title_em" tag="em" />
        </h2>

        <div className="outcomes-container">
          <div className="outcomes-blur" />
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Role</th>
                <th>Top Use Case</th>
                <th>Outcome</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4].map((n) => (
                <tr key={n}>
                  <td>
                    <E k={`t${n}_industry`} tag="span" />
                  </td>
                  <td>
                    <E k={`t${n}_usecase`} tag="span" />
                  </td>
                  <td>
                    <E k={`t${n}_outcome_num`} tag="span" className="outcome-num" />{" "}
                    <E k={`t${n}_outcome_text`} tag="span" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <E k="table_footnote" tag="p" className="table-footnote" />

        <hr />

        <h2 className="section-title">
          <E k="why_now_title_1" tag="span" /> <E k="why_now_title_em" tag="em" />
        </h2>
        <E k="why_now_body" tag="p" className="section-body" />

        <E k="closing_line" tag="p" className="closing-line" />

        <div className="about-section">
          <E k="about_title" tag="h3" className="about-title" />
          <E k="about_body" tag="p" className="about-body" />
          <E k="about_addon" tag="p" className="about-addon" />
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default GoEngageDatasheetEditable;
