import React from "react";
import {
  PhoneCall,
  UserSearch,
  FileText,
  Zap,
  Sparkles,
  BarChart3,
  MousePointerClick,
  Bell,
  ClipboardList,
  Workflow,
  LineChart,
  Layers,
} from "lucide-react";
import "./GoEngageDatasheet.css";

const iconWrapStyle: React.CSSProperties = {
  width: 34,
  height: 34,
  borderRadius: 8,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  background: "linear-gradient(135deg, #43B5BF 0%, #27698F 100%)",
  color: "#fff",
  marginBottom: 8,
};

const FeatureIcon = ({ children }: { children: React.ReactNode }) => (
  <div style={iconWrapStyle}>{children}</div>
);

const ZohoIntegrationDatasheet: React.FC = () => {
  const handleExportPDF = () => window.print();

  return (
    <div className="datasheet-wrapper bhive-datasheet">
      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="hero">
          <div>
            <h1 className="hero-headline">
              b-<em>hive</em> + Zoho Integration
            </h1>
            <p className="hero-body">
              Connect b-hive calling workflows directly inside Zoho.
            </p>

            <p className="hero-desc">
              b-hive is Broadvoice's unified communications platform, built to help teams manage business calling, messaging, meetings, and collaboration in one place. With the b-hive + Zoho integration, teams can access b-hive calling capabilities directly within Zoho to make and receive calls, view inbound caller information, add call notes and dispositions, and keep call activity connected to the right customer or contact record.
            </p>
            <p className="hero-desc" style={{ marginTop: 8 }}>
              By integrating b-hive with Zoho, sales and customer support teams can reduce manual steps, respond faster, and work more efficiently from the tools they already use every day.
            </p>
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <div className="stat-label-top">Calling Built Into</div>
              <div className="stat-value">
                <em>Zoho</em>
              </div>
              <div className="stat-desc">
                Click-to-call, screen pop,<br />notes &amp; analytics
              </div>
            </div>
          </div>
        </div>

        <hr />

        <h2 className="section-title">Why Teams Use the <em>b-hive + Zoho</em> Integration</h2>
        <p className="section-body">
          Bring b-hive calling into the Zoho workflows sales and support teams already use every day — so every conversation stays connected to the right customer record.
        </p>

        <div className="feature-grid" style={{ marginTop: 8 }}>
          <div className="feature-item">
            <FeatureIcon><PhoneCall size={18} /></FeatureIcon>
            <div className="feature-title">Simplify Daily Calling Workflows</div>
            <div className="feature-body">
              Make outbound calls directly from Zoho with click-to-call, helping teams avoid manual dialing and stay focused on the customer conversation.
            </div>
          </div>
          <div className="feature-item">
            <FeatureIcon><UserSearch size={18} /></FeatureIcon>
            <div className="feature-title">Give Teams Customer Context Faster</div>
            <div className="feature-body">
              When an inbound call comes in, screen pop automatically displays relevant caller information and links it to the customer or contact account in Zoho.
            </div>
          </div>
          <div className="feature-item">
            <FeatureIcon><FileText size={18} /></FeatureIcon>
            <div className="feature-title">Keep Call Records Connected</div>
            <div className="feature-body">
              Users can add call notes and dispositions after each conversation, with activity automatically attached to the customer or contact account in Zoho.
            </div>
          </div>
          <div className="feature-item">
            <FeatureIcon><Zap size={18} /></FeatureIcon>
            <div className="feature-title">Improve Team Productivity</div>
            <div className="feature-body">
              Reduce time spent manually dialing numbers or searching for customer information across systems.
            </div>
          </div>
          <div className="feature-item">
            <FeatureIcon><Sparkles size={18} /></FeatureIcon>
            <div className="feature-title">Support Better Customer Experiences</div>
            <div className="feature-body">
              Help teams understand who is calling, respond faster, and create a more streamlined customer experience.
            </div>
          </div>
          <div className="feature-item">
            <FeatureIcon><BarChart3 size={18} /></FeatureIcon>
            <div className="feature-title">Measure Sales Team Performance</div>
            <div className="feature-body">
              Use call analytics in Zoho to measure activity, outcomes, and sales team performance over time.
            </div>
          </div>
        </div>


        <div className="page-bottom-cta" style={{ fontFamily: 'Instrument Sans, sans-serif', fontSize: '13px', fontWeight: 600, color: '#27698F' }}>
          Contact your channel manager to learn more.
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <h2 className="section-title">Key <em>Capabilities</em></h2>
        <p className="section-body">
          Everything sales and support teams need to run calling workflows without leaving Zoho.
        </p>

        <div className="feature-grid">
          {[
            { title: "Click-to-Call", body: "Initiate outbound calls from Zoho with a simple click using b-hive calling." },
            { title: "Screen Pop", body: "Automatically display inbound caller information and link it to the right Zoho customer or contact record." },
            { title: "Call Notes & Dispositions", body: "Capture conversation details after each call and attach them to the customer or contact account in Zoho." },
            { title: "Direct Zoho Integration", body: "Bring b-hive calling workflows into Zoho to support sales, customer support, and other customer-facing processes." },
            { title: "Call Analytics", body: "Use call analytics in Zoho to help measure sales team performance and coach based on real outcomes." },
            { title: "Unified Communications", body: "Backed by the full b-hive platform — calling, messaging, meetings, and collaboration in one solution." },
          ].map((item, i) => (
            <div
              key={item.title}
              className="feature-item"
              style={{
                borderLeft: "3px solid transparent",
                borderImage: "linear-gradient(180deg, #43B5BF 0%, #27698F 100%) 1",
                paddingLeft: 12,
              }}
            >
              <div
                style={{
                  fontFamily: "Instrument Sans, sans-serif",
                  fontSize: 26,
                  fontWeight: 700,
                  lineHeight: 1,
                  background: "linear-gradient(135deg, #43B5BF 0%, #27698F 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  marginBottom: 4,
                }}
              >
                {String(i + 1).padStart(2, "0")}
              </div>
              <div className="feature-title">{item.title}</div>
              <div className="feature-body">{item.body}</div>
            </div>
          ))}
        </div>


        <hr />

        <h2 className="section-title">b-hive Calling, Built Into the <em>Zoho Workflow</em></h2>
        <p className="section-body">
          With b-hive and Zoho working together, teams can spend less time managing manual calling tasks and more time staying connected with customers and team members.
        </p>

        <div className="outcomes-container">
          <table className="outcomes-table">
            <thead>
              <tr>
                <th>Capability</th>
                <th>What It Delivers</th>
                <th>Best For</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Click-to-Call</td>
                <td>Outbound calls launched from any Zoho record</td>
                <td>Sales &amp; support reps</td>
              </tr>
              <tr>
                <td>Screen Pop</td>
                <td>Inbound caller identified &amp; matched to Zoho record</td>
                <td>Customer-facing teams</td>
              </tr>
              <tr>
                <td>Notes &amp; Dispositions</td>
                <td>Call context captured on the customer record</td>
                <td>Reps &amp; managers</td>
              </tr>
              <tr>
                <td>Call Analytics</td>
                <td>Activity, outcomes &amp; performance in Zoho</td>
                <td>Sales leadership</td>
              </tr>
              <tr>
                <td>b-hive Platform</td>
                <td>Calling, messaging, meetings &amp; collaboration</td>
                <td>Every employee</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="about-section" style={{ marginTop: 48, transform: "translateY(60px)" }}>
          <h3 className="about-title">See the b-hive + Zoho integration in action.</h3>
          <p className="about-body">
            Schedule a demo to see how bringing b-hive calling into Zoho helps your sales and support teams work faster, capture more context, and deliver better customer experiences.
          </p>
        </div>

        <div className="page-bottom-cta" style={{ fontFamily: 'Instrument Sans, sans-serif', fontSize: '13px', fontWeight: 600, color: '#27698F' }}>
          Contact your channel manager to learn more.
        </div>

        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default ZohoIntegrationDatasheet;
