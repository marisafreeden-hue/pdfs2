import React from "react";
import {
  MessageSquare,
  PhoneCall,
  Megaphone,
  LayoutDashboard,
  GraduationCap,
  BarChart3,
  Ticket,
  LifeBuoy,
  Sparkles,
  Users,
  Settings2,
  LineChart,
  TrendingUp,
  ShieldCheck,
  Mic,
  Bot,
  FileText,
  Brain,
  CalendarClock,
  ClipboardCheck,
  Plug,
  Boxes,
} from "lucide-react";
import "./GoEngageDatasheet.css";

const Card: React.FC<{
  icon: React.ReactNode;
  title: string;
  body: string;
}> = ({ icon, title, body }) => (
  <div className="gc-card">
    <div className="gc-card-icon">{icon}</div>
    <div className="gc-card-content">
      <div className="gc-card-title">{title}</div>
      <div className="gc-card-body">{body}</div>
    </div>
  </div>
);

const GoContactDatasheet: React.FC = () => {
  const handleExportPDF = () => window.print();

  const ICON = 18;

  return (
    <div className="datasheet-wrapper gocontact-datasheet">
      <style>{`
        .gocontact-datasheet .gc-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
          margin-top: 10px;
        }
        .gocontact-datasheet .gc-grid.cols-3 { grid-template-columns: repeat(3, 1fr); }
        .gocontact-datasheet .gc-card {
          display: flex;
          gap: 10px;
          padding: 12px 14px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          box-shadow: 0 1px 2px rgba(15, 42, 68, 0.04);
          transition: none;
        }
        .gocontact-datasheet .gc-card-icon {
          flex: 0 0 32px;
          width: 32px;
          height: 32px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, rgba(67,181,191,0.14), rgba(39,105,143,0.14));
          color: #27698F;
        }
        .gocontact-datasheet .gc-card-content { flex: 1; min-width: 0; }
        .gocontact-datasheet .gc-card-title {
          font-size: 12px;
          font-weight: 700;
          color: #0F2A44;
          margin-bottom: 3px;
          line-height: 1.25;
        }
        .gocontact-datasheet .gc-card-body {
          font-size: 10.5px;
          color: #4A5568;
          line-height: 1.5;
        }
        .gocontact-datasheet .section-chip {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          background: linear-gradient(90deg, rgba(67,181,191,0.12), rgba(39,105,143,0.12));
          color: #27698F;
          border-radius: 999px;
          font-size: 9.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          margin-bottom: 8px;
        }
        .gocontact-datasheet .section-block { margin-top: 4px; }
        .gocontact-datasheet .section-body { margin-bottom: 4px; }
        .gocontact-datasheet hr { margin: 18px 0; }
        .gocontact-datasheet .section-divider { margin: 14px 0; }
        .gocontact-datasheet .about-section {
          position: static;
          margin-top: 16px;
          padding: 14px 16px;
          background: #F7FAFC;
          border-left: 3px solid #43B5BF;
          border-radius: 6px;
          max-width: 100%;
          transform: none !important;
        }
        .gocontact-datasheet .about-title { margin-bottom: 4px; font-size: 13px; }
        .gocontact-datasheet .about-body { font-size: 11px; }
      `}</style>

      <button className="export-pdf-btn" onClick={handleExportPDF}>
        Export as PDF
      </button>

      {/* ===== PAGE 1 ===== */}
      <div className="page page-1">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        {/* Hero */}
        <div className="hero">
          <div>
            <h1 className="hero-headline">
              Go<em>Contact</em>
            </h1>
            <p className="hero-body">
              Deliver exceptional customer experiences across voice and digital channels.
            </p>
            <p className="hero-desc">
              GoContact is Broadvoice's cloud contact center platform that helps organizations deliver exceptional customer experiences across voice and digital channels. Designed for growing businesses and mid-market organizations, GoContact unifies omnichannel engagement, intelligent routing, workforce optimization, analytics, and AI in a single platform.
            </p>
          </div>

          <div className="hero-stat">
            <div className="hero-stat-blur" />
            <div className="hero-stat-card">
              <div className="stat-label-top">One Platform For</div>
              <div className="stat-value">
                <span className="stat-value-sans">CX </span><em>at scale</em>
              </div>
              <div className="stat-desc">
                Voice, digital, AI<br />&amp; workforce — unified
              </div>
            </div>
          </div>
        </div>

        <hr />

        <div className="section-chip">
          <Sparkles size={11} /> Platform Capabilities
        </div>
        <h2 className="section-title">Contact Center <em>Capabilities</em></h2>
        <p className="section-body">
          Agents and supervisors manage every customer interaction from a unified workspace — with the visibility and insights to drive better performance and outcomes.
        </p>

        <div className="gc-grid">
          <Card icon={<MessageSquare size={ICON} />} title="Omnichannel Engagement"
            body="Manage interactions across voice, email, SMS, chat, and social — all from a unified agent workspace." />
          <Card icon={<PhoneCall size={ICON} />} title="Voice & Intelligent Routing"
            body="ACD, IVR, skills-based routing, queue management, and self-service for inbound and outbound." />
          <Card icon={<Megaphone size={ICON} />} title="Outbound Dialer & Campaigns"
            body="Automated dialing, campaign management, customer segmentation, and outbound performance tracking." />
          <Card icon={<LayoutDashboard size={ICON} />} title="Agent & Supervisor Workspaces"
            body="Intuitive browser-based interfaces with real-time metrics, queue visibility, and operational controls." />
          <Card icon={<GraduationCap size={ICON} />} title="Quality Management & Training"
            body="Call evaluations, coaching workflows, scorecards, and e-learning tools to lift service quality." />
          <Card icon={<BarChart3 size={ICON} />} title="Reporting & Analytics"
            body="Real-time dashboards, historical reporting, KPI tracking, and analytics for data-driven decisions." />
          <Card icon={<Ticket size={ICON} />} title="Ticketing & Case Management"
            body="Track, manage, and resolve inquiries across channels with a complete interaction history." />
          <Card icon={<LifeBuoy size={ICON} />} title="Expert Guidance & Support"
            body="From implementation and training through ongoing support and optimization for long-term success." />
        </div>

        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>

      {/* ===== PAGE 2 ===== */}
      <div className="page page-2">
        <div className="logo">
          <img src="/assets/broadvoice-logo.png" alt="Broadvoice" className="logo-img" />
        </div>

        <div className="section-chip">
          <TrendingUp size={11} /> Business Outcomes
        </div>
        <h2 className="section-title">Why Organizations Choose <em>GoContact</em></h2>
        <p className="section-body">
          A single platform to elevate customer experience, empower agents, and run efficient, insight-driven operations.
        </p>

        <div className="gc-grid cols-3">
          <Card icon={<Sparkles size={ICON} />} title="Better Customer Experiences"
            body="Seamless, personalized interactions across every communication channel." />
          <Card icon={<Users size={ICON} />} title="Empower Agents to Perform"
            body="Tools, information, and automation to handle interactions efficiently." />
          <Card icon={<Settings2 size={ICON} />} title="Optimize Operations"
            body="Improve resource utilization, streamline workflows, and increase efficiency." />
          <Card icon={<LineChart size={ICON} />} title="Actionable Insights"
            body="Real-time analytics and conversational reporting for faster, smarter decisions." />
          <Card icon={<TrendingUp size={ICON} />} title="Scale with Confidence"
            body="Flexible, cloud-based platform built to support evolving business needs." />
          <Card icon={<ShieldCheck size={ICON} />} title="Simplify Administration"
            body="Accelerate time-to-value with intuitive experiences for agents, supervisors, and admins." />
        </div>

        <hr className="section-divider" />

        <div className="section-chip">
          <Brain size={11} /> AI &amp; Automation
        </div>
        <h2 className="section-title">AI &amp; <em>Automation</em></h2>
        <p className="section-body">
          AI-powered capabilities that automate routine work, guide agents in real time, and turn every interaction into insight.
        </p>

        <div className="gc-grid cols-3">
          <Card icon={<Mic size={ICON} />} title="Engage Voice"
            body="AI voice agent that automates routine inbound calls with natural speech-to-speech conversations — 24/7." />
          <Card icon={<Bot size={ICON} />} title="Agent Assist"
            body="Real-time guidance, dynamic scripting, and knowledge recommendations to improve outcomes." />
          <Card icon={<FileText size={ICON} />} title="Post-Call AI"
            body="Automatic summaries, outcome detection, dispositions, action items, and sentiment analysis." />
          <Card icon={<Brain size={ICON} />} title="GoInsights AI Analyst"
            body="Conversational analytics that turn contact center data into instant, data-backed answers." />
          <Card icon={<CalendarClock size={ICON} />} title="Workforce Management"
            body="Forecasting, scheduling, adherence, and capacity planning to optimize staffing." />
          <Card icon={<ClipboardCheck size={ICON} />} title="AI Quality & Coaching"
            body="Auto-evaluate interactions, identify coaching opportunities, and surface service improvements." />
        </div>

        <hr className="section-divider" />

        <div className="section-chip">
          <Plug size={11} /> Integrations
        </div>
        <h2 className="section-title"><em>Integrations</em></h2>

        <div className="gc-grid">
          <Card icon={<Boxes size={ICON} />} title="Microsoft Dynamics 365"
            body="Handle inbound and outbound interactions directly inside Microsoft Dynamics through a fully embedded GoContact experience — no application switching." />
          <Card icon={<Plug size={ICON} />} title="Open Integrations & Business Apps"
            body="Connect GoContact with CRM systems, business applications, and third-party tools to streamline workflows in a single experience." />
        </div>


        <div className="page-bottom-cta">
          <img src="/assets/learn-more-cta.png" alt="Learn More at broadvoice.com" />
        </div>
        <div className="page-bottom-blur" />
        <div className="page-bottom-wave">
          <img src="/assets/chart-lines.png" alt="" className="chart-lines-img" />
        </div>
      </div>
    </div>
  );
};

export default GoContactDatasheet;
