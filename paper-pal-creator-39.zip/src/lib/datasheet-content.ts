import { supabase } from "@/integrations/supabase/client";

export const loadContent = async (
  sheetId: string
): Promise<Record<string, string>> => {
  const { data, error } = await supabase
    .from("datasheet_content")
    .select("field_key, content")
    .eq("sheet_id", sheetId);

  if (error) {
    console.error("Error loading content:", error);
    return {};
  }

  const map: Record<string, string> = {};
  for (const row of data || []) {
    map[row.field_key] = row.content;
  }
  return map;
};

export const saveContent = async (
  sheetId: string,
  fields: Record<string, string>
): Promise<boolean> => {
  const rows = Object.entries(fields).map(([field_key, content]) => ({
    sheet_id: sheetId,
    field_key,
    content,
  }));

  const { error } = await supabase
    .from("datasheet_content")
    .upsert(rows, { onConflict: "sheet_id,field_key" });

  if (error) {
    console.error("Error saving content:", error);
    return false;
  }
  return true;
};
