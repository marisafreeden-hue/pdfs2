import { supabase } from "@/integrations/supabase/client";
import { SheetElement } from "@/types/datasheet";

export const saveElements = async (sheetId: string, elements: SheetElement[]) => {
  // Delete existing elements for this sheet
  await supabase.from("datasheet_elements").delete().eq("sheet_id", sheetId);

  if (elements.length === 0) return;

  const rows = elements.map((el) => ({
    sheet_id: sheetId,
    type: el.type,
    x: el.x,
    y: el.y,
    width: el.width ?? null,
    height: el.height ?? null,
    content: el.content ?? null,
    font_size: el.fontSize ?? null,
    font_weight: el.fontWeight ?? null,
    font_family: el.fontFamily ?? null,
    font_style: el.fontStyle ?? null,
    line_height: el.lineHeight ?? null,
    letter_spacing: el.letterSpacing ?? null,
    color: el.color ?? null,
    fill: el.fill ?? null,
    stroke: el.stroke ?? null,
  }));

  const { error } = await supabase.from("datasheet_elements").insert(rows);
  if (error) console.error("Error saving elements:", error);
};

export const loadElements = async (sheetId: string): Promise<SheetElement[]> => {
  const { data, error } = await supabase
    .from("datasheet_elements")
    .select("*")
    .eq("sheet_id", sheetId);

  if (error) {
    console.error("Error loading elements:", error);
    return [];
  }

  return (data || []).map((row) => ({
    id: row.id,
    type: row.type as SheetElement["type"],
    x: row.x,
    y: row.y,
    width: row.width ?? undefined,
    height: row.height ?? undefined,
    content: row.content ?? undefined,
    fontSize: row.font_size ?? undefined,
    fontWeight: row.font_weight ?? undefined,
    fontFamily: row.font_family ?? undefined,
    fontStyle: row.font_style ?? undefined,
    lineHeight: row.line_height ?? undefined,
    letterSpacing: row.letter_spacing ?? undefined,
    color: row.color ?? undefined,
    fill: row.fill ?? undefined,
    stroke: row.stroke ?? undefined,
  }));
};
