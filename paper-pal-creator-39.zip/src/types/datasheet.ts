export interface SheetElement {
  id: string;
  type: "text" | "rect" | "line" | "image";
  x: number;
  y: number;
  width?: number;
  height?: number;
  content?: string;
  fontSize?: number;
  fontWeight?: string;
  fontFamily?: string;
  fontStyle?: string;
  lineHeight?: string;
  letterSpacing?: string;
  color?: string;
  fill?: string;
  stroke?: string;
}
