import React, { useRef, useState, useEffect } from "react";
import { SheetElement } from "@/types/datasheet";

interface CanvasElementProps {
  element: SheetElement;
  isSelected: boolean;
  onSelect: () => void;
  onUpdate: (updates: Partial<SheetElement>) => void;
}

type ResizeHandle = "se" | "sw" | "ne" | "nw" | "e" | "w" | "n" | "s";

const HANDLE_SIZE = 10;

const handleCursors: Record<ResizeHandle, string> = {
  se: "nwse-resize",
  sw: "nesw-resize",
  ne: "nesw-resize",
  nw: "nwse-resize",
  e: "ew-resize",
  w: "ew-resize",
  n: "ns-resize",
  s: "ns-resize",
};

const CanvasElement: React.FC<CanvasElementProps> = ({
  element,
  isSelected,
  onSelect,
  onUpdate,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeHandle, setResizeHandle] = useState<ResizeHandle | null>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [resizeStart, setResizeStart] = useState({ mouseX: 0, mouseY: 0, x: 0, y: 0, w: 0, h: 0 });
  const textRef = useRef<HTMLDivElement>(null);

  const elWidth = element.width || 200;
  const elHeight = element.height || (element.type === "line" ? 2 : element.type === "text" ? 24 : 150);

  // Drag logic
  const handleMouseDown = (e: React.MouseEvent) => {
    if (isEditing) return;
    e.stopPropagation();
    onSelect();
    setIsDragging(true);
    setDragStart({ x: e.clientX - element.x, y: e.clientY - element.y });
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMouseMove = (e: MouseEvent) => {
      onUpdate({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
    };
    const handleMouseUp = () => setIsDragging(false);
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging, dragStart]);

  // Resize logic
  const handleResizeMouseDown = (e: React.MouseEvent, handle: ResizeHandle) => {
    e.stopPropagation();
    e.preventDefault();
    onSelect();
    setIsResizing(true);
    setResizeHandle(handle);
    setResizeStart({
      mouseX: e.clientX,
      mouseY: e.clientY,
      x: element.x,
      y: element.y,
      w: elWidth,
      h: elHeight,
    });
  };

  useEffect(() => {
    if (!isResizing || !resizeHandle) return;

    const handleMouseMove = (e: MouseEvent) => {
      const dx = e.clientX - resizeStart.mouseX;
      const dy = e.clientY - resizeStart.mouseY;
      let newX = resizeStart.x;
      let newY = resizeStart.y;
      let newW = resizeStart.w;
      let newH = resizeStart.h;

      if (resizeHandle.includes("e")) newW = Math.max(20, resizeStart.w + dx);
      if (resizeHandle.includes("w")) {
        newW = Math.max(20, resizeStart.w - dx);
        newX = resizeStart.x + (resizeStart.w - newW);
      }
      if (resizeHandle.includes("s")) newH = Math.max(20, resizeStart.h + dy);
      if (resizeHandle.includes("n")) {
        newH = Math.max(20, resizeStart.h - dy);
        newY = resizeStart.y + (resizeStart.h - newH);
      }

      onUpdate({ x: newX, y: newY, width: newW, height: newH });
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      setResizeHandle(null);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isResizing, resizeHandle, resizeStart]);

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (element.type === "text") {
      setIsEditing(true);
      setTimeout(() => textRef.current?.focus(), 0);
    }
  };

  const handleBlur = () => {
    setIsEditing(false);
    if (textRef.current) {
      onUpdate({ content: textRef.current.innerText });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      setIsEditing(false);
      textRef.current?.blur();
    }
  };

  const renderResizeHandles = () => {
    if (!isSelected) return null;
    const corners: { handle: ResizeHandle; style: React.CSSProperties }[] = [
      { handle: "nw", style: { top: -HANDLE_SIZE / 2, left: -HANDLE_SIZE / 2 } },
      { handle: "ne", style: { top: -HANDLE_SIZE / 2, right: -HANDLE_SIZE / 2 } },
      { handle: "sw", style: { bottom: -HANDLE_SIZE / 2, left: -HANDLE_SIZE / 2 } },
      { handle: "se", style: { bottom: -HANDLE_SIZE / 2, right: -HANDLE_SIZE / 2 } },
    ];

    return corners.map(({ handle, style }) => (
      <div
        key={handle}
        className="absolute"
        style={{
          width: HANDLE_SIZE,
          height: HANDLE_SIZE,
          cursor: handleCursors[handle],
          zIndex: 10,
          borderRadius: "50%",
          backgroundColor: "white",
          border: "2px solid hsl(var(--primary))",
          boxShadow: "0 0 3px rgba(0,0,0,0.2)",
          ...style,
        }}
        onMouseDown={(e) => handleResizeMouseDown(e, handle)}
      />
    ));
  };

  if (element.type === "text") {
    return (
      <div
        className="absolute cursor-move group"
        style={{
          left: element.x,
          top: element.y,
          minWidth: elWidth,
          minHeight: 24,
          outline: isSelected ? "1px solid hsl(var(--primary) / 0.6)" : "none",
          outlineOffset: 1,
        }}
        onMouseDown={handleMouseDown}
        onDoubleClick={handleDoubleClick}
      >
        <div
          ref={textRef}
          contentEditable={isEditing}
          suppressContentEditableWarning
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          className="outline-none whitespace-pre-wrap"
          style={{
            fontSize: element.fontSize || 16,
            fontWeight: element.fontWeight || "normal",
            fontFamily: element.fontFamily || "sans-serif",
            fontStyle: element.fontStyle || "normal",
            lineHeight: element.lineHeight || "normal",
            letterSpacing: element.letterSpacing || "normal",
            ...(element.color?.startsWith("linear-gradient")
              ? {
                  background: element.color,
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }
              : { color: element.color || "hsl(var(--foreground))" }),
            cursor: isEditing ? "text" : "move",
          }}
        >
          {element.content}
        </div>
        {renderResizeHandles()}
      </div>
    );
  }

  if (element.type === "rect") {
    return (
      <div
        className="absolute cursor-move"
        style={{
          left: element.x,
          top: element.y,
          width: elWidth,
          height: elHeight,
          backgroundColor: element.fill || "hsl(var(--muted))",
          border: `2px solid ${element.stroke || "hsl(var(--border))"}`,
          borderRadius: 4,
          outline: isSelected ? "1px solid hsl(var(--primary) / 0.6)" : "none",
          outlineOffset: 1,
        }}
        onMouseDown={handleMouseDown}
      >
        {renderResizeHandles()}
      </div>
    );
  }

  if (element.type === "line") {
    return (
      <div
        className="absolute cursor-move"
        style={{
          left: element.x,
          top: element.y,
          width: elWidth,
          height: 2,
          backgroundColor: element.stroke || "hsl(var(--foreground))",
          outline: isSelected ? "1px solid hsl(var(--primary) / 0.6)" : "none",
          outlineOffset: 4,
        }}
        onMouseDown={handleMouseDown}
      >
        {isSelected && (
          <>
            <div
              className="absolute"
              style={{
                width: HANDLE_SIZE,
                height: HANDLE_SIZE,
                top: -HANDLE_SIZE / 2 + 1,
                left: -HANDLE_SIZE / 2,
                cursor: "ew-resize",
                borderRadius: "50%",
                backgroundColor: "white",
                border: "2px solid hsl(var(--primary))",
                boxShadow: "0 0 3px rgba(0,0,0,0.2)",
              }}
              onMouseDown={(e) => handleResizeMouseDown(e, "w")}
            />
            <div
              className="absolute"
              style={{
                width: HANDLE_SIZE,
                height: HANDLE_SIZE,
                top: -HANDLE_SIZE / 2 + 1,
                right: -HANDLE_SIZE / 2,
                cursor: "ew-resize",
                borderRadius: "50%",
                backgroundColor: "white",
                border: "2px solid hsl(var(--primary))",
                boxShadow: "0 0 3px rgba(0,0,0,0.2)",
              }}
              onMouseDown={(e) => handleResizeMouseDown(e, "e")}
            />
          </>
        )}
      </div>
    );
  }

  if (element.type === "image") {
    return (
      <div
        className="absolute cursor-move"
        style={{
          left: element.x,
          top: element.y,
          width: elWidth,
          height: elHeight,
          outline: isSelected ? "1px solid hsl(var(--primary) / 0.6)" : "none",
          outlineOffset: 1,
        }}
        onMouseDown={handleMouseDown}
      >
        <img
          src={element.content}
          alt=""
          className="w-full h-full object-contain"
          draggable={false}
        />
        {renderResizeHandles()}
      </div>
    );
  }

  return null;
};

export default CanvasElement;
