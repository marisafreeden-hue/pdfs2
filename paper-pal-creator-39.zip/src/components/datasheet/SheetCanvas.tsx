import React, { useRef } from "react";
import { SheetElement } from "@/types/datasheet";
import CanvasElement from "./CanvasElement";

interface SheetCanvasProps {
  elements: SheetElement[];
  selectedId: string | null;
  onSelectElement: (id: string | null) => void;
  onUpdateElement: (id: string, updates: Partial<SheetElement>) => void;
  onAddTextElement: (x: number, y: number) => void;
  onDropAsset: (assetUrl: string, x: number, y: number) => void;
}

const CANVAS_WIDTH_PX = 816; // 8.5in * 96dpi
const PAGE_HEIGHT_PX = 1056; // 11in * 96dpi
const NUM_PAGES = 2;
const CANVAS_HEIGHT_PX = PAGE_HEIGHT_PX * NUM_PAGES;

const SheetCanvas: React.FC<SheetCanvasProps> = ({
  elements,
  selectedId,
  onSelectElement,
  onUpdateElement,
  onAddTextElement,
  onDropAsset,
}) => {
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleCanvasClick = (e: React.MouseEvent) => {
    if (e.target === canvasRef.current) {
      onSelectElement(null);
    }
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    if (e.target === canvasRef.current) {
      const rect = canvasRef.current!.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      onAddTextElement(x, y);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const json = e.dataTransfer.getData("application/json");
    if (!json) return;
    try {
      const asset = JSON.parse(json);
      const rect = canvasRef.current!.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      onDropAsset(asset.file_url, x, y);
    } catch {}
  };

  return (
    <div className="flex-1 overflow-auto flex items-start justify-center p-8 bg-background">
      <div
        ref={canvasRef}
        className="bg-canvas relative shadow-xl"
        style={{
          width: CANVAS_WIDTH_PX,
          minHeight: CANVAS_HEIGHT_PX,
          height: CANVAS_HEIGHT_PX,
          boxShadow: "0 4px 24px -4px hsl(var(--canvas-shadow) / 0.15)",
        }}
        onClick={handleCanvasClick}
        onDoubleClick={handleDoubleClick}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {/* Page divider */}
        {NUM_PAGES > 1 && Array.from({ length: NUM_PAGES - 1 }, (_, i) => (
          <div
            key={`page-divider-${i}`}
            className="absolute w-full border-t-2 border-dashed pointer-events-none"
            style={{
              top: PAGE_HEIGHT_PX * (i + 1),
              borderColor: "hsl(var(--muted-foreground) / 0.3)",
            }}
          />
        ))}

        {elements.map((el) => (
          <CanvasElement
            key={el.id}
            element={el}
            isSelected={selectedId === el.id}
            onSelect={() => onSelectElement(el.id)}
            onUpdate={(updates) => onUpdateElement(el.id, updates)}
          />
        ))}

        {elements.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <p className="text-muted-foreground text-sm">
              Double-click to add text, or use the toolbar above
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SheetCanvas;
