import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Upload, Image, Trash2, GripVertical, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

interface Asset {
  id: string;
  name: string;
  file_url: string;
  asset_type: string;
}

interface AssetLibraryProps {
  onDragAsset: (asset: Asset) => void;
}

const DEFAULT_ASSETS: Asset[] = [
  {
    id: "default-chart-lines",
    name: "Chart Lines",
    file_url: "/assets/chart-lines.svg",
    asset_type: "image",
  },
  {
    id: "default-broadvoice-cta",
    name: "Broadvoice CTA",
    file_url: "/assets/broadvoice-cta.png",
    asset_type: "image",
  },
  {
    id: "default-teal-glow",
    name: "Teal Glow",
    file_url: "/assets/teal-glow.svg",
    asset_type: "image",
  },
  {
    id: "default-background",
    name: "Background",
    file_url: "/assets/background.svg",
    asset_type: "image",
  },
  {
    id: "default-broadvoice-logo",
    name: "Broadvoice Logo",
    file_url: "/assets/broadvoice-logo.png",
    asset_type: "image",
  },
  {
    id: "default-teal-wave",
    name: "Teal Wave",
    file_url: "/assets/teal-wave.svg",
    asset_type: "image",
  },
  {
    id: "default-teal-gradient-bg",
    name: "Teal Gradient BG",
    file_url: "/assets/teal-gradient-bg.png",
    asset_type: "image",
  },
  {
    id: "default-teal-blur-wide",
    name: "Teal Blur Wide",
    file_url: "/assets/teal-blur-wide.svg",
    asset_type: "image",
  },
];

const AssetLibrary: React.FC<AssetLibraryProps> = ({ onDragAsset }) => {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  const allAssets = [...DEFAULT_ASSETS, ...assets];

  const fetchAssets = async () => {
    const { data, error } = await supabase
      .from("assets")
      .select("*")
      .order("created_at", { ascending: false });
    if (data) setAssets(data);
    if (error) console.error("Error fetching assets:", error);
  };

  useEffect(() => {
    fetchAssets();
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    try {
      for (const file of Array.from(files)) {
        const fileExt = file.name.split(".").pop();
        const filePath = `${crypto.randomUUID()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from("assets")
          .upload(filePath, file);

        if (uploadError) {
          toast.error(`Failed to upload ${file.name}`);
          continue;
        }

        const { data: urlData } = supabase.storage
          .from("assets")
          .getPublicUrl(filePath);

        const { error: insertError } = await supabase.from("assets").insert({
          name: file.name,
          file_path: filePath,
          file_url: urlData.publicUrl,
          asset_type: file.type.startsWith("image/") ? "image" : "file",
        });

        if (insertError) {
          toast.error(`Failed to save ${file.name}`);
        }
      }
      toast.success("Assets uploaded!");
      fetchAssets();
    } finally {
      setIsUploading(false);
      e.target.value = "";
    }
  };

  const handleDelete = async (asset: Asset) => {
    await supabase.storage.from("assets").remove([asset.file_url.split("/assets/")[1] || ""]);
    await supabase.from("assets").delete().eq("id", asset.id);
    setAssets((prev) => prev.filter((a) => a.id !== asset.id));
    toast.success("Asset deleted");
  };

  const handleDragStart = (e: React.DragEvent, asset: Asset) => {
    e.dataTransfer.setData("application/json", JSON.stringify(asset));
    e.dataTransfer.effectAllowed = "copy";
  };

  if (collapsed) {
    return (
      <div className="w-10 bg-card border-r border-border flex flex-col items-center pt-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCollapsed(false)}
          className="h-8 w-8 text-muted-foreground hover:text-foreground"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
        <div className="mt-4">
          <Image className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col">
      {/* Header */}
      <div className="p-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Image className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-semibold text-foreground">Assets</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCollapsed(true)}
          className="h-7 w-7 text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
      </div>

      {/* Upload */}
      <div className="p-3 border-b border-border">
        <label className="flex items-center justify-center gap-2 px-3 py-2 rounded-md border-2 border-dashed border-border cursor-pointer hover:border-primary hover:bg-accent transition-colors">
          <Upload className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            {isUploading ? "Uploading..." : "Upload Assets"}
          </span>
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={handleUpload}
            className="hidden"
            disabled={isUploading}
          />
        </label>
      </div>

      {/* Asset Grid */}
      <ScrollArea className="flex-1">
        <div className="p-3 grid grid-cols-2 gap-2">
          {allAssets.map((asset) => {
            const isDefault = asset.id.startsWith("default-");
            return (
              <div
                key={asset.id}
                draggable
                onDragStart={(e) => handleDragStart(e, asset)}
                className="group relative rounded-md border border-border overflow-hidden cursor-grab active:cursor-grabbing hover:border-primary transition-colors bg-background"
              >
                <img
                  src={asset.file_url}
                  alt={asset.name}
                  className="w-full aspect-square object-cover"
                  draggable={false}
                />
                <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/10 transition-colors" />
                <div className="absolute top-1 left-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <GripVertical className="h-3 w-3 text-foreground/70" />
                </div>
                {!isDefault && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(asset);
                    }}
                    className="absolute top-1 right-1 h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity bg-destructive/80 hover:bg-destructive text-destructive-foreground"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
                <div className="px-1 py-0.5">
                  <p className="text-xs text-muted-foreground truncate">{asset.name}</p>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
};

export default AssetLibrary;
