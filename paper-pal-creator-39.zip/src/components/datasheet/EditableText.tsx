import React, { useRef, useEffect } from "react";

interface EditableTextProps {
  value: string;
  fieldKey: string;
  onChange: (key: string, value: string) => void;
  className?: string;
  tag?: "h1" | "h2" | "h3" | "p" | "div" | "span" | "em" | "strong";
  style?: React.CSSProperties;
}

const EditableText: React.FC<EditableTextProps> = ({
  value,
  fieldKey,
  onChange,
  className,
  tag: Tag = "div",
  style,
}) => {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    if (ref.current && ref.current.innerText !== value) {
      ref.current.innerText = value;
    }
  }, [value]);

  const handleBlur = () => {
    if (ref.current) {
      const newValue = ref.current.innerText;
      if (newValue !== value) {
        onChange(fieldKey, newValue);
      }
    }
  };

  return (
    <Tag
      ref={ref as any}
      contentEditable
      suppressContentEditableWarning
      onBlur={handleBlur}
      className={className}
      style={{
        ...style,
        cursor: "text",
        outline: "none",
        minHeight: "1em",
      }}
      data-field={fieldKey}
    />
  );
};

export default EditableText;
