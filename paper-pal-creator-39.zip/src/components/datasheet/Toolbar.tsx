import React from "react";
import { Button } from "@/components/ui/button";
import {
  Type,
  Square,
  Minus,
  Image,
  Trash2,
  FileText,
  Bold,
  Italic,
} from "lucide-react";

interface ToolbarProps {
  onAddText: () => void;
  onAddRect: () => void;
  onAddLine: () => void;
  onAddImage: () => void;
  onDelete: () => void;
  onToggleBold: () => void;
  onToggleItalic: () => void;
  hasSelection: boolean;
}

const Toolbar: React.FC<ToolbarProps> = ({
  onAddText,
  onAddRect,
  onAddLine,
  onAddImage,
  onDelete,
  onToggleBold,
  onToggleItalic,
  hasSelection,
}) => {
  return (
    <div className="bg-toolbar flex items-center gap-1 px-4 py-2 shadow-md">
      <div className="flex items-center gap-1 mr-2">
        <FileText className="h-5 w-5 text-toolbar-foreground" />
        <span className="text-toolbar-foreground font-semibold text-sm tracking-wide">
          DataSheet Creator
        </span>
      </div>

      <div className="w-px h-6 bg-toolbar-foreground/20 mx-2" />

      <Button
        variant="ghost"
        size="icon"
        onClick={onAddText}
        className="text-toolbar-foreground hover:bg-toolbar-foreground/10 h-8 w-8"
        title="Add Text"
      >
        <Type className="h-4 w-4" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={onAddRect}
        className="text-toolbar-foreground hover:bg-toolbar-foreground/10 h-8 w-8"
        title="Add Rectangle"
      >
        <Square className="h-4 w-4" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={onAddLine}
        className="text-toolbar-foreground hover:bg-toolbar-foreground/10 h-8 w-8"
        title="Add Line"
      >
        <Minus className="h-4 w-4" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={onAddImage}
        className="text-toolbar-foreground hover:bg-toolbar-foreground/10 h-8 w-8"
        title="Add Image"
      >
        <Image className="h-4 w-4" />
      </Button>

      <div className="w-px h-6 bg-toolbar-foreground/20 mx-2" />

      <Button
        variant="ghost"
        size="icon"
        onClick={onToggleBold}
        disabled={!hasSelection}
        className="text-toolbar-foreground hover:bg-toolbar-foreground/10 h-8 w-8 disabled:opacity-30"
        title="Bold"
      >
        <Bold className="h-4 w-4" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={onToggleItalic}
        disabled={!hasSelection}
        className="text-toolbar-foreground hover:bg-toolbar-foreground/10 h-8 w-8 disabled:opacity-30"
        title="Italic"
      >
        <Italic className="h-4 w-4" />
      </Button>

      <div className="w-px h-6 bg-toolbar-foreground/20 mx-2" />

      <Button
        variant="ghost"
        size="icon"
        onClick={onDelete}
        disabled={!hasSelection}
        className="text-toolbar-foreground hover:bg-destructive/80 h-8 w-8 disabled:opacity-30"
        title="Delete"
      >
        <Trash2 className="h-4 w-4" />
      </Button>

      <div className="flex-1" />

      <span className="text-toolbar-foreground/60 text-xs">
        8.5" × 11"
      </span>
    </div>
  );
};

export default Toolbar;
